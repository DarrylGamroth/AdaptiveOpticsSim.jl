import csv,hashlib,json,os,subprocess,threading,time
from pathlib import Path
root=Path('/tmp/aos-completion-slopes-20261021')
after=Path('/home/dgamroth/workspaces/codex/AdaptiveOpticsSim-cuda-completion-slopes')
before=Path('/home/dgamroth/workspaces/codex/AdaptiveOpticsSim.jl')
source=['src/wfs/geometric_slopes.jl','ext/AdaptiveOpticsSimCUDAExt.jl','benchmarks/benchmark_geometric_slopes_workflow_cuda.jl','benchmarks/profile_pyramid_efficiency_cuda.jl']
(root/'campaign-source-hashes.json').write_text(json.dumps({f:hashlib.sha256((after/f).read_bytes()).hexdigest() for f in source},indent=2)+'\n')
stop=threading.Event()
def monitor():
 os.sched_setaffinity(0,{6})
 with (root/'telemetry.csv').open('w') as f:
  w=csv.writer(f);w.writerow(['begin_ns','end_ns','sm_mhz','memory_mhz','pstate','temperature_c','power_w','clock_event_mask'])
  while not stop.is_set():
   a=time.monotonic_ns()
   p=subprocess.run(['nvidia-smi','--query-gpu=clocks.current.sm,clocks.current.memory,pstate,temperature.gpu,power.draw,clocks_event_reasons.active','--format=csv,noheader,nounits'],capture_output=True,text=True)
   b=time.monotonic_ns()
   if p.returncode==0:w.writerow([a,b]+[v.strip() for v in p.stdout.strip().split(',')]);f.flush()
   stop.wait(.1)
t=threading.Thread(target=monitor);t.start()
try:
 for run in (1,2,3):
  for label,checkout in [('before',before),('after',after)]:
   env=dict(os.environ,JULIA_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',AOS_BENCHMARK_ROOT=str(checkout),AOS_GEOMETRIC_RESULTS=str(root/f'geometric-{label}{run}.toml'),AOS_PYRAMID_RESULTS=str(root/f'pyramid-{label}{run}.toml'))
   code=f'include("{after}/benchmarks/benchmark_geometric_slopes_workflow_cuda.jl"); benchmark_geometric_workflow(); include("{after}/benchmarks/profile_pyramid_efficiency_cuda.jl"); profile_pyramid_efficiency()'
   print('starting',label,run,flush=True)
   with (root/f'campaign-{label}{run}.log').open('w') as f:
    p=subprocess.run(['taskset','-c','2','julia','--startup-file=no','--threads=1,0','--gcthreads=1',f'--project={checkout}/test/cuda','-e',code,'cuda'],cwd=checkout,env=env,stdout=f,stderr=subprocess.STDOUT)
   print('completed',label,run,'exit',p.returncode,flush=True)
   if p.returncode:raise SystemExit(p.returncode)
finally:
 stop.set();t.join()
