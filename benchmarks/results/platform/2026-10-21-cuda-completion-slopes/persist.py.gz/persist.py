import csv,gzip,hashlib,json,math,re,statistics,subprocess,tomllib
from pathlib import Path
root=Path('/tmp/aos-completion-slopes-20261021')
repo=Path('/home/dgamroth/workspaces/codex/AdaptiveOpticsSim-cuda-completion-slopes')
before=Path('/home/dgamroth/workspaces/codex/AdaptiveOpticsSim.jl')
donor=Path('/home/dgamroth/workspaces/codex/pipewire/JuliaFilterGraph.jl')
slug='2026-10-21-cuda-completion-slopes'
out=repo/'benchmarks/results/platform'; rawdir=out/slug;rawdir.mkdir(exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def read(name):return tomllib.loads((root/name).read_text())
expected=json.loads((root/'campaign-source-hashes.json').read_text())
for path,h in expected.items():assert sha((repo/path).read_bytes())==h,path
runs={}
for kind in ('before','after'):
 for run in (1,2,3):
  g=read(f'geometric-{kind}{run}.toml');p=read(f'pyramid-{kind}{run}.toml')
  assert len(g['case'])==5 and len(p['case'])==4
  assert g['selected_cooperative']==(kind=='after')
  assert p['synchronization']=='default'
  assert all(len(c['workflow_samples_ns'])==128 and sum(c['gc_collections'])==0 for c in g['case'])
  assert all(len(c['samples_ns'])==128 and sum(c['gc_collections'])==0 for c in p['case'])
  runs[kind,run]=g,p
entries=[]
for idx,n in enumerate((96,128,160,512,1024)):
 old=[runs['before',r][0]['case'][idx] for r in (1,2,3)]
 new=[runs['after',r][0]['case'][idx] for r in (1,2,3)]
 assert all(c['pupil_resolution']==n for c in old+new)
 e=dict(pupil_resolution=n,lenslets_per_axis=32,pixels_per_subaperture=n//32,
  before_public_p50_us=[c['workflow_p50_ns']/1000 for c in old],after_public_p50_us=[c['workflow_p50_ns']/1000 for c in new],
  before_host_bytes=[c['host_bytes'] for c in old],after_host_bytes=[c['host_bytes'] for c in new],
  maximum_cpu_difference=max(c['maximum_cpu_difference'] for c in old+new))
 for c in old+new:
  assert c['workflow_p50_ns']==statistics.median(c['workflow_samples_ns'])
  assert len(c['blocks'])==16
  assert all(len(b['event_seconds_per_kernel'])==32 for b in c['blocks'])
 medians={v:[] for v in ('serial','selected')};ratios=[]
 for c in new:
  logs=[]
  for rnd in range(1,5):
   blocks=[b for b in c['blocks'] if b['round']==rnd]
   assert [b['variant'] for b in blocks]==['serial','selected','selected','serial']
   times={v:[statistics.median(b['event_seconds_per_kernel']) for b in blocks if b['variant']==v] for v in medians}
   logs.append(statistics.mean(map(math.log,times['serial']))-statistics.mean(map(math.log,times['selected'])))
  ratios.append(math.exp(statistics.mean(logs)))
  for v in medians:medians[v].append(statistics.median([t for b in c['blocks'] if b['variant']==v for t in b['event_seconds_per_kernel']])*1e6)
 e['kernel_paired_geometric_speedup']=ratios
 e['serial_kernel_p50_us']=medians['serial'];e['selected_kernel_p50_us']=medians['selected']
 entries.append(e)
pyramid=[]
for idx in range(4):
 old=[runs['before',r][1]['case'][idx] for r in (1,2,3)];new=[runs['after',r][1]['case'][idx] for r in (1,2,3)]
 for c in old+new:assert c['p50_ns']==statistics.median(c['samples_ns'])
 pyramid.append(dict(resolution=old[0]['resolution'],strategy=old[0]['strategy'],before_p50_us=[c['p50_ns']/1000 for c in old],after_p50_us=[c['p50_ns']/1000 for c in new],maximum_relative_cpu_error=max(c['relative_cpu_error'] for c in old+new),timed_gc_collections=0))
source=['src/wfs/geometric_slopes.jl','ext/AdaptiveOpticsSimCUDAExt.jl','benchmarks/benchmark_geometric_slopes_workflow_cuda.jl','benchmarks/profile_pyramid_efficiency_cuda.jl','test/geometric_slopes_numerics.jl','test/cuda/geometric_slopes.jl','test/cuda/kernel_completion.jl','test/ka_cpu_matrix.jl','test/runtests_cuda.jl','benchmarks/benchmark_geometric_slopes_scaling_cuda.jl']
meta=dict(artifact_id='CUDA-COMPLETION-GEOMETRIC-SLOPES-2026-10-21',baseline_revision='325cdde781083cc756d6b2f88caaea2682ebc65f',implementation_state='Baseline plus production/test/benchmark changes identified by source hashes; scientific formulas, CPU implementation, and edge-masked slopes unchanged.',decision='Use blocking current-stream completion for synchronous CUDA kernel phases. Use cooperative32-lane summation of all original neighboring differences for eligible same-precision subapertures>=5; retain serial small/mixed/exceptional paths.',environment=dict(gpu='RTX3080 sm86;68SM',cpu='AMD Ryzen7 6800H',julia='1.13.2',cuda_jl='6.4.2',kernel_abstractions='0.9.45',cuda_runtime='13.4.0',driver='615.71.09',threads='1 compute,0 interactive,1 GC;BLAS/FFT1',affinity='Julia CPU2;passive monitor CPU6',clocks='Uncontrolled system defaults;shared host',manifest_sha256=sha((repo/'test/cuda/Manifest.toml').read_bytes())),implementation=dict(slopes='Every horizontal/vertical adjacent difference still contributes once, averaged by sub(sub-1) and scaled in the original order. One32-lane group per subaperture; parallel addition order changes rounding.',exceptions='Nonfinite differences or differences exceeding a conservative floatmax/(2count)/max(1,abs(scales)) bound select the original serial sum. Small subapertures<5, mixed/unusual types and nonfinite scales use serial dispatch. Invalid subapertures suppress OPD reads;sub1 unchanged.',completion='CUDA synchronous kernel phases now use CUDA.synchronize(current_stream;blocking=true), retaining device-exception checks. Low-level callers may select blocking=false. Calling-thread task cooperation changes; no global callback/concurrency guarantee is inferred.',capture='Prepared graph completion code and fixed-storage guard are unchanged. Private asynchronous slope enqueue permits fixed-storage capture. Float32/64 slope replay passes zero warmed host-byte assertions; public dynamic KA launch allocations are measured separately.',crossover='Pilot3/4pixel subapertures regressed with cooperative groups;5pixels crossed over. Small cases retainedserial. Pilot data excluded from final campaign.'),protocol=dict(fresh_processes_per_revision=3,process_order='before1,after1,before2,after2,before3,after3; each process geometric cases then Pyramid cases;fixedcase order',workflow='Captured GaussianDM->pupilOPD graph followed by public geometric_wavefront_slopes!; target-ready GPU slopes, host copies forCPUoracles outside timing.128 closed-loop time_ns samples after32 warmups percase. Combined kernel+completion-policy effect.',oracles='Changed0,-0.7,1.3,1times deterministic command: complete CPU workflow compared to GPU beforetiming; posttiming parity and CUDA.used_memory stability. Pyramid each strategy compared to CPU before/after. All passed.',kernel='Within each afterprocess, originalserial versus actualproduction-selected asyncenqueue. FourABBA groups,32CUDAevents/block,32repeatedkernels/event. Nooutputreset needed; alloutputs overwritten. Eventtime includes amortizednativegraph scheduling; no publicwait or inputtransfer.',paired_formula='For eachABBA group: mean(log(serialblockp50))-mean(log(selectedblockp50)); exponentiate mean of4groups perprocess. Report3process values separately. Ratio>1 means selectedfaster.',total_workflow_samples=3840,total_pyramid_samples=3072,total_kernel_event_samples=15360,timed_gc_collections=0,limitations='One hardware/software stack; shared host and uncontrolled clocks. Always-before-first pairedprocess order and fixedcaseorder can bias small effects.128closed-loop samples support descriptive medians, not fixed-rate/tail/WCET claims. Outputcopies/RTC/transport outside boundary. No throughput claim forotherbackends.'),validation=dict(ka_cpu_numerical_checks=824,cuda_numerical_checks=824,cuda_public_api_checks=4,cuda_fixed_storage_slope_checks=6,cuda_capture_graph_regression_checks=91,cuda_completion_storage_wait_multiplication_checks=333,coverage='Float32/64;sub1/2/3/4/5/16/32;constant/plane/spike/checkerboard/largeoffset/subnormal/non-dyadiccancellation;BigFloat exact-input reference withabsoluteerrorbounds;anisotropicscales;NaN/Inf/overflow;invalidmasks;mixedprecision;edge-maskparity;currentstream/contextrestoration;defaultblocking and explicitcooperative completion;capturedreplayzeroheap.',commands=['julia --project=test/cuda -e \'include("test/cuda/geometric_slopes.jl"); include("test/runtests_gpu_target_common.jl"); B=Backends.CUDABackendTag; @testset "capture" begin; run_captured_coordinate_gaussian_graph_execution_smoke(B); run_captured_graph_execution_smoke(B); run_captured_atmosphere_replay_smoke(B); run_captured_wfs_replay_smoke(B); run_captured_detector_replay_smoke(B); run_grouped_graph_execution_smoke(B); run_graph_rng_capture_replay(B); end\'','julia --project=test/cuda -e \'include("test/cuda/kernel_completion.jl"); include("test/cuda/captured_storage.jl"); include("test/cuda/prepared_wait.jl"); include("test/cuda_prepared_multiplication_capture.jl")\'']),executor_comparison=dict(aos_revision='325cdde781083cc756d6b2f88caaea2682ebc65f',juliafiltergraph_revision='02a8ad1bc23f478e6637047c9862adf7c6b36775',scope='Read-only source and existing-test review; no direct executor performancecomparison measured.',juliafiltergraph_strengths='Genericstreaming declaration API, conditional/rejected/deferred samples, joins/pipelines, pernode commitment and richer retained fault/lifetime protocol.',aos_fit='Residentphysicalplant arrays, explicit plan/state/workspace/binding owners, modeltime and capacity-one async tickets/selectiveobservation. JFG ordinary capturedprocess stageshostoutputs and waits everyframe; its publication/lifecycle contracts differ.',recommendation='Keep packageboundary and AOSexecutor; consider borrowing documentedstatefulcapturehooks, retainedfailurediagnostics and failed-drainstoragelifetime protocol, and optional declarationhelper. No executorAPIredesign included in this change.'),commands=dict(common='JULIA_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1; taskset -c 2; julia --startup-file=no --threads=1,0 --gcthreads=1 --project=<checkout>/test/cuda',geometric='AOS_BENCHMARK_ROOT=<checkout> AOS_GEOMETRIC_RESULTS=/tmp/geometric.toml julia --project=<checkout>/test/cuda <driver>/benchmarks/benchmark_geometric_slopes_workflow_cuda.jl cuda',campaign='See archived run_campaign.py; same driver files executed in fresh checkout-specific projects; default Pyramid mode asserted.',telemetry='nvidia-smi SM/memoryclocks,pstate,temperature,power,clockeventreasons every nominal100ms+querylatency,begin/endCLOCK_MONOTONIC retained; includes coldphase, no timingintervalattribution or stabilityclaim'),source_files_sha256={p:sha((repo/p).read_bytes()) for p in source})
meta['environment'].update(gpu='NVIDIA GeForce RTX 3080; sm_86; 68 SMs; 10 GiB', cpu='AMD Ryzen 7 6800H', threads='1 compute, 0 interactive, 1 GC; BLAS/FFT 1', affinity='Julia CPU 2; passive monitor CPU 6', clocks='Uncontrolled system defaults; shared host')
meta['implementation']['slopes'] = 'Every horizontal and vertical adjacent difference contributes once, averaged by sub(sub-1) and scaled in the original order. One 32-lane group per eligible subaperture; parallel addition order changes rounding.'
meta['protocol'].update(process_order='before1, after1, before2, after2, before3, after3; each process runs geometric cases then Pyramid cases in fixed order.', workflow='Captured Gaussian DM → pupil OPD graph followed by public geometric_wavefront_slopes!; completed GPU slopes. CPU-oracle host copies are outside timing. 128 closed-loop time_ns samples after 32 warmups per case. Combined kernel and completion-policy effect.', oracles='Command scales 0, -0.7, 1.3 and 1: complete CPU workflow compared to GPU before timing; post-timing parity and CUDA.used_memory stability. Each Pyramid strategy compared to CPU before and after. All passed.', kernel='Within each after process, original serial versus actual production-selected asynchronous enqueue. Four ABBA groups, 32 CUDA events per block, 32 repeated kernels per event. Every output is overwritten. Event time includes amortized native graph scheduling; no public wait or input transfer.', paired_formula='For each ABBA group: mean(log(serial block p50)) − mean(log(selected block p50)); exponentiate the mean of four groups per process. Report three process values separately. Ratio > 1 means selected is faster.')
meta['validation']['coverage'] = 'Float32/64; subapertures 1/2/3/4/5/16/32; constant, plane, spike, checkerboard, large offset, subnormal and non-dyadic cancellation inputs; BigFloat exact-input reference with absolute error bounds; anisotropic scales; NaN/Inf/overflow; invalid masks; mixed precision; edge-mask parity; 32/33 output-grid boundary; current-stream/context restoration; default blocking and explicit cooperative completion; captured replay with zero warmed host bytes.'
meta['executor_comparison'].update(scope='Read-only source and existing-test review; no direct executor performance comparison.', juliafiltergraph_strengths='Generic streaming declaration API, conditional/rejected/deferred samples, joins and pipelines, per-node commitment and a richer retained fault/lifetime protocol.', aos_fit='Resident physical plant arrays, explicit plan/state/workspace/binding owners, model time, capacity-one asynchronous tickets and selective observation. Ordinary JFG captured process stages host outputs and waits every frame; publication and lifecycle contracts differ.', recommendation='Keep the package boundary and AOS executor. Consider borrowing documented stateful capture hooks, retained failure diagnostics, a failed-drain storage lifetime protocol, and an optional declaration helper. No executor API redesign is included here.')
meta['commands']['telemetry'] = 'nvidia-smi SM/memory clocks, pstate, temperature, power and clock event reasons every nominal 100 ms plus query latency. Begin/end CLOCK_MONOTONIC retained. Includes cold phases; no timing-interval attribution or stability claim.'
meta['decision'] = 'Use blocking current-stream completion for synchronous CUDA kernel phases. Use cooperative summation for same-precision Float32/Float64 subapertures with at least five pixels per side on grids no larger than 32 × 32. Retain original serial execution elsewhere.'
meta['implementation']['crossover'] = 'Small subapertures (three/four pixels) regressed in pilots. A separate output-density pilot found regressions with one group per output on dense grids. The final policy restricts cooperative execution to a conservative measured region; it is not an optimal crossover model. Pilot and final density samples are archived separately.'
meta['implementation']['exceptions'] = 'Nonfinite differences or differences above floatmax/(2count)/max(1,abs(scales)) select the original serial sum. Subapertures smaller than five pixels, grids larger than 32 × 32, mixed/unusual types and nonfinite scales use original serial dispatch. Invalid subapertures suppress OPD reads; sub=1 is unchanged.'
meta['protocol']['limitations'] = 'One RTX 3080 and software stack; shared host and uncontrolled clocks. Always-before-first process order and fixed case order can bias small effects. The 128 closed-loop samples support descriptive medians, not fixed-rate, tail-latency or WCET claims. Host output copies, RTC and transport are outside the timed boundary. Density sweep uses Float32 and a deterministic mask with about 20% invalid subapertures. No throughput claim for other backends or mask distributions.'
meta['full_plant_control'] = {}
for kind in ('before', 'after'):
    log = (root / f'plant-{kind}.log').read_text()
    assert 'cpu_reference_before_after=passed' in log
    for policy, mean, allocated in re.findall(r'policy=(stream|captured).*?mean_ns=([0-9.]+) warmed_host_allocation_bytes=(\d+)', log):
        meta['full_plant_control'][f'{kind}_{policy}_mean_us'] = float(mean) / 1000
        meta['full_plant_control'][f'{kind}_{policy}_host_bytes'] = int(allocated)
        if policy == 'captured': assert int(allocated) == 0
meta['full_plant_control']['boundary'] = 'Complete Gaussian DM → pupil OPD → Shack–Hartmann rate → CCD frame plant, 1000 completed frames in one fresh process per revision. CPU oracle before and after. Descriptive control; no small-effect significance claim.'
density = []
for label in ('pilot', 'final'):
    data = read(f'geometric-scaling-{label}.toml')
    assert len(data['case']) == 14
    for case in data['case']:
        times = {v: statistics.median([t for b in case['blocks'] if b['variant'] == v for t in b['event_seconds_per_kernel']]) * 1e6 for v in ('serial','selected')}
        density.append(dict(policy=label, lenslets_per_axis=case['lenslets_per_axis'], pixels_per_subaperture=case['pixels_per_subaperture'], serial_p50_us=times['serial'], selected_p50_us=times['selected'], maximum_cpu_difference=case['maximum_cpu_difference']))
meta['density_protocol'] = dict(boundary='CUDA events around eight repeated kernels per graph; two rounds of ABBA/BAAB, eight events per block. CPU oracle before/after. One process each for unrestricted pilot and final selection.', pilot_source_sha256=sha((root/'geometric-scaling-pilot-source.jl').read_bytes()), final_source_sha256=sha((repo/'src/wfs/geometric_slopes.jl').read_bytes()))
meta['independent_review'] = dict(scope='Read-only independent source, benchmark, arithmetic and provenance review; no additional GPU runs.', result='No implementation blocker. Recomputed raw archive/source/manifest hashes, medians, paired speedups, density results, sample counts and validation totals. Corrected full plant boundary to include Shack–Hartmann rate and CCD frame. The density policy is a conservative measured region, not an optimal crossover.')
meta['baseline_source_sha256']={p:sha(subprocess.check_output(['git','-C',str(before),'show','325cdde7:'+p])) for p in ['src/wfs/geometric_slopes.jl','ext/AdaptiveOpticsSimCUDAExt.jl']}
# Archive all actual campaign samples, validation logs, and independent review.
paths=[root/f'{prefix}-{kind}{run}.toml' for kind in ['before','after'] for run in [1,2,3] for prefix in ['geometric','pyramid']]
paths += [root/name for name in ['telemetry.csv','run_campaign.py','persist.py','campaign-source-hashes.json','executor-comparison.md','cuda-final-focused.log','ka-cpu-final.log','cuda-completion-capture.log','plant-before.log','plant-after.log','geometric-scaling-pilot.toml','geometric-scaling-final.toml','geometric-scaling-pilot-source.jl','geometric-scaling-pilot-source-hashes.json','finish_validation.py','campaign-final.log','finish-validation.log']]
archives=[]
for p in paths:
 data=p.read_bytes();packed=gzip.compress(data,mtime=0);dest=rawdir/(p.name+'.gz');dest.write_bytes(packed)
 archives.append(dict(path=str(dest.relative_to(repo)),sha256=sha(packed),uncompressed_sha256=sha(data),uncompressed_bytes=len(data)))
telemetry=list(csv.DictReader((root/'telemetry.csv').open()))
meta['telemetry']=dict(samples=len(telemetry),sm_mhz_range_campaign=[min(int(r['sm_mhz']) for r in telemetry),max(int(r['sm_mhz']) for r in telemetry)],pstates_campaign=sorted({r['pstate'] for r in telemetry}),limitation='Wholecampaign includes compilation/warmup/oracles; no conclusion ofstable clocksduringtiming.')
lines=[]
def key(k):return json.dumps(k,ensure_ascii=False) if any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-' for c in k) else k
def dump(table,prefix=''):
 for k,v in table.items():
  if not isinstance(v,dict):lines.append(key(k)+' = '+json.dumps(v,ensure_ascii=False))
 for k,v in table.items():
  if isinstance(v,dict):
   p=(prefix+'.' if prefix else '')+key(k);lines.extend(['','['+p+']']);dump(v,p)
def entry(name,e):lines.extend(['','[['+name+']]']);dump(e,name)
dump(meta)
for e in entries:entry('geometric',e)
for e in pyramid:entry('pyramid',e)
for e in density:entry('density',e)
for e in archives:entry('raw_archive',e)
text='\n'.join(lines)+'\n';tomllib.loads(text);(out/(slug+'.toml')).write_text(text)
for e in entries:print(e['pupil_resolution'],'workflow before',e['before_public_p50_us'],'after',e['after_public_p50_us'],'device speedup',e['kernel_paired_geometric_speedup'])
for e in pyramid:print(e['resolution'],e['strategy'],e['before_p50_us'],e['after_p50_us'])
print('Archived',len(archives),'files')
