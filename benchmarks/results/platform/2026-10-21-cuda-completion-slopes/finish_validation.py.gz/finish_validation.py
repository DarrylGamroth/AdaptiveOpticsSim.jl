import os,subprocess,time
from pathlib import Path
root=Path('/tmp/aos-completion-slopes-20261021')
repo=Path('/home/dgamroth/workspaces/codex/AdaptiveOpticsSim-cuda-completion-slopes')
for _ in range(360):
    log=(root/'campaign-final.log').read_text()
    if 'completed after 3 exit 0' in log:break
    if 'Traceback' in log or 'exit 1' in log:raise SystemExit('campaign failed')
    time.sleep(5)
else:raise SystemExit('campaign timeout')
env=dict(os.environ,JULIA_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',AOS_PROFILE_REPLAYS='1000')
common=['taskset','-c','2','julia','--startup-file=no','--threads=1,0','--gcthreads=1','--project=test/cuda']
focused='''include("test/cuda/geometric_slopes.jl"); include("test/runtests_gpu_target_common.jl"); B=Backends.CUDABackendTag; @testset "CUDA capture completion regression" begin; run_captured_coordinate_gaussian_graph_execution_smoke(B); run_captured_graph_execution_smoke(B); run_captured_atmosphere_replay_smoke(B); run_captured_wfs_replay_smoke(B); run_captured_detector_replay_smoke(B); run_grouped_graph_execution_smoke(B); run_graph_rng_capture_replay(B); end'''
for name,args in [('cuda-final-focused.log',['-e',focused]),('plant-after.log',['benchmarks/profile_aos_gpu_plant.jl','cuda','both'])]:
    print('starting',name,flush=True)
    with (root/name).open('w') as f:
        p=subprocess.run(common+args,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
    print('completed',name,p.returncode,flush=True)
    if p.returncode:raise SystemExit(p.returncode)
