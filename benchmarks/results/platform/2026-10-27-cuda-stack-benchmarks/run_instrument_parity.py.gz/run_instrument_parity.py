import os,time,subprocess,json,datetime
from pathlib import Path
b=Path(__file__).resolve().parent
while subprocess.check_output(["nvidia-smi","--query-compute-apps=pid","--format=csv,noheader"],text=True).strip():time.sleep(2)
cmd=["taskset","-c","2","julia","--startup-file=no","--threads=1,0","--gcthreads=1","--project="+str(b/"baseline-instrument-environment"),str(b/"instrument-parity.jl")]
env=dict(os.environ,OPENBLAS_NUM_THREADS="1",BENCH_BASE=str(b))
with (b/"instrument-parity.log").open("w") as f:
 rc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
(b/"instrument-parity-command.json").write_text(json.dumps(dict(command=cmd,returncode=rc),indent=2))
print("Parity diagnostic completed; scheduler remains paused for adjudication",flush=True)
