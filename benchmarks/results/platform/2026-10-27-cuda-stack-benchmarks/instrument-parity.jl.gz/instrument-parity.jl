using CUDA,AdaptiveOpticsSim,AdaptiveOpticsSimPipeWireHIL,PipeWireAORTC,LinearAlgebra,TOML
using AdaptiveOpticsSim.AlgorithmGraphs
function main()
 BLAS.set_num_threads(1);AdaptiveOpticsSim.Backends.set_fft_provider_threads!(1);CUDA.allowscalar(false)
 path=joinpath(ENV["BENCH_BASE"],"instrument-data/gpi2/simulation/definition.yaml")
 target=AdaptiveOpticsSim.Backends.compute_device(CUDA.zeros(Float32,1))
 rates=Matrix{Float32}[];frames=Matrix{UInt16}[]
 for (name,execution) in (("stream",StreamGraphExecution()),("captured",CapturedGraphExecution()))
  println("prepare ",name);flush(stdout)
  system=PipeWireAORTC.InstrumentConfiguration.prepare_system(path;settings=Dict("profile"=>"grid_gaussian","pupil_resolution"=>240),target,execution)
  for _ in 1:32;step_graph!(system.graph);end
  reset_hil_boundary!(system.boundary)
  seq=step_hil_frame!(system.boundary);adopt_hil_command!(system.boundary,seq)
  push!(rates,Array(graph_output(system.graph,:photon_rate)));push!(frames,copy(hil_frame_buffer(system.boundary)))
  open(io->write(io,vec(rates[end])),joinpath(ENV["BENCH_BASE"],"parity-"*name*".f32"),"w")
  println(name," rate_sum=",sum(Float64,rates[end]));flush(stdout)
 end
 a,c=rates;difference=Float64.(c).-a
 result=Dict("relative_l2"=>norm(difference)/norm(Float64.(a)),"maximum_abs"=>maximum(abs,difference),"maximum_value"=>maximum(a),"unequal_pixels"=>count(a.!=c),"pixels"=>length(a),"frame_exact"=>frames[1]==frames[2])
 println(result)
 open(io->TOML.print(io,result;sorted=true),joinpath(ENV["BENCH_BASE"],"instrument-parity.toml"),"w")
end
main()
