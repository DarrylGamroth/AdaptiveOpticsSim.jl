import os, subprocess, json, time, datetime
from pathlib import Path
BASE=Path(__file__).resolve().parent
SOURCE=Path("/home/dgamroth/workspaces/codex/worktrees/aos-cuda-stack-benchmarks-20261027")
JULIA=["taskset","-c","2","julia","--startup-file=no","--threads=1,0","--gcthreads=1"]
ENV=dict(os.environ, OPENBLAS_NUM_THREADS="1", JULIA_NUM_THREADS="1", JULIA_PKG_PRECOMPILE_AUTO="0", AOS_BENCHMARK_ROOT=str(SOURCE), AOS_GPU_PATTERN_PROFILE="0", AOS_PROFILE_EXTERNAL="0")
def run(label, stack, rep, script, args=(),extra=None):
 stem=f"{label}-{stack}-{rep}"
 output=BASE/(stem+".toml")
 env=dict(ENV,AOS_RESULTS=str(output), AOS_GEOMETRIC_RESULTS=str(output), AOS_GEOMETRIC_SCALING_RESULTS=str(output),AOS_PROFILE_SAMPLES="128",AOS_PROFILE_WARMUPS="32")
 if extra:env.update(extra)
 argv=JULIA+["--project="+str(BASE/(stack+"-environment")),str(script)]+[str(a).replace("{OUTPUT}",str(output)) for a in args]
 # Refuse measurements alongside another compute client. Only read GPU state.
 clients=subprocess.check_output(["nvidia-smi","--query-compute-apps=pid,process_name","--format=csv,noheader"],text=True).strip()
 if clients:raise RuntimeError("GPU occupied before "+stem+": "+clients)
 record=dict(label=label,stack=stack,repetition=rep,command=argv,environment_overrides={k:v for k,v in env.items() if k.startswith("AOS_") or k in ("OPENBLAS_NUM_THREADS","JULIA_NUM_THREADS")},start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 print("START",stem,flush=True)
 started=time.monotonic()
 with (BASE/(stem+".log")).open("w") as log:
  result=subprocess.run(argv,env=env,cwd=SOURCE,stdout=log,stderr=subprocess.STDOUT)
 record.update(returncode=result.returncode,elapsed_s=time.monotonic()-started,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),output_exists=output.exists())
 with (BASE/"commands.jsonl").open("a") as f:f.write(json.dumps(record)+"\n")
 print("DONE",stem,"exit",result.returncode,"seconds",round(record["elapsed_s"],1),flush=True)
 # Preserve failures and continue remaining independent workloads.
for stack in ("baseline","candidate"):
 run("metadata",stack,0,BASE/"metadata.jl")
workloads=[("builders", BASE/"builder_driver.jl",()),
 ("kernel-patterns",SOURCE/"benchmarks/profile_gpu_kernel_patterns_cuda.jl",("{OUTPUT}",)),
 ("geometric-workflow",SOURCE/"benchmarks/benchmark_geometric_slopes_workflow_cuda.jl",("cuda",)),
 ("geometric-scaling",SOURCE/"benchmarks/benchmark_geometric_slopes_scaling_cuda.jl",("cuda",))]
for case in ("gpi_default","gpi_fine","copper_default","copper_fast","copper_fine"):
 workloads.append(("physical-"+case,SOURCE/"benchmarks/profile_physical_pyramid_cuda.jl",("{OUTPUT}",case,"-1")))
for rep in range(1,4):
 stacks=("baseline","candidate") if rep%2 else ("candidate","baseline")
 cases=workloads if rep%2 else list(reversed(workloads))
 for label,script,args in cases:
  for stack in stacks:run(label,stack,rep,script,args)
print("CAMPAIGN COMPLETE",flush=True)
