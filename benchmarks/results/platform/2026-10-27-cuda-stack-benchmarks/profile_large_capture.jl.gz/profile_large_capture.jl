using Profile
include(joinpath(ENV["AOS_BENCHMARK_ROOT"], "benchmarks/profile_physical_pyramid_cuda.jl"))
function diagnose()
 CUDA.allowscalar(false);BLAS.set_num_threads(1);Backends.set_fft_provider_threads!(1)
 MODULATION_BATCH[]=-1
 case=only(filter(c->c.name=="gpi_fine",PHYSICAL_PROFILE_CASES))
 graph=batch_graph(case,WavefrontSensors.PyramidPupilTiltStrategy())
 for _ in 1:32;step_graph!(graph);end
 reference=Array(graph_output(graph,:rate))
 bytes=[@allocated(step_graph!(graph)) for _ in 1:16]
 println("UNPROFILED_BYTES=",bytes);flush(stdout)
 Profile.Allocs.clear()
 Profile.Allocs.start(sample_rate=1.0)
 try
  for _ in 1:64;step_graph!(graph);end
 finally
  Profile.Allocs.stop()
 end
 records=Profile.Allocs.fetch()
 println("ALLOCATION_RECORDS=",length(records.allocs))
 Profile.Allocs.print(stdout,records)
 for (i,a) in enumerate(records.allocs)
  println("\nALLOCATION ",i," size=",a.size," type=",a.type)
  for f in a.stacktrace
   println(f)
  end
 end
 reference==Array(graph_output(graph,:rate)) || error("replaychanged")
end
diagnose()
