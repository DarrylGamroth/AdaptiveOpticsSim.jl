using CUDA, TOML, Statistics, LinearAlgebra
using AdaptiveOpticsSim
BLAS.set_num_threads(1)
AdaptiveOpticsSim.Backends.set_fft_provider_threads!(1)
CUDA.allowscalar(false)
include(joinpath(ENV["AOS_BENCHMARK_ROOT"], "benchmarks/backend_benchmark_contract.jl"))
suite = run_backend_benchmark_suite(GPUBenchmarkTarget{CUDABackendTag}())
function record_trial(trial)
 Dict("times_ns"=>trial.times, "gc_times_ns"=>trial.gctimes,
      "evals"=>trial.params.evals, "samples"=>length(trial.times),
      "median_ns"=>median(trial.times), "host_bytes"=>BenchmarkTools.memory(trial),
      "allocations"=>BenchmarkTools.allocs(trial))
end
open(ENV["AOS_RESULTS"], "w") do io
 TOML.print(io, Dict("julia"=>string(VERSION), "cuda"=>string(pkgversion(CUDA)),
  "boundary"=>"Complete cold builder call and backend completion; warmed compilation; setup allocates by design",
  "model"=>record_trial(suite.builder_trial),
  "high_accuracy"=>record_trial(suite.builder_high_accuracy_trial)); sorted=true)
end
