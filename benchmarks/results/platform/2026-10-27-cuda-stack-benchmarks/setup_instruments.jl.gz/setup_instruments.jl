using Pkg
Pkg.add([PackageSpec(name="AdaptiveOpticsSimPipeWireHIL",version="0.2.6"), PackageSpec(name="PipeWireAORTC",version="0.2.18")])
Pkg.precompile()
Pkg.status()
