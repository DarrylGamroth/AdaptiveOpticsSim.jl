using TOML,HdrHistogram,Base64,SHA
function verify()
 base=@__DIR__
 count=0
 for name in ("gpi2","classic"),stack in ("baseline","candidate"),rep in 1:3
  retry=joinpath(base,"instrument-rerun-$name-$stack-$rep.toml")
  path=isfile(retry) ? retry : joinpath(base,"instrument-$name-$stack-$rep.toml")
  data=TOML.parsefile(path)
  data["captured"]["comparison"]["passed"] || error("comparison failed")
  for policy in ("stream","captured"),boundary in ("graph","hil_cycle")
   result=data[policy][boundary]
   histogram=HdrHistogram.decode_from_compressed_byte_buffer(base64decode(result["histogram_base64"]))
   HdrHistogram.total_count(histogram)==5000 || error("histogram count mismatch")
   samples=result["samples_ns"]
   length(samples)==5000 || error("raw sample count mismatch")
   # Hdr values represent quantized ranges, so compare percentile ranks within its resolution.
   actual=sort(samples)[4950]
   reported=HdrHistogram.value_at_percentile(histogram,99.0)
   abs(actual-reported)<=max(1000,0.002*actual) || error("histogram percentile mismatch")
   count+=1
  end
 end
 println("Verified ",count," histograms, ",count*5000," raw completed-operation samples")
end
verify()
