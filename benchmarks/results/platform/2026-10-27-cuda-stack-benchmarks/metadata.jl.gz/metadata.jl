using CUDA, KernelAbstractions, AdaptiveOpticsSim, Pkg, LinearAlgebra, TOML, SHA
VERSION >= v"1.13" && VERSION < v"1.14" || error("Julia1.13 required")
CUDA.versioninfo()
Pkg.status(;mode=Pkg.PKGMODE_MANIFEST)
println("JULIA_THREADS=", Threads.nthreads(), " BLAS_THREADS=",BLAS.get_num_threads())
println("CUDA_NONBLOCKING_SYNC=", isdefined(CUDA.CUDACore, :use_nonblocking_synchronization) ? CUDA.CUDACore.use_nonblocking_synchronization : "unavailable")
println("AOS=",pathof(AdaptiveOpticsSim))
println("EXT_SHA256=",bytes2hex(sha256(read(joinpath(dirname(dirname(pathof(AdaptiveOpticsSim))),"ext/AdaptiveOpticsSimCUDAExt.jl")))))
