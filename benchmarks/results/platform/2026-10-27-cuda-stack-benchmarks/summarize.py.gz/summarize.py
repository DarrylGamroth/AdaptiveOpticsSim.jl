import json, math, statistics, tomllib
from pathlib import Path
BASE=Path(__file__).resolve().parent
ROWS=[]
commands=[json.loads(line) for line in (BASE/"commands.jsonl").read_text().splitlines()]
FINISHED={f"{r['label']}-{r['stack']}-{r['repetition']}" for r in commands if r["returncode"]==0}
def load(label,stack,rep):
 p=BASE/f"{label}-{stack}-{rep}.toml"
 if not (p.exists() and p.stem in FINISHED) and label.startswith("instrument-"):
  p=BASE/f"{label.replace('instrument-','instrument-rerun-',1)}-{stack}-{rep}.toml"
 return tomllib.loads(p.read_text()) if p.exists() and p.stem in FINISHED else None

def add(label,metric,extract,unit="ms"):
 data={k:[] for k in ("baseline","candidate")}
 for rep in range(1,4):
  for k in data:
   x=load(label,k,rep)
   if x is not None:
    try:data[k].append(float(extract(x)))
    except (KeyError,TypeError,StopIteration):pass
 if not all(len(v)==3 for v in data.values()):return
 a=statistics.median(data["baseline"]);c=statistics.median(data["candidate"])
 ROWS.append(dict(workload=label,metric=metric,unit=unit,baseline_runs=data["baseline"],candidate_runs=data["candidate"],baseline_median=a,candidate_median=c,percent_change=100*(c/a-1),paired_changes=[100*(y/x-1) for x,y in zip(data["baseline"],data["candidate"])]))
for case in ("gpi_default","gpi_fine","copper_default","copper_fast","copper_fine"):
 add("physical-"+case,"completed_node_median",lambda d:d["median_ms"])
for name in ("model","high_accuracy"):
 add("builders",name,lambda d,n=name:d[n]["median_ns"]/1e6)
for n in (96,128,160,512,1024):
 add("geometric-workflow",f"N{n}.completed_median",lambda d,n=n:next(r["workflow_p50_ns"] for r in d["case"] if r["pupil_resolution"]==n)/1e3,"us")
sample=load("geometric-scaling","baseline",1)
if sample:
 for row in sample["case"]:
  n=row["pupil_resolution"];lenslets=row["lenslets_per_axis"]
  def kernel_time(d,n=n,lenslets=lenslets):
   row=next(r for r in d["case"] if r["pupil_resolution"]==n and r["lenslets_per_axis"]==lenslets)
   return statistics.median(t for block in row["blocks"] if block["variant"]=="selected" for t in block["event_seconds_per_kernel"])*1e6
  add("geometric-scaling",f"N{n}.L{lenslets}.selected_event",kernel_time,"us")
for name in ("gpi2","classic"):
 label="instrument-"+name
 for policy in ("stream","captured"):
  for boundary in ("graph","hil_cycle"):
   for pct in ("p50_ns","p95_ns","p99_ns","maximum_ns"):
    add(label,f"{policy}.{boundary}.{pct.removesuffix('_ns')}",lambda d,p=policy,b=boundary,q=pct:d[p][b][q]/1e6)
# Individual kernel event medians preserve case and process identity.
sample=load("kernel-patterns","baseline",1)
if sample:
 for row in sample["cases"]:
  label=row["label"]
  add("kernel-patterns",label,lambda d,n=label:next(r["median_seconds"] for r in d["cases"] if r["label"]==n)*1e6,"us")
commands=[json.loads(line) for line in (BASE/"commands.jsonl").read_text().splitlines()]
result=dict(rows=ROWS,finished_commands=len(commands),failed_commands=[r for r in commands if r["returncode"]],interpretation="Stack comparison; medians of 3 independent process runs; paired changes in run order. Unpaced serial service; no fixed-rate, deadline, or transport claim. Physical: 128 samples/process; instrument: 5000 samples/process; instrument p99 diagnostic only.")
(BASE/"summary.json").write_text(json.dumps(result,indent=2))
for r in ROWS:
 print(f"{r['workload']:30s} {r['metric']:35s} {r['baseline_median']:10.4f} -> {r['candidate_median']:10.4f} {r['unit']} {r['percent_change']:+6.1f}% paired="+str([round(v,1) for v in r['paired_changes']]))
print("Finished",len(commands),"failed",len(result["failed_commands"]))
