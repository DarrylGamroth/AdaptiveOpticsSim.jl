using Profile
include(joinpath(ENV["AOS_BENCHMARK_ROOT"], "benchmarks/profile_physical_pyramid_cuda.jl"))
@noinline function completed_step!(graph::G) where {G}
 step_graph!(graph)
 return nothing
end
function collect_steps!(graph::G,bytes;profile=false) where {G}
 for i in eachindex(bytes)
  bytes[i]=@allocated completed_step!(graph)
 end
 return nothing
end
function print_records(records)
 println("ALLOCATION_RECORDS=",length(records.allocs))
 for (i,a) in enumerate(records.allocs)
  typestring=string(a.type)
  println("ALLOCATION ",i," size=",a.size," type=",first(typestring,min(length(typestring),160)))
  for f in a.stacktrace
   func=string(f.func);file=string(f.file)
   println(first(func,min(length(func),160))," at ",file,":",f.line)
  end
 end
end
function diagnose()
 CUDA.allowscalar(false);BLAS.set_num_threads(1);Backends.set_fft_provider_threads!(1)
 MODULATION_BATCH[]=-1
 case=only(filter(c->c.name=="gpi_fine",PHYSICAL_PROFILE_CASES))
 graph=batch_graph(case,WavefrontSensors.PyramidPupilTiltStrategy())
 completed_step!(graph)
 bytes=Vector{Int}(undef,64)
 collect_steps!(graph,Vector{Int}(undef,1))
 for _ in 1:30;completed_step!(graph);end
 reference=Array(graph_output(graph,:rate))
 Profile.Allocs.clear()
 Profile.Allocs.start(sample_rate=1.0)
 try
  collect_steps!(graph,bytes)
 finally
  Profile.Allocs.stop()
 end
 println("PROFILED_BYTES=",bytes)
 print_records(Profile.Allocs.fetch())
 reference==Array(graph_output(graph,:rate)) || error("replaychanged")
end
diagnose()
