using Pkg
VERSION >= v"1.13" && VERSION < v"1.14" || error("Julia1.13 required")
Pkg.add(PackageSpec(name="BenchmarkTools", version="1"))
Pkg.add(PackageSpec(url="https://github.com/DarrylGamroth/HdrHistogram.jl.git", rev="cd42987e0739c06d29d20b4341f088b85e7a620c"))
Pkg.precompile()
Pkg.status()
