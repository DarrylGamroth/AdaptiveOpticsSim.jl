using CUDA, AdaptiveOpticsSim, AdaptiveOpticsSimPipeWireHIL, PipeWireAORTC
using AdaptiveOpticsSim.AlgorithmGraphs
using LinearAlgebra, Statistics, TOML, SHA, HdrHistogram, Base64
const IC = PipeWireAORTC.InstrumentConfiguration
const SAMPLES = 5000
const WARMUPS = 100
cycle!(boundary) = (adopt_hil_command!(boundary, step_hil_frame!(boundary)); nothing)
function probe_command!(command::AbstractArray)
    fill!(command, 0)
    command[firstindex(command)] = 1f-8
    command[lastindex(command)] = -2f-8
    return nothing
end
probe_command!(commands::NamedTuple) = foreach(probe_command!, values(commands))
function probe!(system)
    sequence = step_hil_frame!(system.boundary)
    probe_command!(hil_command_buffer(system.boundary))
    adopt_hil_command!(system.boundary, sequence)
    cycle!(system.boundary)
    return copy(hil_frame_buffer(system.boundary))
end
function relative_error(actual, reference)
    norm(Float64.(actual) .- Float64.(reference)) / max(norm(Float64.(reference)), eps())
end
function measure(f, value; require_zero)
    first_started = time_ns()
    f(value)
    first_call_ns = time_ns() - first_started
    for _ in 1:WARMUPS
        f(value)
    end
    allocations = [@allocated(f(value)) for _ in 1:16]
    require_zero && !all(iszero, allocations) && error("captured allocation: $allocations")
    histogram = HdrHistogram.Histogram(1, 60_000_000_000, 3)
    samples = Vector{UInt64}(undef, SAMPLES)
    memory_before = CUDA.used_memory()
    gc_before = Base.gc_num()
    started = time_ns()
    for index in eachindex(samples)
        t = time_ns()
        f(value)
        samples[index] = time_ns() - t
        HdrHistogram.record_value!(histogram, Int64(samples[index]))
    end
    elapsed = time_ns() - started
    gc_after = Base.gc_num()
    memory_after = CUDA.used_memory()
    require_zero && memory_after != memory_before && error("device memory changed")
    encoded = HdrHistogram.encode_into_compressed_byte_buffer(histogram)
    HdrHistogram.total_count(HdrHistogram.decode_from_compressed_byte_buffer(encoded)) == SAMPLES || error("histogram sample loss")
    return Dict("samples_ns"=>samples, "samples"=>SAMPLES,
        "first_call_ns"=>first_call_ns, "warmups"=>WARMUPS,
        "p50_ns"=>median(samples), "p95_ns"=>quantile(samples,.95),
        "p99_ns"=>quantile(samples,.99), "maximum_ns"=>maximum(samples),
        "elapsed_ns"=>elapsed, "instrumented_closed_loop_hz"=>1e9*SAMPLES/elapsed,
        "allocation_samples"=>allocations, "device_bytes_before"=>memory_before,
        "device_bytes_after"=>memory_after,
        "gc_collections"=>Base.GC_Diff(gc_after,gc_before).pause,
        "instrumented_loop_allocated_bytes"=>Base.GC_Diff(gc_after,gc_before).allocd,
        "instrumented_loop_gc_time_ns"=>Base.GC_Diff(gc_after,gc_before).total_time,
        "histogram_base64"=>base64encode(encoded),
        "histogram_encoding"=>"HdrHistogram compressed V2; ns, range1..60e9,3significant figures")
end
function main()
    length(ARGS)==2 || error("INSTRUMENT DEFINITION")
    name,path = ARGS
    CUDA.functional() || error("CUDA required")
    CUDA.allowscalar(false)
    BLAS.set_num_threads(1)
    AdaptiveOpticsSim.Backends.set_fft_provider_threads!(1)
    target=AdaptiveOpticsSim.Backends.compute_device(CUDA.zeros(Float32,1))
    resolution = name=="classic" ? 480 : 240
    settings=Dict("profile"=>"grid_gaussian", "pupil_resolution"=>resolution)
    rate_name = name=="classic" ? :shwfs_photon_rate : :photon_rate
    println("oracle_cpu_prepare ",name);flush(stdout)
    cpu=IC.prepare_system(path; settings, calibration=true)
    expected=probe!(cpu)
    expected_rate=Array(graph_output(cpu.graph,rate_name))
    all(isfinite,expected_rate) && sum(expected_rate)>0 || error("invalid CPU reference")
    oracle=Dict{String,Any}()
    for (policy,execution) in (("stream",StreamGraphExecution()),("captured",CapturedGraphExecution()))
        println("oracle_gpu_prepare ",policy);flush(stdout)
        gpu=IC.prepare_system(path; settings, calibration=true,target,execution)
        actual=probe!(gpu)
        actual_rate=Array(graph_output(gpu.graph,rate_name))
        rate_error=relative_error(actual_rate,expected_rate)
        frame_error=relative_error(actual,expected)
        rate_error<1e-3 && frame_error<1e-3 || error("$policy numerical error: rate=$rate_error frame=$frame_error")
        oracle[policy]=Dict("rate_relative_l2"=>rate_error,"frame_relative_l2"=>frame_error)
        gpu=nothing
        GC.gc(true);CUDA.reclaim()
    end
    cpu=nothing;GC.gc(true);CUDA.reclaim()
    output=Dict{String,Any}("instrument"=>name,"definition"=>path,"settings"=>settings,
        "julia"=>string(VERSION),"cuda"=>string(pkgversion(CUDA)),"aos"=>string(pkgversion(AdaptiveOpticsSim)),
        "aortc"=>string(pkgversion(PipeWireAORTC)),"samples"=>SAMPLES,"oracle"=>oracle,
        "scope"=>"Unpaced single outstanding completed science graph; HIL additionally copies frame to retained host storage and adopts same-sequence zero commands; no transport/RTC/optical diagnostic rendering",
        "accuracy_scope"=>"CPU/GPU parity of same deterministic calibration model; not external physical validation",
        "tails"=>"p99 has50expected exceedances perprocess; p99.9 not claimed; raw histograms/samples retained")
    references=Dict{String,Any}()
    for (policy,execution) in (("stream",StreamGraphExecution()),("captured",CapturedGraphExecution()))
        println("science_prepare ",name," ",policy);flush(stdout)
        started=time_ns()
        system=IC.prepare_system(path;settings,target,execution)
        preparation_ns=time_ns()-started
        graph_stats=measure(step_graph!,system.graph;require_zero=policy=="captured")
        reset_hil_boundary!(system.boundary)
        hil_stats=measure(cycle!,system.boundary;require_zero=policy=="captured")
        reset_hil_boundary!(system.boundary);cycle!(system.boundary)
        frame=copy(hil_frame_buffer(system.boundary))
        rate=Array(graph_output(system.graph,rate_name))
        reset_hil_boundary!(system.boundary);cycle!(system.boundary)
        frame==hil_frame_buffer(system.boundary) || error("seeded reset changed frame")
        if policy=="stream"
            references["frame"]=frame;references["rate"]=rate
        else
            frame==references["frame"] || error("stream/captured seeded frame mismatch")
            rate==references["rate"] || error("stream/captured seeded rate mismatch")
        end
        output[policy]=Dict("preparation_first_call_ns"=>preparation_ns,"graph"=>graph_stats,
            "hil_cycle"=>hil_stats,"seeded_reset_reproducible"=>true,
            "frame_sha256"=>bytes2hex(sha256(reinterpret(UInt8,vec(frame)))),
            "frame_shape"=>collect(size(frame)),"frame_type"=>string(eltype(frame)),
            "rate_sha256"=>bytes2hex(sha256(reinterpret(UInt8,vec(rate)))),
            "captured_nodes"=>captured_graph_node_count(system.graph))
        println(name," ",policy," graph_p50_ms=",graph_stats["p50_ns"]/1e6," hil_p50_ms=",hil_stats["p50_ns"]/1e6);flush(stdout)
        open(io->TOML.print(io,output;sorted=true),ENV["AOS_RESULTS"],"w")
        system=nothing;GC.gc(true);CUDA.reclaim()
    end
end
main()
