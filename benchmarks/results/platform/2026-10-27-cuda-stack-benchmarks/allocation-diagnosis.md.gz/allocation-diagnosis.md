The expanded CUDA comparison fails the process-wide zero-allocation gate on the fine physical GPI and Copper cases. The existing assertions remain unchanged. Default dependency pins remain unchanged.

A clean diagnostic uses a concrete completed-step helper returning `nothing`, warms the same Vector collector type, then profiles 64 completed fine GPI replays while recording the allocation count of each step. One step records 288 bytes; the other 63 record zero. Profile.Allocs records exactly one allocation: a requested 272-byte `Memory{Any}` in Base's timer-handle preservation dictionary rehash. Its stack ends at the Timer callback task compiled into CUDACore. There are no graph-return boxes or compiler records in this final diagnostic.

CUDACore starts a one-second Timer for resource retirement. The Timer wait preserves and unpreserves its handle in Base's `uvhandles` IdDict. Deleted entries eventually trigger a rehash. The 272-byte request plus the GC tag rounds to the 288-byte allocation class charged by `@allocated`; these describe the same event. The yielded AOS completion wait permits the background task to run, and the allocation counter is process-wide.

This is separate from a 16-byte RefValue{Int64} allocation observed on CUDACore's active resource-drain path. The optional concrete-counter patch avoids boxing in empty-drain replay, but does not establish zero allocation during arbitrary resource cleanup.

The first diagnostic directly called a dynamically inferred immutable graph-returning function and recorded 64 return-value boxes. A second diagnostic used a no-return helper but warmed a SubArray collector before profiling a Vector, adding compiler records outside the per-step allocation interval. Both exploratory traces are retained. The final diagnostic removes both measurement artifacts and preserves the 288-byte event.

Primary implementation evidence:
- CUDACore 6.5.0, `src/resources/lifecycle.jl`, retirement Timer and drain_retired.
- Julia 1.13.3 Base `libuv.jl:59–80`, `asyncevent.jl:164–202,362–379`, `iddict.jl:61–87,100–111`.
- https://github.com/JuliaLang/julia/blob/v1.13.3/src/gc-stock.c#L746-L766 (requested-size profiler and allocation class selection).
- https://github.com/JuliaLang/julia/blob/v1.13.3/src/gc-stock.c#L676-L694 (GC pool-size accounting).
- https://github.com/JuliaLang/julia/blob/v1.13.3/src/julia_internal.h#L469-L479 (size classes).
- https://github.com/JuliaLang/julia/blob/v1.13.3/src/iddict.c#L10-L26 (rehash allocation).

No production code, cleanup policy, GC behavior, dependency source, or allocation assertion was changed for these benchmarks. Disabling the Timer or suppressing cleanup was not tested or used.
