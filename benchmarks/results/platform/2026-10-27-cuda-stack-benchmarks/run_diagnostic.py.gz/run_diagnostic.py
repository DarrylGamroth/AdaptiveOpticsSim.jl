import os,subprocess,time,json,datetime,signal
from pathlib import Path
b=Path(__file__).resolve().parent
source=Path('/home/dgamroth/workspaces/codex/worktrees/aos-cuda-stack-benchmarks-20261027')
while subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip():time.sleep(2)
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',JULIA_NUM_THREADS='1',AOS_BENCHMARK_ROOT=str(source))
cmd=['taskset','-c','2','julia','--startup-file=no','--threads=1,0','--gcthreads=1','--project='+str(b/'candidate-environment'),str(b/'profile_large_capture.jl')]
record={'command':cmd,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
try:
 with (b/'large-capture-profile.log').open('w') as log:
  record['returncode']=subprocess.run(cmd,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 record['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 (b/'large-capture-profile-command.json').write_text(json.dumps(record,indent=2))
finally:
 os.kill(1476815,signal.SIGCONT)
print('Diagnostic finished; resumed campaign',flush=True)
