import json,tomllib,hashlib,gzip,subprocess,statistics,datetime,array,math
from pathlib import Path
BASE=Path(__file__).resolve().parent
SOURCE=Path('/home/dgamroth/workspaces/codex/worktrees/aos-cuda-stack-benchmarks-20261027')
NAME='2026-10-27-cuda-stack-benchmarks'
TARGET=SOURCE/'benchmarks/results/platform'/NAME
# Call only when all campaigns are complete and all writers are stopped.
assert 'CAMPAIGN COMPLETE' in (BASE/'campaign.log').read_text()
assert 'INSTRUMENT CAMPAIGN COMPLETE' in (BASE/'instrument-campaign.log').read_text()
assert 'INSTRUMENT RETRIES COMPLETE' in (BASE/'instrument-retries.log').read_text()
subprocess.run(['python3',str(BASE/'summarize.py')],check=True,stdout=subprocess.DEVNULL)
summary=json.loads((BASE/'summary.json').read_text())
commands=[json.loads(line) for line in (BASE/'commands.jsonl').read_text().splitlines()]
bench_commands=[r for r in commands if r['repetition']>0]
rejected_attempts=[r for r in bench_commands if r['returncode']!=0 and r['label'].startswith('instrument-') and 'stream/captured seeded rate mismatch' in (BASE/f"{r['label']}-{r['stack']}-{r['repetition']}.log").read_text()]
qualification_commands=[r for r in bench_commands if r not in rejected_attempts]
parity=[]
for case in ('gpi_default','gpi_fine','copper_default','copper_fast','copper_fine'):
 for rep in range(1,4):
  paths=[BASE/f'physical-{case}-{k}-{rep}.toml' for k in ('baseline','candidate')]
  if not all(p.exists() for p in paths):continue
  meta=[tomllib.loads(p.read_text()) for p in paths];values=[]
  for p,d in zip(paths,meta):
   v=array.array('f');v.frombytes((p.parent/d['rate_file']).read_bytes());values.append(v)
   assert len(v)==math.prod(d['output_shape'])
   assert hashlib.sha256((p.parent/d['rate_file']).read_bytes()).hexdigest()==d['output_sha256']
  a,c=values;assert len(a)==len(c) and meta[0]['output_shape']==meta[1]['output_shape']
  relative=math.sqrt(sum((float(x)-float(y))**2 for x,y in zip(a,c))/sum(float(x)**2 for x in a))
  parity.append(dict(case=case,repetition=rep,relative_l2=relative,bitwise_equal=meta[0]['output_sha256']==meta[1]['output_sha256'],passed=relative<1e-5))
assert all(r['passed'] for r in parity)
(BASE/'physical-cross-stack-parity.json').write_text(json.dumps(parity,indent=2))
zero_observations=0
instrument_intervals=[]
for r in bench_commands:
 if r['returncode']!=0:continue
 p=BASE/f"{r['label']}-{r['stack']}-{r['repetition']}.toml"
 d=tomllib.loads(p.read_text())
 if r['label'].startswith('physical-'):
  assert all(v==0 for v in d['host_allocated_bytes']);zero_observations+=len(d['host_allocated_bytes'])
 if r['label'].startswith('instrument-'):
  for boundary in ('graph','hil_cycle'):
   a=d['captured'][boundary]['allocation_samples'];assert all(v==0 for v in a);zero_observations+=len(a)
   stats=d['captured'][boundary]
   instrument_intervals.append(dict(workload=r['label'],stack=r['stack'],repetition=r['repetition'],boundary=boundary,samples=stats['samples'],probe_max_bytes=max(a),instrumented_loop_bytes=stats['instrumented_loop_allocated_bytes'],gc_collections=stats['gc_collections'],median_ms=stats['p50_ns']/1e6))
instrument_parity=[]
for name in ('gpi2','classic'):
 for rep in range(1,4):
  paths=[]
  for stack in ('baseline','candidate'):
   original=BASE/f'instrument-{name}-{stack}-{rep}.toml';retry=BASE/f'instrument-rerun-{name}-{stack}-{rep}.toml'
   paths.append(retry if retry.exists() else original)
  if not all(p.exists() for p in paths):continue
  ds=[tomllib.loads(p.read_text()) for p in paths]
  if not all('captured' in d for d in ds):continue
  row=dict(instrument=name,repetition=rep,frame_bitwise_equal=ds[0]['captured']['frame_sha256']==ds[1]['captured']['frame_sha256'],rate_bitwise_equal=ds[0]['captured']['rate_sha256']==ds[1]['captured']['rate_sha256'])
  for quantity in ('rate','frame'):
   arrays=[]
   for d in ds:
    metadata=d['captured'];path=BASE/metadata[quantity+'_file'];blob=path.read_bytes()
    assert hashlib.sha256(blob).hexdigest()==metadata[quantity+'_sha256']
    vals=array.array('H' if path.suffix=='.u16' else 'f');vals.frombytes(blob);arrays.append(vals)
   a,c=arrays;assert len(a)==len(c) and all(math.isfinite(v) for v in a) and all(math.isfinite(v) for v in c)
   rel=math.sqrt(sum((float(x)-float(y))**2 for x,y in zip(a,c))/max(sum(float(x)**2 for x in a),1e-300))
   row[quantity+'_relative_l2']=rel
  row['relative_l2_tolerance']=1e-3
  row['passed']=row['frame_relative_l2']<1e-3 and row['rate_relative_l2']<1e-3
  instrument_parity.append(row)
# Retain negative or unavailable comparisons as evidence; do not turn missing timing into a pass.
report=dict(schema_version=1,date='2026-10-27',source_commit=subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip(),
 source_worktree=str(SOURCE),branch='codex/cuda-stack-benchmarks-20261027',
 purpose='Compare resolved CUDA 6.4.2 / KA 0.9.45 with CUDA 6.5.0 / KA 0.10.3 plus optional counter patch at unchanged AOS source',
 disposition='Keep default pins: candidate fails unchanged process-wide zero-allocation gates on fine physical pyramid cases',
 environment=dict(julia='1.13.3',gpu='NVIDIA GeForce RTX 3080',driver='615.71.10',compute_threads=1,gc_threads=1,blas_threads=1,fft_threads=1,affinity='CPU2',gpu_competing_compute_clients='None admitted by per-process guard',cpu_load='Shared host; independent CPU validation and RTC processes remained active',clocks='Default automatic GPU clocks; no power/clock/governor changes',source_dirty_before_runs=False),
 contract=dict(repetitions=3,order='Paired stacks alternated by repetition; workload order reversed in repetition 2',boundary='Completed graph/device outputs; HIL adds host frame staging and same-sequence command adoption. No transport/RTC.',load_model='Unpaced single-outstanding serial service time',physical_samples_per_process=128,instrument_samples_per_process=5000,instrument_warmups=100,instrument_allocation_probes=16,physical_warmups=32,physical_allocation_probes=16,latency_interpretation='Medians of independent process medians; per-process samples and dispersion preserved. Instrument p99 exploratory (50 expected exceedances); no p99.9 or fixed-arrival deadline claim.',first_use='Process-local first measured preparation/call after earlier calibration, not cold package startup',rate='Instrumented closed-loop completion rate includes histogram and loop overhead',allocation_scope='Process-wide GC byte counters include scheduled CUDA cleanup Timer; zero probes and net used device bytes do not establish absence of transient device allocations'),
 coverage=dict(expected_benchmark_processes=66,benchmark_processes=len(qualification_commands),passed_processes=sum(r['returncode']==0 for r in qualification_commands),failed_processes=sum(r['returncode']!=0 for r in qualification_commands),rejected_harness_attempts=len(rejected_attempts),canonical_builders=['model','high_accuracy'],kernel_patterns=14,geometric_workflows=5,geometric_scaling_cases=14,physical_pyramids=['gpi_default','gpi_fine','copper_default','copper_fast','copper_fine'],current_instruments=['GPI2:240/grid_gaussian','Classic:480/grid_gaussian'],unavailable='Full legacy Copper application benchmark requires AOS 0.2.1; current AOS Copper optical cases are included, no full Copper application claim'),
 allocation_diagnosis=dict(measured_bytes=288,profile_requested_bytes=272,clean_profile_records=1,clean_profile_steps=64,clean_profile_nonzero_steps=1,allocation_type='Base Memory{Any} in uvhandles IdDict rehash',stack='CUDACore one-second resource retirement Timer -> Base.Timer wait -> preserve_handle -> IdDict rehash',accounting='272 B requested plus an 8 B GC tag rounds to the 288 B charged pool class',separate_observation='First exploratory profile also found 16 B RefValue{Int64} in active resource-drain path; not the 288 B Timer event',clean_receipt='large-capture-warmed-profile.log.gz',notes='Existing allocation assertions preserved; no Timer suppression, GC disabling, runtime/source patch changes or production changes'),
 evidence=dict(prior_software_correctness='CUDA 6.4.2 and optionally patched CUDA 6.5.0 each passed 2089/2089 at the same AOS source; prior record 2026-10-27-cuda-resource-ownership.toml',physical_cross_stack_comparisons=len(parity),physical_cross_stack_all_bitwise_equal=all(r['bitwise_equal'] for r in parity),instrument_cross_stack_comparisons=len(instrument_parity),instrument_expected_comparisons=6,instrument_cross_stack_all_passed=all(r['passed'] for r in instrument_parity),observed_zero_host_probes=zero_observations,histograms_verified=48,raw_completed_samples_verified=240000,extension_sha256='07713339319f52486af862f638d508f79a18df1576b023c8ef062903c90f236b',cudacore_tree='f044e2795044ed9ed3d86fa529722346bff5d1a9',default_pins_changed=False,independent_review='Sol read-only methodology and allocation-source review; no timing-boundary blockers',receipt_directory=NAME),
 notes=['Initial histogram verifier subtracted mixed signed/unsigned values and underflowed. The corrected signed verifier passed all 48 histograms and 240000 samples; no histogram or timing data changed.','Candidate fine optical timings were not emitted because the unchanged allocation assertion stops before the timed phase.','Three initial instrument attempts used an unjustified exact cross-prepared Float32 rate oracle. The diagnostic measured 1.414e-7 relative L2, within the maintained 1e-3 criterion. Corrected harness, preserved initial failures, reran three jobs at end; no numerical kernel or allocation gate changed.','Two initial metadata probes used a nonexistent private preference name; corrected metadata retries preserved separately. These are not benchmark failures.','Three diagnostic pauses stopped only our Python scheduler after its active child finished. Wrapper elapsed_s for physical-copper_fine-baseline-1, physical-copper_default-baseline-2 and physical-gpi_default-baseline-2 includes waiting for diagnostics; inner sample timings remain the comparison.','Exploratory profiles with immutable return boxes and collector compilation retained; final warmed concrete no-return diagnostic has neither artifact.','Instrument data frozen from committed simulations source; unrelated uncommitted user changes excluded. Exact provenance and hashes retained.'])
TARGET.mkdir(parents=True,exist_ok=True)
files=[]
for p in BASE.iterdir():
 if p.is_file() and p.suffix in ('.jl','.py','.toml','.json','.jsonl','.log','.csv','.md','.f32','.u16','.txt'):files.append((p,p.name))
for env in ('baseline-environment','candidate-environment','baseline-instrument-environment','candidate-instrument-environment'):
 for name in ('Project.toml','Manifest.toml'):
  files.append((BASE/env/name,env+'/'+name))
for p,relative in files:
 dest=TARGET/(relative+'.gz');dest.parent.mkdir(parents=True,exist_ok=True)
 with dest.open('wb') as out:
  with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0) as z:z.write(p.read_bytes())
checksums={str(p.relative_to(TARGET)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(TARGET.rglob('*')) if p.is_file() and p.name!='SHA256SUMS'}
(TARGET/'SHA256SUMS').write_text(''.join(f'{v}  {k}\n' for k,v in checksums.items()))
report['evidence']['compressed_receipts']=len(checksums)
report['evidence']['receipt_bytes']=sum(p.stat().st_size for p in TARGET.rglob('*') if p.is_file())
# Simple TOML encoder, preserving Unicode text and flat numeric arrays.
def value(x):
 if isinstance(x,bool):return str(x).lower()
 if isinstance(x,str):return json.dumps(x,ensure_ascii=False)
 if isinstance(x,(int,float)):return repr(x)
 if isinstance(x,list):return '['+', '.join(value(v) for v in x)+']'
 raise TypeError(type(x))
lines=[]
for k,v in report.items():
 if not isinstance(v,dict):lines.append(f'{k} = {value(v)}')
for section,data in report.items():
 if not isinstance(data,dict):continue
 lines.append('\n['+section+']')
 for k,v in data.items():lines.append(f'{k} = {value(v)}')
for kind,rows in [('measurement',summary['rows']),('physical_parity',parity),('instrument_parity',instrument_parity),('instrument_interval',instrument_intervals)]:
 for row in rows:
  lines.append('\n[['+kind+']]')
  for k,v in row.items():lines.append(f'{k} = {value(v)}')
for r in qualification_commands:
 if r['returncode']==0:continue
 stem=f"{r['label']}-{r['stack']}-{r['repetition']}"
 first=next((line for line in (BASE/(stem+'.log')).read_text().splitlines() if line.startswith('ERROR:')), 'see raw log')
 lines.append('\n[[failed_benchmark]]')
 for k,v in dict(workload=r['label'],stack=r['stack'],repetition=r['repetition'],error=first,receipt=stem+'.log.gz').items():lines.append(f'{k} = {value(v)}')
path=TARGET.parent/(NAME+'.toml');path.write_text('\n'.join(lines)+'\n')
tomllib.loads(path.read_text())
print('Wrote',path,'receipts',len(checksums),'bytes',report['evidence']['receipt_bytes'],'zero probes',zero_observations)
