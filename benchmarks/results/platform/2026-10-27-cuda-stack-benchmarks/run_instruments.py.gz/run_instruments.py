import os, subprocess, json, time, datetime
from pathlib import Path
BASE=Path(__file__).resolve().parent
SOURCE=Path("/home/dgamroth/workspaces/codex/worktrees/aos-cuda-stack-benchmarks-20261027")
JULIA=["taskset","-c","2","julia","--startup-file=no","--threads=1,0","--gcthreads=1"]
ENV=dict(os.environ, OPENBLAS_NUM_THREADS="1", JULIA_NUM_THREADS="1", JULIA_PKG_PRECOMPILE_AUTO="0", AOS_BENCHMARK_ROOT=str(SOURCE), AOS_GPU_PATTERN_PROFILE="0", AOS_PROFILE_EXTERNAL="0")
def run(label, stack, rep, script, args=(),extra=None):
 stem=f"{label}-{stack}-{rep}"
 output=BASE/(stem+".toml")
 env=dict(ENV,AOS_RESULTS=str(output), AOS_GEOMETRIC_RESULTS=str(output), AOS_GEOMETRIC_SCALING_RESULTS=str(output),AOS_PROFILE_SAMPLES="128",AOS_PROFILE_WARMUPS="32")
 if extra:env.update(extra)
 argv=JULIA+["--project="+str(BASE/(stack+"-instrument-environment")),str(script)]+[str(a).replace("{OUTPUT}",str(output)) for a in args]
 # Refuse measurements alongside another compute client. Only read GPU state.
 clients=subprocess.check_output(["nvidia-smi","--query-compute-apps=pid,process_name","--format=csv,noheader"],text=True).strip()
 if clients:raise RuntimeError("GPU occupied before "+stem+": "+clients)
 record=dict(label=label,stack=stack,repetition=rep,command=argv,environment_overrides={k:v for k,v in env.items() if k.startswith("AOS_") or k in ("OPENBLAS_NUM_THREADS","JULIA_NUM_THREADS")},start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 print("START",stem,flush=True)
 started=time.monotonic()
 with (BASE/(stem+".log")).open("w") as log:
  result=subprocess.run(argv,env=env,cwd=SOURCE,stdout=log,stderr=subprocess.STDOUT)
 record.update(returncode=result.returncode,elapsed_s=time.monotonic()-started,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),output_exists=output.exists())
 with (BASE/"commands.jsonl").open("a") as f:f.write(json.dumps(record)+"\n")
 print("DONE",stem,"exit",result.returncode,"seconds",round(record["elapsed_s"],1),flush=True)
 # Preserve failures and continue remaining independent workloads.

# Serialize with the first campaign; never share the GPU with it.
while Path("/proc/1476815").exists():time.sleep(5)
for stack in ("baseline","candidate"):run("metadata-instruments",stack,0,BASE/"metadata.jl")
for rep in range(1,4):
 stacks=("baseline","candidate") if rep%2 else ("candidate","baseline")
 names=("gpi2","classic") if rep%2 else ("classic","gpi2")
 for name in names:
  definition=BASE/"instrument-data"/("revolt-classic" if name=="classic" else "gpi2")/"simulation/definition.yaml"
  for stack in stacks:
   run("instrument-"+name,stack,rep,BASE/"instrument_driver.jl",(name,definition))
print("INSTRUMENT CAMPAIGN COMPLETE",flush=True)
