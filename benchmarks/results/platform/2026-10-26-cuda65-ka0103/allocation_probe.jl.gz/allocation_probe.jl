using Test
import CUDA
using KernelAbstractions
using AdaptiveOpticsSim
using AdaptiveOpticsSim.Backends
using TOML
using Pkg

@kernel function probe_kernel!(out, input)
    i = @index(Global, Linear)
    @inbounds out[i] = muladd(input[i], 2.0f0, 1.0f0)
end

enqueue!(style, out, input) = Backends.launch_kernel_async!(
    style, probe_kernel!, out, input; ndrange=length(out))
complete!(style, out, input) = Backends.launch_kernel!(
    style, probe_kernel!, out, input; ndrange=length(out))
allocation_bytes(f, args...) = @allocated f(args...)
blocking_wait!(stream) = CUDA.synchronize(stream; blocking=true)
cooperative_wait!(stream) = CUDA.synchronize(stream; blocking=false)
function replay!(captured, context)
    Backends._launch_prepared_device_graph!(captured, context)
    Backends._synchronize_prepared_device_execution_context_blocking!(context)
    return nothing
end

function measure(f, args...; finish=()->nothing)
    for _ in 1:8
        f(args...)
        finish()
        allocation_bytes(f, args...)
        finish()
    end
    bytes = Int[]
    for _ in 1:32
        push!(bytes, allocation_bytes(f, args...))
        finish()
    end
    return bytes
end

function main(output_path)
    CUDA.functional() || error("functional CUDA device required")
    CUDA.allowscalar(false)
    CUDA.versioninfo()
    input = CUDA.CuArray(Float32.(1:256))
    out = similar(input)
    style = Backends.execution_style(out)
    stream = CUDA.stream()
    results = Dict{String,Any}(
        "julia" => string(VERSION),
        "cuda" => string(pkgversion(CUDA)),
        "ka" => string(pkgversion(KernelAbstractions)),
    )
    results["enqueue_bytes"] = measure(enqueue!, style, out, input;
        finish=()->blocking_wait!(stream))
    results["completed_launch_bytes"] = measure(complete!, style, out, input)
    results["blocking_wait_bytes"] = measure(blocking_wait!, stream)
    results["cooperative_wait_bytes"] = measure(cooperative_wait!, stream)
    @test Array(out) == 2 .* Float32.(1:256) .+ 1
    context = Backends._prepare_device_execution_context(out)
    addresses = (pointer(out), pointer(input))
    Backends._with_prepared_device_execution_context(context) do
        enqueue!(style, out, input)
        Backends._synchronize_prepared_device_execution_context_blocking!(context)
        captured = Backends._capture_prepared_device_graph(context) do
            enqueue!(style, out, input)
        end
        results["captured_replay_bytes"] = measure(replay!, captured, context)
        copyto!(input, Float32.(257:512))
        replay!(captured, context)
        @test Array(out) == 2 .* Float32.(257:512) .+ 1
        @test addresses == (pointer(out), pointer(input))
    end
    for (name, bytes) in sort!(collect(results); by=first)
        println(name, " = ", bytes)
    end
    open(output_path, "w") do io
        TOML.print(io, results)
    end
    @test all(iszero, results["captured_replay_bytes"])
    for (_, dependency) in Pkg.dependencies()
        dependency.name in ("CUDA", "CUDACore", "KernelAbstractions",
            "KernelInterface", "GPUCompiler", "GPUArrays") || continue
        println("SOURCE ", dependency.name, " ", dependency.version, " ",
            dependency.tree_hash, " ", dependency.source)
    end
end

if abspath(PROGRAM_FILE) == @__FILE__
    main(only(ARGS))
end
