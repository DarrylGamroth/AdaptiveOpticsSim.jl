include("allocation_probe.jl")
using Profile

launch_only!(captured, context) = Backends._launch_prepared_device_graph!(captured, context)
wait_only!(context) = Backends._synchronize_prepared_device_execution_context_blocking!(context)
query_only!(stream) = CUDA.isdone(stream)

function diagnose()
    CUDA.allowscalar(false)
    input = CUDA.ones(Float32, 256)
    out = similar(input)
    style = Backends.execution_style(out)
    context = Backends._prepare_device_execution_context(out)
    Backends._with_prepared_device_execution_context(context) do
        enqueue!(style, out, input)
        wait_only!(context)
        captured = Backends._capture_prepared_device_graph(context) do
            enqueue!(style, out, input)
        end
        for (label, operation, arguments) in (
            ("launch", launch_only!, (captured, context)),
            ("prepared_wait", wait_only!, (context,)),
            ("query", query_only!, (context.stream,)),
            ("blocking_wait", blocking_wait!, (context.stream,)),
            ("replay", replay!, (captured, context)),
        )
            bytes = measure(operation, arguments...; finish=()->wait_only!(context))
            println(label, " = ", bytes)
        end
        Profile.Allocs.clear()
        Profile.Allocs.@profile sample_rate=1.0 begin
            for _ in 1:8
                replay!(captured, context)
            end
        end
        for allocation in Profile.Allocs.fetch().allocs
            println("ALLOCATION ", allocation.size, " ", allocation.type)
            for frame in allocation.stacktrace
                occursin("/julia/", string(frame.file)) && continue
                println("  ", frame)
            end
        end
    end
end

diagnose()
