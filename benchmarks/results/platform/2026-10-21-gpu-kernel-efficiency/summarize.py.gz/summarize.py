import csv,gzip,hashlib,json,math,statistics,subprocess,tomllib,sqlite3
from pathlib import Path
root=Path('/tmp/aos-gpu-assessment-20261021')
repo=Path('/home/dgamroth/workspaces/codex/AdaptiveOpticsSim-gpu-assessment')
slug='2026-10-21-gpu-kernel-efficiency'
out=repo/'benchmarks/results/platform';rawdir=out/slug;rawdir.mkdir(exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def read(name):return tomllib.loads((root/name).read_text())
def metric(rows,name,unit=None):
 values=[r['Metric Value'] for r in rows if r['Metric Name']==name and(unit is None or r['Metric Unit']==unit)]
 if not values:return -1.0
 assert len(set(values))==1,(name,values)
 return float(values[0].replace(',',''))
def counters(prefix):
 rows=list(csv.DictReader((root/(prefix+'-details.csv')).open()))
 ids=sorted({r['ID'] for r in rows},key=int)
 entries=[]
 for i in ids:
  rs=[r for r in rows if r['ID']==i]
  e=dict(profile_id=int(i),kernel=rs[0]['Kernel Name'],duration_us=metric(rs,'Duration','us'),sm_throughput_percent=metric(rs,'Compute (SM) Throughput','%'),dram_throughput_percent=metric(rs,'DRAM Throughput','%'),achieved_occupancy_percent=metric(rs,'Achieved Occupancy','%'),registers_per_thread=metric(rs,'Registers Per Thread'),block_size=metric(rs,'Block Size'),grid_size=metric(rs,'Grid Size'))
  entries.append(e)
 return entries
pattern=read('patterns-baseline.toml');profiled=read('patterns-profiled.toml')
assert len(pattern['cases'])==len(profiled['cases'])==14
for c in pattern['cases']:
 assert len(c['event_seconds_per_operation'])==64 and c['workgroupsize']==[16,16]
 assert c['median_seconds']==statistics.median(c['event_seconds_per_operation'])
pattern_entries=counters('patterns');assert len(pattern_entries)==14
raw=list(csv.DictReader((root/'patterns-raw-metrics.csv').open()))
raw={int(r['ID']):r for r in raw if r['ID']}
for e,c in zip(pattern_entries,pattern['cases']):
 e.update(c)
 r=raw[e['profile_id']]
 val=lambda k:float(r[k].replace(',',''))
 req=val('l1tex__t_requests_pipe_lsu_mem_global_op_ld.sum')
 e['global_load_sectors_per_request']=val('l1tex__t_sectors_pipe_lsu_mem_global_op_ld.sum')/req if req else 0
 e['local_load_requests']=val('l1tex__t_requests_pipe_lsu_mem_local_op_ld.sum')
 del e['event_seconds_per_operation']
 e['case_dimensions']=e.pop('dimensions')
# Complete-workload timeline analysis uses unions rather than sums.
timelines=[]
traced=read('pyramid-traced.toml')
for i in range(1,5):
 conn=sqlite3.connect(root/f'pyramid.{i}.sqlite')
 api=list(conn.execute('select a.start,a.end,s.value from CUPTI_ACTIVITY_KIND_RUNTIME a join StringIds s on a.nameId=s.id order by a.start'))
 kernels=list(conn.execute('select a.start,a.end,s.value from CUPTI_ACTIVITY_KIND_KERNEL a join StringIds s on a.shortName=s.id order by a.start'))
 intervals=[]
 for a,b,n in kernels:
  if intervals and a<=intervals[-1][1]:intervals[-1][1]=max(b,intervals[-1][1])
  else:intervals.append([a,b])
 start=next(a for a,b,n in api if 'Launch' in n)
 end=max(max(b for a,b,n in kernels),max(b for a,b,n in api if 'Synchronize' in n))
 busy=sum(b-a for a,b in intervals)
 c=traced['case'][i-1]
 timelines.append(dict(resolution=c['resolution'],strategy=c['strategy'],steps=32,kernel_activities=len(kernels),kernel_active_union_ns=busy,traced_interval_ns=end-start,kernel_active_percent=100*busy/(end-start),kernel_active_us_per_step=busy/32/1000))
pyramid=[]
for index in range(4):
 baseline=[read(f'pyramid-final{i}.toml')['case'][index] for i in (1,2,3)]
 blocking=[read(f'pyramid-blocking{i}.toml')['case'][index] for i in (1,2,3)]
 for c in baseline+blocking:
  assert len(c['samples_ns'])==128 and sum(c['gc_collections'])==0
  assert c['p50_ns']==statistics.median(c['samples_ns'])
 e=dict(resolution=baseline[0]['resolution'],strategy=baseline[0]['strategy'],default_p50_us=[c['p50_ns']/1000 for c in baseline],blocking_p50_us=[c['p50_ns']/1000 for c in blocking],default_gc_bytes_range=[min(min(c['gc_bytes']) for c in baseline),max(max(c['gc_bytes']) for c in baseline)],blocking_gc_bytes_range=[min(min(c['gc_bytes']) for c in blocking),max(max(c['gc_bytes']) for c in blocking)],maximum_relative_cpu_error=max(c['relative_cpu_error'] for c in baseline+blocking),timed_gc_collections=0)
 pyramid.append(e)
# Experimental reassociation is deliberately not a production qualification.
boundary=read('boundary.toml')
be=[]
for c in boundary['cases']:
 assert len(c['blocks'])==16
 changes=[]
 for rnd in range(1,5):
  blocks=[b for b in c['blocks'] if b['round']==rnd]
  assert [b['variant'] for b in blocks]==['original','boundary','boundary','original']
  assert all(len(b['event_seconds_per_operation'])==64 for b in blocks)
  a=[statistics.median(b['event_seconds_per_operation']) for b in blocks if b['variant']=='original']
  b=[statistics.median(b['event_seconds_per_operation']) for b in blocks if b['variant']=='boundary']
  changes.append(math.exp(statistics.mean(map(math.log,a))-statistics.mean(map(math.log,b))))
 e={k:v for k,v in c.items() if k not in ('blocks','dimensions')}
 e['dimensions']=c['dimensions'];e['paired_geometric_speedup']=math.exp(statistics.mean(map(math.log,changes)))
 be.append(e)
source_files=['benchmarks/profile_gpu_kernel_patterns_cuda.jl','benchmarks/profile_pyramid_efficiency_cuda.jl','benchmarks/benchmark_geometric_slopes_boundary_cuda.jl','scripts/profile_pyramid_plant_runtime.jl','src/backends/arrays.jl','src/wfs/geometric_slopes.jl','src/optics/deformable_mirror.jl','src/wfs/pyramid/optics.jl','src/wfs/pyramid/setup.jl','src/atmosphere/multilayer.jl','src/detectors/interface.jl']
meta=dict(artifact_id='GPU-KERNEL-EFFICIENCY-RTX3080-2026-10-21',base_revision='50741bc95f5b8af2ee2947ef9504f11fbffe3aa3',objective='Assess execution architecture and representative GPU kernel patterns on RTX3080; no instrument-specific optimization or claim that all algorithms are optimal.',decision='Prioritize synchronization/completion policy and geometric-slopes work decomposition; retain production implementations pending scoped remediation and numerical qualification.',scope=dict(source_kernel_definitions=138,source_families='44 WFS,32 detector,23 optics,16 atmosphere,12 backend,5 core,3 tomography,2 algorithm-graph,1 calibration',measured='13 nodes from captured DM/SH/detector plant;14 synthetic production-launch kernel patterns;4 Pyramid strategy/size fixtures,3 fresh processes per wait policy;6 experimental slopes fixtures.',unmeasured='Not an exhaustive audit of every kernel/configuration. Stochastic RNG/Poisson, infinite-screen evolution, direction batching, cold covariance/tomography builds, full LiFT inverse, and complete Bi-O-edge/curvature/Zernike workflows lack new focused measurements. Shared pointwise/FFT patterns are not proof of their performance.',production_changes=False),environment=dict(gpu='NVIDIA GeForce RTX3080 sm86;68 SMs',driver='615.71.09',cuda_runtime='13.4.0',cuda_jl='6.4.2',kernel_abstractions='0.9.45',julia='1.13.2',cpu='AMD Ryzen7 6800H',affinity='Julia CPU2, one compute thread, zero interactive, one GC, OPENBLAS_NUM_THREADS=1',clocks='Uncontrolled system defaults; no changes to power,clock,driver or profiler access policy',manifest_sha256=sha((repo/'test/cuda/Manifest.toml').read_bytes())),method=dict(patterns='Production Backends.preferred_workgroupsize selected before execution:16x16 in all14 cases.64 CUDA event samples, each graph32 reset+kernel operations; per-operation times include reset and graph scheduling. One fresh process; diagnostic baseline, not regression gate.',pattern_oracle='CPU execution of same KA kernels; backend parity, input immutability and post-replay stability. Utility reduction also exact Float64 oracle. Not independent physical validation. All passed.',counters='NsightCompute2026.3.1; single warmed kernel occurrences; basic+Occupancy+SchedulerStats, plant MemoryWorkloadAnalysis, patterns MemoryWorkloadAnalysis_Tables. Replay/cache/clock perturbation: durations diagnostic, not production latency. Raw metric names and units retained; do not confuse Memory Throughput percent with Gbyte/s.',pyramid='Complete synchronized stream optics+noiseless acquisition,128 host time_ns samples after32 warmups perfixture; default vs process-local blocking synchronize_backend! specialization.3 fresh processes per policy, fixed default-then-blocking campaign and fixedcase order. No paired randomized causal estimate.',pyramid_oracle='Complete GPU frames compared to CPU for each strategy/size before and after. Stable CUDA.used_memory.0 timed GC collections. Caller OPD and physical algorithms unchanged.',blocking_scope='Benchmark-only more-specific Backends.synchronize_backend!(AcceleratorStyle{CUDA.CUDABackend}) invokes CUDA.synchronize(blocking=true). Changes every AOS synchronization call in that process while retaining boundaries/current-stream scope. Implicates synchronization policy and bookkeeping collectively, not scheduler-only causality. It changes Julia task cooperation and requires latency/concurrency qualification before adoption.',source_provenance='Pyramid trace preceded addition of outside-timer GC counters and opt-in blocking dispatch; default step helper and package kernels unchanged. Current retained driver hashes do not claim byte-identical driver source for the earlier trace.',timeline='NsightSystems2026.3.2, four cudaProfilerApi regions32 steps each. Kernel interval union divided by first host launch to final kernel/synchronization end. Profiler changed the slow unprofiled wait behavior; use only for GPU-work mix, not unprofiled latency. Printed profile wall time can include collection/flush.',boundary='Benchmark-only exact-real telescoping of ordinary unmasked-pixel finite differences, not edge-masked slopes.6 fixtures:3 shapes including sub1, each smooth/nonsmooth field and mixed validity masks;4 ABBA groups64 event samples/block,32 reset+kernel operations. Same production16x16 group. Numerical reassociation explicitly unqualified outside fixtures.',limitations='Synthetic bounded Float32 inputs; one hardware/software stack and shared host. No WCET/tail/deadline guarantees, no clock locking, no whole-application or cross-backend optimality claim. Blocking-policy campaign fixed order and CPU2 affinity can affect magnitude.'),commands=dict(common_environment='JULIA_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1; taskset -c 2; --threads=1,0 --gcthreads=1; apply to profiler commands too',pattern_baseline='JULIA_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 taskset -c 2 julia --startup-file=no --threads=1,0 --gcthreads=1 --project=test/cuda benchmarks/profile_gpu_kernel_patterns_cuda.jl /tmp/patterns.toml',pattern_counters='AOS_GPU_PATTERN_PROFILE=1 ncu --clock-control none --cache-control none --profile-from-start off --launch-count 40 --set basic --section Occupancy --section MemoryWorkloadAnalysis_Tables --section SchedulerStats --export /tmp/patterns julia --startup-file=no --threads=1,0 --gcthreads=1 --project=test/cuda benchmarks/profile_gpu_kernel_patterns_cuda.jl /tmp/patterns-profiled.toml',plant_counters='AOS_SH_OCCUPANCY_GROUP=default ncu --clock-control none --cache-control none --profile-from-start off --graph-profiling node --launch-count 13 --set basic --section Occupancy --section MemoryWorkloadAnalysis --section SchedulerStats --export /tmp/plant julia --startup-file=no --threads=1,0 --gcthreads=1 --project=test/cuda benchmarks/profile_sh_pupil_occupancy_cuda.jl cuda',pyramid_baseline='JULIA_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 AOS_PYRAMID_RESULTS=/tmp/pyramid.toml taskset -c 2 julia --startup-file=no --threads=1,0 --gcthreads=1 --project=test/cuda benchmarks/profile_pyramid_efficiency_cuda.jl',pyramid_blocking='Same command with AOS_PYRAMID_BLOCKING_SYNC=1, in a separate fresh process; repeat each policy3 times.',pyramid_timeline='AOS_PYRAMID_PROFILE=1 AOS_PYRAMID_RESULTS=/tmp/pyramid-traced.toml nsys profile --sample=none --cpuctxsw=none --trace=cuda,nvtx --cuda-graph-trace=node --capture-range=cudaProfilerApi --capture-range-end=repeat:4:defer --output=/tmp/pyramid julia --startup-file=no --threads=1,0 --gcthreads=1 --project=test/cuda benchmarks/profile_pyramid_efficiency_cuda.jl',boundary='JULIA_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 taskset -c 2 julia --startup-file=no --threads=1,0 --gcthreads=1 --project=test/cuda benchmarks/benchmark_geometric_slopes_boundary_cuda.jl /tmp/boundary.toml',counter_text='ncu --import <report>.ncu-repz --page details --csv; also --page raw --csv for metric identities/units',timeline_export='nsys export --type sqlite --output <report>.sqlite <report>.nsys-rep'),source_files_sha256={p:sha((repo/p).read_bytes()) for p in source_files},references=dict(ampere='https://docs.nvidia.com/cuda/archive/12.6.0/ampere-tuning-guide/index.html',cuda_julia='https://cuda.juliagpu.org/stable/tutorials/performance/'))
priorities=[dict(id='GPU-EFF-1',status='Observed synchronization-policy sensitivity',priority=1,evidence='N256 pupil-tilt default median about8ms vs blocking about405us in3 fresh processes/policy, CPU-parity frames,0GC. Trace has about350us device-kernel activity/step. Wait policy/bookkeeping dominates this baseline.',action='Preserve asynchronous composition and choose explicit completion policy for latency-sensitive prepared execution. Profile task cooperation/multithread affinity before changing defaults; do not select physical propagation strategy solely to avoid a wait artifact.',source='src/backends/arrays.jl:799; benchmarks/profile_pyramid_efficiency_cuda.jl'),dict(id='GPU-EFF-2',status='Observed sparse grid and expensive finite-difference loop',priority=2,evidence='Geometric slopes has4blocks for1024 outputs,39registers,under1% aggregate SM throughput; global loads about32sectors/request.16-to32pixels per subaperture increases measured kernel time75to527us.',action='Evaluate boundary-difference formulation for ordinary slopes and/or cooperative work per subaperture. Validate reassociation over adversarial/scientific OPDs and scales; edge-masked slopes require a different algorithm.',source='src/wfs/geometric_slopes.jl:1'),dict(id='GPU-EFF-3',status='Observed useful throughput; library comparison unmeasured',priority=3,evidence='Larger custom separable-DM right pass reaches79% SM throughput with64-term dot products. Grid capture uses custom dots; dense/measured native DMs already use retained-coefficient cuBLAS GEMV.',action='Compare captured custom separable passes against capture-safe prepared GEMM across shapes, including pupil-mask pass and workspace cost. Do not assume tensor cores/TF32 meet numerical policy.',source='src/optics/deformable_mirror.jl:66; src/optics/deformable_mirror.jl:1062'),dict(id='GPU-EFF-4',status='Observed bandwidth use and workload-size sensitivity',priority=4,evidence='cuFFT stages and abs2 achieve about70% DRAM throughput in plant sample;32-point Pyramid intensity reduction reaches86.8%. Moving-layer interpolation reaches67.7% SM throughput. Detector31tap rows/cols differ24.7vs15.1us in counters.',action='Prioritize bytes/work removed, batching, and stencil reuse over occupancy increases. Tiling/fusion alternatives remain hypotheses until benchmarked at the same output semantics.',source='src/wfs/pyramid/setup.jl:74; src/atmosphere/multilayer.jl:59; src/detectors/interface.jl:1644'),dict(id='GPU-EFF-5',status='Source observation and low-priority utility measurement',priority=5,evidence='Small copy/scale kernels have low compute utilization despite high occupancy. Scalar atomic masked_sum is slow in a utility fixture but has no production caller in this checkout. No local-memory load traffic observed in14 pattern samples.',action='Remove/fuse redundant data movement where bindings permit; do not optimize dormant utilities or rewrite every Int toInt32 on source appearance alone. Inspect generated code for measured targets.',source='src/backends/arrays.jl:744; src/backends/reductions.jl:2')]
rawnames=['patterns-baseline.toml','patterns-profiled.toml','patterns.ncu-repz','patterns-details.csv','patterns-raw-metrics.csv','plant.ncu-repz','plant-details.csv','plant-raw-metrics.csv','boundary.toml','pyramid-traced.toml']
rawnames += [f'pyramid-{policy}{i}.toml' for policy in ['final','blocking'] for i in (1,2,3)]
rawnames += [f'pyramid.{i}.nsys-rep' for i in range(1,5)] + ['summarize.py']
archives=[]
for name in rawnames:
 data=(root/name).read_bytes();compressed=gzip.compress(data,mtime=0);dest=rawdir/(name+'.gz');dest.write_bytes(compressed)
 archives.append(dict(path=str(dest.relative_to(repo)),sha256=sha(compressed),uncompressed_sha256=sha(data),uncompressed_bytes=len(data)))
# Archive the analysis script after it is fully written, for independent recomputation.
lines=[]
def key(k):return json.dumps(k) if any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-' for c in k) else k
def dump(table,prefix=''):
 for k,v in table.items():
  if not isinstance(v,dict):lines.append(key(k)+' = '+json.dumps(v))
 for k,v in table.items():
  if isinstance(v,dict):
   p=(prefix+'.' if prefix else '')+key(k);lines.extend(['','['+p+']']);dump(v,p)
def entry(name,table):
 # Nested fields in arrays need their owning array table as prefix.
 lines.extend(['','[['+name+']]']);dump(table,name)
dump(meta)
for e in priorities:entry('priority',e)
for e in pattern_entries:entry('kernel_pattern',e)
for e in counters('plant'):entry('plant_kernel',e)
for e in pyramid:entry('pyramid_wait_comparison',e)
for e in timelines:entry('pyramid_timeline',e)
for e in be:entry('boundary_experiment',e)
for e in archives:entry('raw_archive',e)
text='\n'.join(lines)+'\n';parsed=tomllib.loads(text)
assert len(parsed['kernel_pattern'])==14 and len(parsed['boundary_experiment'])==6
(out/(slug+'.toml')).write_text(text)
print('Persisted',len(archives),'archives,14patterns,13plantkernels,6boundaryfixtures')
for e in be:print(e['label'],'speedup',round(e['paired_geometric_speedup'],2),'maxdiff',e['boundary_vs_cpu_max_abs'])
