import os,subprocess,time
from pathlib import Path
r=Path('/tmp/aos-instrument-review-20261021');repo=Path('/home/dgamroth/workspaces/codex/AdaptiveOpticsSim-instrument-review');w=Path('/home/dgamroth/workspaces/codex/adaptive-optics-simulations')
for _ in range(240):
    s=(r/'campaign.log').read_text()
    if 'completed gpi2-profiled 0' in s:break
    if 'Traceback' in s:raise SystemExit('failed campaign')
    time.sleep(5)
else:raise SystemExit('campaign timeout')
common=['julia','--startup-file=no','--threads=1,0','--gcthreads=1']
env=dict(os.environ,JULIA_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
for name in ('classic','copper'):
    print('starting native',name,flush=True)
    args=['taskset','-c','2']+common+[f'--project={w}/environments/{name}',str(r/'inspect_native_graph.jl'),name]
    env['AOS_NATIVE_INSPECTION_RESULTS']=str(r/f'{name}-native.toml')
    with (r/f'{name}-native.log').open('w') as f:p=subprocess.run(args,cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT)
    print('completed native',name,p.returncode,flush=True)
    if p.returncode:raise SystemExit(p.returncode)
for name,kernel in [('classic','counter_poisson_noise_kernel'),('copper','regular_fft')]:
    print('starting counters',name,flush=True)
    args=['taskset','-c','2','/opt/nvidia/nsight-compute/2026.3.1/ncu','--clock-control','none','--cache-control','none','--profile-from-start','off','--target-processes','all','--kernel-name-base','demangled','--kernel-name',f'regex:{kernel}','--launch-count','1','--set','basic','--section','Occupancy','--section','SchedulerStats','--section','MemoryWorkloadAnalysis','--export',str(r/f'{name}-kernel'),'--force-overwrite']+common+[f'--project={w}/environments/{name}',str(repo/'benchmarks/profile_instrument_workspace_cuda.jl'),name]
    env.update(AOS_INSTRUMENT_RESULTS=str(r/f'{name}-counters.toml'),AOS_INSTRUMENT_PROFILE='1')
    with (r/f'{name}-counters.log').open('w') as f:p=subprocess.run(args,cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT)
    print('completed counters',name,p.returncode,flush=True)
    # Preserve access/tool failures as limitations rather than changing policy.
