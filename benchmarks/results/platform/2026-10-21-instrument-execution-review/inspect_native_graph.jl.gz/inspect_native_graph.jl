using AdaptiveOpticsSim
using AdaptiveOpticsSim.AlgorithmGraphs
import CUDA
using TOML
using LinearAlgebra
const INSTRUMENT = first(ARGS)
if INSTRUMENT == "classic"
    import REVOLTClassicSim
    const Instrument = REVOLTClassicSim
elseif INSTRUMENT == "copper"
    import REVOLTCopperSim
    const Instrument = REVOLTCopperSim
else
    error("only the admitted Classic/Copper graphs are inspected")
end
function graph_node_counts!(counts, graph)
    driver = CUDA.CUDACore
    count = Ref{Csize_t}(0)
    driver.cuGraphGetNodes(graph, C_NULL, count)
    nodes = Vector{driver.CUgraphNode}(undef, count[])
    driver.cuGraphGetNodes(graph, nodes, count)
    for node in nodes
        kind = Ref{driver.CUgraphNodeType}()
        driver.cuGraphNodeGetType(node, kind)
        label = string(kind[])
        counts[label] = get(counts, label, 0) + 1
        if kind[] == driver.CU_GRAPH_NODE_TYPE_GRAPH
            child = Ref{driver.CUgraph}(C_NULL)
            driver.cuGraphChildGraphNodeGetGraph(node, child)
            graph_node_counts!(counts, child[])
        end
    end
    return counts
end
function cycle!(boundary)
    seq = step_hil_frame!(boundary)
    adopt_hil_command!(boundary, seq)
    return nothing
end
function allocation_samples(system)
    for _ in 1:64
        cycle!(system.boundary)
    end
    return [@allocated(cycle!(system.boundary)) for _ in 1:16]
end
function main()
    CUDA.allowscalar(false)
    BLAS.set_num_threads(1)
    AdaptiveOpticsSim.Backends.set_fft_provider_threads!(1)
    target=AdaptiveOpticsSim.Backends.compute_device(CUDA.zeros(Float32,1))
    system=Instrument.prepare_hil_system(; target, execution=CapturedGraphExecution())
    counts=graph_node_counts!(Dict{String,Int}(),system.graph.execution.captured.graph)
    bytes=allocation_samples(system)
    open(ENV["AOS_NATIVE_INSPECTION_RESULTS"],"w") do io
        TOML.print(io,Dict("instrument"=>INSTRUMENT,"node_counts"=>counts,"hil_cycle_host_bytes"=>bytes))
    end
end
main()
