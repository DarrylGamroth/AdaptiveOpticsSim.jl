import os,subprocess
from pathlib import Path
r=Path('/tmp/aos-instrument-review-20261021');repo=Path('/home/dgamroth/workspaces/codex/AdaptiveOpticsSim-instrument-review');w=Path('/home/dgamroth/workspaces/codex/adaptive-optics-simulations')
common=['julia','--startup-file=no','--threads=1,0','--gcthreads=1']
env=dict(os.environ,JULIA_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
for name,kernel in [('copper','regular_fft')]:
    print('starting counters',name,flush=True)
    args=['taskset','-c','2','/opt/nvidia/nsight-compute/2026.3.1/ncu','--clock-control','none','--cache-control','none','--profile-from-start','off','--target-processes','all','--kernel-name-base','demangled','--kernel-name',f'regex:{kernel}','--launch-skip','1','--launch-count','1','--set','basic','--section','Occupancy','--section','SchedulerStats','--section','MemoryWorkloadAnalysis','--export',str(r/f'{name}-kernel'),'--force-overwrite']+common+[f'--project={w}/environments/{name}',str(repo/'benchmarks/profile_instrument_workspace_cuda.jl'),name]
    env.update(AOS_INSTRUMENT_RESULTS=str(r/f'{name}-counters.toml'),AOS_INSTRUMENT_PROFILE='1')
    with (r/f'{name}-counters.log').open('w') as f:p=subprocess.run(args,cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT)
    print('completed counters',name,p.returncode,flush=True)
    # Preserve access/tool failures as limitations rather than changing policy.
