import csv,gzip,hashlib,json,shutil,statistics,subprocess,tomllib
from pathlib import Path
r=Path('/tmp/aos-instrument-review-20261021')
repo=Path('/home/dgamroth/workspaces/codex/AdaptiveOpticsSim-instrument-review')
w=Path('/home/dgamroth/workspaces/codex/adaptive-optics-simulations')
slug='2026-10-21-instrument-execution-review'
base=repo/'benchmarks/results/platform';rawdir=base/slug;rawdir.mkdir(exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return tomllib.loads(p.read_text())
assert sha((repo/'benchmarks/profile_instrument_workspace_cuda.jl').read_bytes())==(r/'harness.sha256').read_text().strip()
assert 'completed gpi2-profiled 0' in (r/'campaign.log').read_text()
assert 'completed counters copper 0' in (r/'followup.log').read_text()
revisions={}
for label,folder in [('workspace',w),('aos_development',Path('/home/dgamroth/workspaces/codex/AdaptiveOpticsSim.jl')),('classic',w.parent/'REVOLTClassicSim.jl'),('copper',w.parent/'REVOLTCopperSim.jl'),('gpi2',w.parent/'GPI2Sim.jl'),('juliafiltergraph',w.parent/'pipewire/JuliaFilterGraph.jl'),('specula',w.parent/'SPECULA')]:
    revisions[label]=subprocess.check_output(['git','-C',str(folder),'rev-parse','HEAD'],text=True).strip()
models=[]
for name,period in [('classic',2000),('copper',2000),('gpi2',500)]:
    d=load(r/f'{name}.toml')
    m=load(w/f'environments/{name}/Manifest.toml')
    assert d['aos_version']=='0.2.1' and not d['profile']
    assert m['deps']['AdaptiveOpticsSim'][0]['git-tree-sha1']=='1a809e78c898ce01a58915b7f4fb71dc92d4711e'
    numerical=d['numerical'];assert numerical['frame_relative_l2_error']<1e-3 and numerical['rate_relative_l2_error']<1e-3
    entry=dict(name=name,model_period_us=period,manifest_sha256=sha((w/f'environments/{name}/Manifest.toml').read_bytes()),numerical=numerical,execution=d['execution'])
    for e in entry['execution']:
        for boundary in ('graph','hil_cycle'):
            s=e[boundary];assert s['p50_ns']==statistics.median(s['samples_ns'])
            assert len(s['samples_ns'])==32 and s['timed_gc_collections']==0
            assert s['device_used_bytes_before']==s['device_used_bytes_after']
        assert e['hil_cycle']['seeded_reset_reproducible']
        if e['policy']=='captured':assert e['graph']['host_bytes']==0 and e['captured_node_count']==5
    if name!='gpi2':
        assert numerical['captured_calibration_admitted']
        assert numerical['captured_frame_relative_l2_error']==numerical['captured_rate_relative_l2_error']==0
        native=load(r/f'{name}-native.toml')
        assert all('MEM_ALLOC' not in kind and 'MEM_FREE' not in kind for kind in native['node_counts'])
        assert native['hil_cycle_host_bytes']==[160]*16
        entry['native_inspection']=native
    else:
        assert not numerical['captured_calibration_admitted'] and 'command_routing' in d['capture_failure']['message']
        entry['capture_failure']=d['capture_failure']
    models.append(entry)
timelines=json.loads((r/'timeline-summary.json').read_text());assert len(timelines)==10
for t in timelines:
    if '_captured_' in t['region']:assert t['api_counts']['cuGraphLaunch']==64
    assert 0<t['kernel_active_percent']<=t['device_activity_percent']<=100
counters=[]
for name in ('classic','copper'):
    rows=list(csv.DictReader((r/f'{name}-counter-details.csv').open()))
    metrics={row['Metric Name']:row for row in rows if row['Metric Name']}
    chosen={key:dict(value=metrics[key]['Metric Value'],unit=metrics[key]['Metric Unit']) for key in ['Duration','Compute (SM) Throughput','DRAM Throughput','Theoretical Occupancy','Achieved Occupancy','Registers Per Thread','Grid Size','Block Size','Eligible Warps Per Scheduler']}
    if name=='copper': assert metrics['Grid Size']['Metric Value'].replace(',','')=='4096'
    counters.append(dict(instrument=name,kernel=rows[0]['Kernel Name'],matching_occurrence=2 if name=='copper' else 1,metrics=chosen))
meta=dict(artifact_id='INSTRUMENT-EXECUTION-SCIENCE-REVIEW-2026-10-21',scope='Review of unchanged current application environments and local instrument checkouts, not a production implementation change.',revisions=revisions,environment=dict(gpu='NVIDIA GeForce RTX 3080; sm_86; 68 SMs; 10 GiB',driver='615.71.09',julia='1.13.2',cuda='6.4.2',cuda_runtime='13.4.0',cuda_driver_api='13.4.0',manifest_generated_julia='1.12.7',kernel_abstractions='0.9.45',nsys='2026.3.2',ncu='2026.3.1',cpu='AMD Ryzen 7 6800H',threads='1 compute, 0 interactive, 1 GC; BLAS/FFT 1',affinity='Julia/profilers CPU 2; campaign passive monitor CPU 6',clocks='Uncontrolled defaults; shared host; no policy or permissions changed.',registered_aos_version='0.2.1',registered_aos_tree='1a809e78c898ce01a58915b7f4fb71dc92d4711e'),protocol=dict(workload='Default instrument atmosphere/noisy detector production graph, zero commands; no transport/RTC. Full-resolution noiseless calibration self-parity uses one deterministic OPD and sparse nonzero command probe.',timing='One fresh process per instrument; stream then captured when admitted; 32 warmups and 32 closed-loop time_ns samples per endpoint. Completed GPU graph outputs and completed host-frame/same-sequence zero-command adoption measured separately. No production tail/deadline or causal small-effect claim.',allocations='One warmed @allocated sample per timed endpoint. Classic/Copper captured HIL allocation confirmed by 16 additional samples in independent processes. Native graph node recursion checked for allocation/free nodes. Stable CUDA.used_memory alone is retained-memory evidence, not a device allocation measurement.',numerical='CPU/GPU full-resolution noiseless stream parity. Classic/Copper GPU stream versus captured deterministic frame and photon rate exactly matched for the probe. No noisy CPU/GPU equivalence or independent instrument scientific accuracy claim. Seeded reset tested separately in each production execution policy.',timeline='Separate fresh profiled process; two cudaProfilerApi ranges where capture admitted, otherwise one. Each includes 64 completed GPU graph frames and 64 complete HIL cycles, separated by NVTX ranges. Percentages are interval unions of kernel activities, or kernel+copy+memset activities, divided by enclosing NVTX range duration. Reset outside selected NVTX intervals. Not SM occupancy or unprofiled wall-time utilization.',counters='One occurrence per selected kernel in actual instrument stream execution: Classic photon Poisson first match, Copper dominant batched FFT second regular_fft match (first single forward FFT skipped). Nsight Compute replay, basic + Occupancy + SchedulerStats + MemoryWorkloadAnalysis; no clock/cache control. Diagnostic one-kernel metrics; replay durations are not service latency. No counter coverage of every GPU algorithm.',limitations='One shared GPU/software stack; uncontrolled clocks and fixed case order. Self-paced workload excludes RTC, PipeWire, queueing and external command arrival. Profile instrumentation perturbs waits/timings; use unprofiled samples for service times. Model cadence is not an achieved hardware execution rate. No physical bench or on-sky validation.',telemetry='Nominal 250 ms plus nvidia-smi query time; whole baseline/timeline campaign including compilation/warmup. Follow-up native inspections/counters are outside this telemetry window. No stable-clock claim.'),conclusions=dict(application='All scenario launchers default to stream execution; the workspace does not expose a captured-execution selector. Registered AOS dependency use preserved; recent development changes are not automatically deployed.',capture='Classic/Copper explicit capture admits five graph nodes and measured zero Julia bytes for GPU graph replay; native graph inspection finds kernels/memsets only. Complete captured HIL cycles allocate 160 Julia bytes repeatedly on this stack. GPI2 capture rejects at its custom command-routing owner; frame-layout owner also lacks qualification.',science='Declared mathematical conventions are consistent within reviewed scope. GPI2 normalized detector sampling is twice producer metadata; no present pixel-value effect. Known EM clipped-Gaussian approximation has +8.3315% conditional single-electron mean bias before read noise, not a measured frame-wide bias. Photon noise uses a rounded Gaussian approximation at means >=30. One atmosphere sample/exposure and fast Pyramid/quadrature settings require application convergence studies.',oracles='AOS has genuine pinned OOPAO component exports; SPECULA-targeted fixtures are regenerated through AOS, without independent SPECULA producer provenance. No complete-instrument independent SPECULA or measured-frame qualification was found. CPU/GPU self-parity is not an independent scientific oracle.',api='Prioritize GPI2 capture conformance, public immutable boundary metadata/needed semantic accessors, and retained first-failure diagnostics. Investigate failed-drain storage lifetime before implementing retention. Defer declaration macros and streaming/rejection semantics absent an instrument requirement.'),source_sha256={'benchmarks/profile_instrument_workspace_cuda.jl':sha((repo/'benchmarks/profile_instrument_workspace_cuda.jl').read_bytes())},references=dict(specula='https://github.com/ArcetriAdaptiveOptics/SPECULA',gpi_emccd='https://arxiv.org/abs/2410.01960'))
meta['independent_verification'] = dict(result='No implementation or evidence blocker in this bounded review.', scope='Independent source/science review and final artifact/profiling verification; reviewers performed no additional GPU runs.', checks='64 raw archive hashes/lengths; harness and manifest hashes; numerical records; endpoint medians/allocations; repeated HIL allocation and native nodes; ten timeline interval unions; selected NCU occurrence, launch geometry and metrics; interpretation qualifiers.')
for name in ('science-review.md','executor-review.md','evidence-inventory.md'):
    shutil.copyfile(r/name,rawdir/name)
paths=[r/f'{name}{suffix}' for name in ('classic','copper','gpi2') for suffix in ('.toml','.log','-profiled.toml','-profiled.log')]
paths += sorted(r.glob('*-timeline.*.nsys-rep'))+sorted(r.glob('*-kernels.csv'))
paths += [r/f'{name}{suffix}' for name in ('classic','copper') for suffix in ('-native.toml','-native.log','-counters.log','-counters.toml','-counter-details.csv','-counter-raw.csv','-kernel.ncu-repz')]
paths += [r/('copper-forward'+suffix) for suffix in ('-counter-details.csv','-counter-raw.csv','-kernel.ncu-repz','-counters.log','-counters.toml')]
paths += [r/'run_copper_batched_counters.py',r/'copper-batched-campaign.log']
paths += [r/name for name in ('run_review.py','run_followup.py','summarize_timeline.py','inspect_native_graph.jl','persist_review.py','harness.sha256','runtime.log','telemetry.csv','campaign.log','followup.log','science-review.md','executor-review.md','evidence-inventory.md')]
archives=[]
for p in paths:
    data=p.read_bytes();packed=gzip.compress(data,mtime=0);dest=rawdir/(p.name+'.gz');dest.write_bytes(packed)
    archives.append(dict(path=str(dest.relative_to(repo)),sha256=sha(packed),uncompressed_sha256=sha(data),uncompressed_bytes=len(data)))
for name in ('classic','copper','gpi2'):
    p=w/f'environments/{name}/Manifest.toml';data=p.read_bytes();packed=gzip.compress(data,mtime=0);dest=rawdir/f'{name}-Manifest.toml.gz';dest.write_bytes(packed)
    archives.append(dict(path=str(dest.relative_to(repo)),sha256=sha(packed),uncompressed_sha256=sha(data),uncompressed_bytes=len(data)))
lines=[]
def key(k):return json.dumps(k,ensure_ascii=False) if any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-' for c in k) else k
def dump(table,prefix=''):
    for k,v in table.items():
        if not isinstance(v,dict) and not (isinstance(v,list) and v and isinstance(v[0],dict)):
            lines.append(key(k)+' = '+json.dumps(v,ensure_ascii=False))
    for k,v in table.items():
        path=(prefix+'.' if prefix else '')+key(k)
        if isinstance(v,dict):lines.extend(['','['+path+']']);dump(v,path)
        elif isinstance(v,list) and v and isinstance(v[0],dict):
            for e in v:lines.extend(['','[['+path+']]']);dump(e,path)
dump(meta)
for name,entries in [('instrument',models),('timeline',timelines),('counter',counters),('raw_archive',archives)]:
    for e in entries:lines.extend(['','[['+name+']]']);dump(e,name)
text='\n'.join(lines)+'\n';tomllib.loads(text);(base/(slug+'.toml')).write_text(text)
print('Archived',len(archives),'files; model/counter/timeline arithmetic and allocation checks passed.')
