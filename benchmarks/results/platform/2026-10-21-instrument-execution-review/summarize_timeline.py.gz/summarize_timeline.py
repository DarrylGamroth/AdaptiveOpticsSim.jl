import collections,csv,json,sqlite3,subprocess
from pathlib import Path
root=Path('/tmp/aos-instrument-review-20261021')
def union_duration(intervals):
    merged=[]
    for a,b in sorted(intervals):
        if merged and a<=merged[-1][1]:merged[-1][1]=max(b,merged[-1][1])
        else:merged.append([a,b])
    return sum(b-a for a,b in merged)
results=[]
for report in sorted(root.glob('*-timeline.*.nsys-rep')):
    db=report.with_suffix('.sqlite')
    subprocess.run(['nsys','export','--type','sqlite','--force-overwrite=true','--output',str(db),str(report)],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,check=True)
    c=sqlite3.connect(db)
    tables={r[0] for r in c.execute("select name from sqlite_master where type='table'")}
    strings=dict(c.execute('select id,value from StringIds'))
    kernels=[dict(zip(('start','end','name','stream','grid_x','grid_y','grid_z','block_x','block_y','block_z'),r)) for r in c.execute('select start,end,shortName,streamId,gridX,gridY,gridZ,blockX,blockY,blockZ from CUPTI_ACTIVITY_KIND_KERNEL')]
    apis=[(a,b,strings[n]) for a,b,n in c.execute('select start,end,nameId from CUPTI_ACTIVITY_KIND_RUNTIME')]
    copies=list(c.execute('select start,end,bytes,copyKind from CUPTI_ACTIVITY_KIND_MEMCPY')) if 'CUPTI_ACTIVITY_KIND_MEMCPY' in tables else []
    memset=list(c.execute('select start,end from CUPTI_ACTIVITY_KIND_MEMSET')) if 'CUPTI_ACTIVITY_KIND_MEMSET' in tables else []
    for start,end,text,textid in c.execute('select start,end,text,textId from NVTX_EVENTS where end is not null'):
        label=text or strings.get(textid,'')
        if not label.endswith(('_graph','_hil_cycle')):continue
        ks=[k for k in kernels if start<=k['start'] and k['end']<=end]
        cp=[(a,b,size,kind) for a,b,size,kind in copies if start<=a and b<=end]
        ms=[(a,b) for a,b in memset if start<=a and b<=end]
        api=[(a,b,n) for a,b,n in apis if start<=a and b<=end]
        counts=collections.Counter(n for a,b,n in api)
        active=union_duration([(k['start'],k['end']) for k in ks])
        device=union_duration([(k['start'],k['end']) for k in ks]+[(a,b) for a,b,_,_ in cp]+ms)
        byname=collections.Counter()
        for k in ks:byname[strings[k['name']]]+=k['end']-k['start']
        result=dict(region=label,report=report.name,frames=64,interval_ns=end-start,kernel_active_percent=100*active/(end-start),device_activity_percent=100*device/(end-start),kernel_count=len(ks),api_counts=dict(counts),copy_bytes_by_kind={str(kind):sum(size for a,b,size,k in cp if k==kind) for kind in {k for a,b,s,k in cp}},top_kernels=[dict(name=n,total_ns=t,percent_summed_kernel_time=100*t/sum(byname.values())) for n,t in byname.most_common(10)])
        results.append(result)
        with (root/(label+'-kernels.csv')).open('w') as f:
            w=csv.writer(f);w.writerow(['start_ns','end_ns','stream','name','grid_x','grid_y','grid_z','block_x','block_y','block_z'])
            for k in sorted(ks,key=lambda k:k['start']):w.writerow([k['start'],k['end'],k['stream'],strings[k['name']],k['grid_x'],k['grid_y'],k['grid_z'],k['block_x'],k['block_y'],k['block_z']])
        print(label, 'kernel active %',round(result['kernel_active_percent'],2),'device active %',round(result['device_activity_percent'],2),'graph launches',counts['cuGraphLaunch'],'top',result['top_kernels'][:2])
    c.close()
(root/'timeline-summary.json').write_text(json.dumps(results,indent=2)+'\n')
