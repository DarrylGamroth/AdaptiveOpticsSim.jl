import os,subprocess,hashlib,time,csv,threading
from pathlib import Path
root=Path('/tmp/aos-instrument-review-20261021')
repo=Path('/home/dgamroth/workspaces/codex/AdaptiveOpticsSim-instrument-review')
workspace=Path('/home/dgamroth/workspaces/codex/adaptive-optics-simulations')
driver=repo/'benchmarks/profile_instrument_workspace_cuda.jl'
(root/'harness.sha256').write_text(hashlib.sha256(driver.read_bytes()).hexdigest()+'\n')
stop=threading.Event()
def monitor():
    os.sched_setaffinity(0,{6})
    with (root/'telemetry.csv').open('w') as f:
        w=csv.writer(f);w.writerow(['begin_ns','end_ns','sm_mhz','memory_mhz','pstate','temperature_c','power_w'])
        while not stop.is_set():
            a=time.monotonic_ns()
            p=subprocess.run(['nvidia-smi','--query-gpu=clocks.current.sm,clocks.current.memory,pstate,temperature.gpu,power.draw','--format=csv,noheader,nounits'],capture_output=True,text=True)
            b=time.monotonic_ns()
            if p.returncode==0:w.writerow([a,b]+[s.strip() for s in p.stdout.strip().split(',')]);f.flush()
            stop.wait(.25)
t=threading.Thread(target=monitor);t.start()
try:
    for profile in (False,True):
        for name in ('classic','copper','gpi2'):
            label=name+('-profiled' if profile else '')
            env=dict(os.environ,JULIA_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',AOS_INSTRUMENT_RESULTS=str(root/f'{label}.toml'),AOS_INSTRUMENT_PROFILE=str(int(profile)))
            cmd=['taskset','-c','2']
            if profile:cmd+=['nsys','profile','--sample=none','--cpuctxsw=none','--trace=cuda,nvtx','--cuda-graph-trace=node','--capture-range=cudaProfilerApi','--capture-range-end=repeat:2:defer',f'--output={root}/{name}-timeline','--force-overwrite=true']
            cmd+=['julia','--startup-file=no','--threads=1,0','--gcthreads=1',f'--project={workspace}/environments/{name}',str(driver),name]
            print('starting',label,flush=True)
            with (root/f'{label}.log').open('w') as f:p=subprocess.run(cmd,cwd=workspace,env=env,stdout=f,stderr=subprocess.STDOUT)
            print('completed',label,p.returncode,flush=True)
            if p.returncode:raise SystemExit(p.returncode)
finally:
    stop.set();t.join()
