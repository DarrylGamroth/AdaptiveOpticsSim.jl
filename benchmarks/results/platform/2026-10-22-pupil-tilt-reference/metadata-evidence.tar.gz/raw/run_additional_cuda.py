exec(open('/home/dgamroth/workspaces/codex/aos-pupil-tilt-evidence/run_cuda.py').read().split("for name in ('modulation_batches'")[0])
run('gpi-package-cuda','gpi-env',root/'GPI2Sim-pupil-tilt/test/cuda/runtests.jl')
run('gpi-complete-loop-cuda','gpi-env',root/'GPI2Sim-pupil-tilt/benchmarks/test_gpi_closed_loop_cuda.jl')
