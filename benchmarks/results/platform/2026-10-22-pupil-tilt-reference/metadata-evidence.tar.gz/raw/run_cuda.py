import subprocess, os, json, time
from pathlib import Path
root=Path('/home/dgamroth/workspaces/codex'); evi=root/'aos-pupil-tilt-evidence'; aos=root/'AdaptiveOpticsSim-batches'
env=os.environ.copy();env.update(JULIA_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
def run(label,project,script,args=(),extra=None):
 e=env.copy();e.update(extra or {})
 cmd=['taskset','-c','2','julia','--startup-file=no','--project='+str(evi/project),str(script),*map(str,args)]
 with (evi/'commands.jsonl').open('a') as f:f.write(json.dumps(dict(label=label,command=cmd,extra=extra,time=time.time()))+'\n')
 print('START',label,flush=True)
 with (evi/(label+'.log')).open('w') as f:subprocess.run(cmd,env=e,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',label,flush=True)
for name in ('modulation_batches','modulation_storage','modulation_batch_policy'):
 run(name,'gpi-env',aos/('test/cuda/'+name+'.jl'))
run('external-physical','gpi-env',aos/'benchmarks/oopao_modulation_batches/aos.jl',[root/'aos-batch-oracle'],dict(AOS_ORACLE_BACKEND='cuda',AOS_ORACLE_PRECISION='Float32',AOS_ORACLE_CASES='n120_p30_m3',AOS_ORACLE_PREFIX='cuda_f32_physical_after_removal'))
run('copper-before','copper-env',aos/'benchmarks/validate_physical_pyramid_copper_cuda.jl',[root/'REVOLTCopperSim-pupil-tilt',evi/'copper-before'],dict(AOS_BATCH_VALIDATION_POLICY='baseline'))
run('copper-after','copper-env',aos/'benchmarks/validate_physical_pyramid_copper_cuda.jl',[root/'REVOLTCopperSim-pupil-tilt',evi/'copper-after',evi/'copper-before'])
run('gpi-before','gpi-env',root/'GPI2Sim-pupil-tilt/benchmarks/gpi_closed_loop_cuda.jl',[evi/'gpi-before'],dict(GPI_LOOP_CASES='default'))
run('gpi-after','gpi-env',root/'GPI2Sim-pupil-tilt/benchmarks/gpi_closed_loop_cuda.jl',[evi/'gpi-after'],dict(GPI_LOOP_CASES='default,fine,transfer'))
for mode in ('default','fast','accurate'):
 run('copper-mode-'+mode,'copper-env',root/'REVOLTCopperSim-pupil-tilt/benchmarks/copper_modes_cuda.jl',[evi/('copper-mode-'+mode+'.toml')],dict(COPPER_MODES=mode))
