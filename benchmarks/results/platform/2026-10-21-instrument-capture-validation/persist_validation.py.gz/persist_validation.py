import gzip, hashlib, json, shutil, subprocess, tomllib, statistics
from pathlib import Path
base=Path('/tmp/aos-hil-capture-20261021')
aos=Path('/home/dgamroth/workspaces/codex/AdaptiveOpticsSim-hil-capture')
output=aos/'benchmarks/results/platform/2026-10-21-instrument-capture-validation'
output.mkdir(exist_ok=True)
results={}
for name in ('classic','copper','gpi2'):
    results[name]={}
    for variant in ('before','after'):
        runs=[]
        for rep in range(1,4):
            path=base/f'{name}-{variant}-{rep}.toml'
            d=tomllib.loads(path.read_text())
            assert len(d['execution'])==2 and d['numerical']['captured_calibration_admitted']
            assert d['profile'] is False and d['execution'][0]['policy']=='stream'
            assert d['numerical']['captured_frame_relative_l2_error']==0
            assert d['numerical']['captured_rate_relative_l2_error']==0
            cap=d['execution'][1]
            assert cap['policy']=='captured'
            assert cap['graph']['allocation_samples']==[0]*16
            expected=0 if variant=='after' else 160
            assert cap['hil_cycle']['allocation_samples']==[expected]*16
            for e in d['execution']:
                assert e['hil_cycle']['seeded_reset_reproducible'] is True
                for endpoint in ('graph','hil_cycle'):
                    assert len(e[endpoint]['samples_ns'])==128
                    assert statistics.median(e[endpoint]['samples_ns'])==e[endpoint]['p50_ns']
                    assert e[endpoint]['timed_gc_collections']==0
                    assert e[endpoint]['device_used_bytes_before']==e[endpoint]['device_used_bytes_after']
            runs.append(d)
        results[name][variant]=runs

def revision(path):
    return subprocess.check_output(['git','rev-parse','HEAD'],cwd=path,text=True).strip()
revisions={n:revision(p) for n,p in {
    'aos':aos,'gpi2':'/home/dgamroth/workspaces/codex/GPI2Sim-capture',
    'launchers':'/home/dgamroth/workspaces/codex/worktrees/explicit-execution-policy-20261021',
    'classic':'/home/dgamroth/workspaces/codex/REVOLTClassicSim.jl',
    'copper':'/home/dgamroth/workspaces/codex/REVOLTCopperSim.jl'}.items()}
application_manifest_hashes={}
for name in ('classic','copper','gpi2'):
    current=Path(f'/home/dgamroth/workspaces/codex/adaptive-optics-simulations/environments/{name}/Manifest.toml').read_bytes()
    prior=gzip.decompress((aos/f'benchmarks/results/platform/2026-10-21-instrument-execution-review/{name}-Manifest.toml.gz').read_bytes())
    assert current==prior
    application_manifest_hashes[name]=hashlib.sha256(current).hexdigest()
for name,policy in [('classic','CapturedGraphExecution'),('copper','CapturedGraphExecution'),('gpi2','StreamGraphExecution'),('gpi2-captured','CapturedGraphExecution')]:
    assert f'execution={policy}' in (base/f'launcher-{name}.log').read_text()
metadata={'application_manifest_hashes_unchanged':application_manifest_hashes,'revisions':revisions,'baseline_aos_base':'7af2555a40540f8fce2c7bc3e9929d659c16321b',
'baseline_modal_patch_sha256':hashlib.sha256((base/'modal-baseline.patch').read_bytes()).hexdigest(),
'harness_sha256':hashlib.sha256((aos/'benchmarks/profile_instrument_workspace_cuda.jl').read_bytes()).hexdigest(),
'command':'python3 run_benchmarks.py; python3 check_launchers.py',
'system':subprocess.check_output(['uname','-a'],text=True).strip(),
'cpu':subprocess.check_output(['lscpu'],text=True),
'device':subprocess.check_output(['nvidia-smi','--query-gpu=name,driver_version','--format=csv,noheader'],text=True).strip()}
(base/'provenance.json').write_text(json.dumps(metadata,indent=2)+'\n')
files=list(base.glob('*-before-*.toml'))+list(base.glob('*-after-*.toml'))+list(base.glob('*-before-*.log'))+list(base.glob('*-after-*.log'))
files += [base/name for name in ('independent-review.txt','capture-tests.log','gpi-cuda.log','aos-cpu-pkg.log','modal-cpu-results.log','gpi-metadata-before-after.log','allocations-before.log','allocations-after.log','profile_allocations.jl','modal-baseline.patch','run_benchmarks.py','check_launchers.py','persist_validation.py','gpi2-captured.toml','provenance.json','benchmarks.log','launcher-policy.log')]
files += list(base.glob('launcher-*.log'))
for p in set(files):
    if p.exists(): (output/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for name in ('classic','copper','gpi2'):
    for variant,folder in [('after','app'),('before','before')]:
        for file in ('Project.toml','Manifest.toml'):
            p=base/f'{folder}-{name}'/file
            (output/f'{name}-{variant}-{file}.gz').write_bytes(gzip.compress(p.read_bytes(),mtime=0))
lines=['# Instrument CUDA capture and HIL validation','',
'2026-10-21. Follow-up to the [instrument execution review](2026-10-21-instrument-execution-review.md). This campaign validates implementation changes on the local RTX 3080; no physical coefficients, controller gains, sampling grids or model algorithms were changed.','',
'## Changes','',
'- GPI detector metadata now matches the pyramid product: normalized pupil sampling 1/60. The cell-integrated photon-rate array is shared unchanged; no resampling or scaling was introduced.',
'- GPI routing and frame-layout owners qualify their retained CUDA bindings for capture. Native modal OPD expansion enqueues its existing kernel asynchronously in prepared graphs. Public `combine_basis!` remains synchronous.',
'- CUDA HIL device-to-host staging queues the packed device-array copy on the retained stream, preserves both buffers through the final completion wait, and publishes afterward. Other storage kinds keep ordinary copy behavior. This removes two redundant CUDA cooperative waits and their 160 warmed host bytes.',
'- Launchers select actual `StreamGraphExecution()` or `CapturedGraphExecution()` objects from `execution = "stream" | "captured"`; omitted selection is stream. CPU capture is rejected. Classic/Copper scenarios select capture. GPI stays stream until a registered AOS 0.2.2 release can replace the application pin. SPIDERS stays stream.','',
'## Local verification','',
'- CPU: `algorithm-graphs` 559/559; `ka-cpu` 993/993; GPI package 103/103; launcher configuration 18/18.',
'- CUDA: HIL copies/modal edges/storage admission/workspace/waits 104/104; GPI ownership/routing/conversion/full-graph parity/reset 150/150. Reduced GPI regressions use 60² pupils with 4/8 modulation points; the performance campaign below independently uses each full-size default model.',
'- HIL and calibration tests cover Float32/Float64, nonzero command adoption, invalid-command rejection, reset storage addresses, host visibility, alternate producer streams, caller stream/context restoration, empty and wrong-shaped buffers, and HostMemory fallback. Modal tests cover cancellation, masked cells, NaN/Inf, and zero-mode kernel handling.',
'- GPI checks cover all command regions, shifted registration, changed commands, conversion with/without ADU calibration, negative/fractional/clipped values, poisoned padding, and evolving atmosphere/detector RNG reset.',
'- Actual CUDA launchers passed `--check`: Classic/Copper captured, GPI default stream and explicit captured override. No transport connection or RTC process was started.',
'- Independent source review found no blocker in the modal path, copy lifetime/ordering, or GPI traits. Hardware qualification here is CUDA only. The pre-existing scalar-CPU versus GPU nonfinite mask convention is not changed or claimed equal.',
'- Fail-before metadata assertion and HIL allocation profile, plus pass-after evidence, are archived. Worker console summaries are labelled as summaries; process logs are preserved where captured.','',
'## Measurement method','',
'Julia 1.13.2, CUDA 6.4.2, KernelAbstractions 0.9.45; RTX 3080, driver '+metadata['device'].split(',')[-1].strip()+'. One compute thread, no interactive pool, one GC thread, CPU 2 affinity, BLAS/FFT one thread. Shared host and uncontrolled GPU clocks. No profiler ran during timing.',
'',
'Three fresh processes per instrument and source variant; 32 warmups, 16 allocation samples and 128 completed-operation timing samples per endpoint. Instrument order and before/after order reverse in round two. Within a process stream precedes capture. Values are medians of the three process medians; ranges show those process medians. This is closed-loop service cost, without offered-rate scheduling, transport, RTC, queueing, or a deadline/tail-latency claim.',
'',
'The controlled **before-copy** source is AOS `7af2555a` plus the archived modal async patch, using the same fixed GPI nodes/metadata as after. It admits GPI capture and isolates only the HIL copy change. It is not the registered 0.2.1 baseline from the earlier review. Application environments were not modified: private environments under `/tmp` used local AOS/GPI sources; their exact projects/manifests and the patch are archived.',
'',
'## Full-size after-change results','',
'| Model | Stream graph µs | Captured graph µs | Stream HIL µs | Captured HIL µs (run range) | Captured HIL bytes |',
'|---|---:|---:|---:|---:|---:|']
for name in results:
    runs=results[name]['after']
    def vals(policy,endpoint): return [d['execution'][policy][endpoint]['p50_ns']/1000 for d in runs]
    med=lambda values:statistics.median(values)
    h=vals(1,'hil_cycle')
    lines.append(f'| {name} | {med(vals(0,"graph")):.1f} | {med(vals(1,"graph")):.1f} | {med(vals(0,"hil_cycle")):.1f} | {med(h):.1f} ({min(h):.1f}–{max(h):.1f}) | 0 |')
lines += ['', 'Captured graph replay and complete captured HIL cycles measured zero host bytes in all 48 allocation samples per instrument and endpoint. Every capture passed the recursive allocation/free-node admission guard. Retained device-used memory was unchanged across each timing interval, and no timed sample collected GC. These checks cover these exact graphs, not arbitrary storage types or transport.', '',
'### Isolated HIL-copy comparison','',
'| Model | Before-copy captured HIL µs (run range) | After-copy captured HIL µs (run range) | Host bytes before → after |','|---|---:|---:|---:|']
for name in results:
    def summary(variant):
        values=[d['execution'][1]['hil_cycle']['p50_ns']/1000 for d in results[name][variant]]
        return f"{statistics.median(values):.1f} ({min(values):.1f}–{max(values):.1f})"
    lines.append(f'| {name} | {summary("before")} | {summary("after")} | 160 → 0 |')
lines += ['', 'The allocation removal is demonstrated. Timing differences must be interpreted against the run ranges and shared-host variability; the copy change does not establish a broad throughput gain.', '',
'## Workload comparison','',
'Derived from the unchanged instrument parameters and pyramid padding rule: Copper has a 480² pupil, 30 pupil samples, 32 modulation points, separation 2 and edge 1. Its padded FFT side is (2×30 + 2 + 2×1)×480/30 = 1024. GPI has a 240² pupil, 60 pupil samples, 24 modulation points, separation 60 and edge 30; its side is (2×60 +60 +2×30)×240/60 = 960. Copper therefore has about 1.52× as many batched FFT elements (32×1024² versus 24×960²). Pupil-grid size alone does not describe FFT cost. This workload difference supports the observed ordering; it does not by itself establish relative implementation efficiency.', '',
'Copper samples its pupil at 16 grid pixels per detector pupil sample versus 4 for GPI. The instrument fixes 480 in its current preset; this review found no convergence evidence establishing that 480 is necessary. Reducing that sampling changes numerical discretization and needs an optical convergence study against matched physical inputs and a finer reference, including photon rates, slopes and calibration response. The 32-point modulation quadrature is likewise an accuracy/performance parameter to test against a finer angular reference, rather than assume mandatory. It was not done here. Measured numerical error should constrain the grid and quadrature choices in that follow-up.', '',
'## Numerical parity and limits','',
'| Model | Pupil | Maximum CPU/CUDA frame relative L2 | Maximum CPU/CUDA rate relative L2 | Stream/captured frame and rate relative L2 |',
'|---|---:|---:|---:|---:|']
for name in results:
    ns=[d['numerical'] for v in results[name].values() for d in v]
    lines.append(f'| {name} | {ns[0]["pupil_resolution"]}² | {max(n["frame_relative_l2_error"] for n in ns):.3g} | {max(n["rate_relative_l2_error"] for n in ns):.3g} | 0 / 0 |')
lines += ['', 'The full-resolution noiseless deterministic OPD/command probe matched stream and captured frames/rates exactly. This is an implementation parity oracle against matching CPU code, not an independent SPECULA, optical-bench, detector-statistics or closed-loop validation. The physical-model limitations from the earlier review remain. Model cadence, peak SM utilization, occupancy and external RTC latency are not established by these service-time samples.', '',
'## Reproduction and delivery','',
'Raw samples, allocation traces, logs, private project/manifests, commands and provenance are in [the evidence directory](2026-10-21-instrument-capture-validation/). The maintained harness is `benchmarks/profile_instrument_workspace_cuda.jl`; it takes `classic`, `copper`, or `gpi2`, `AOS_INSTRUMENT_RESULTS`, and optional `AOS_INSTRUMENT_SAMPLES`. Use one appropriate instrument environment per process. Local validation source overrides belong outside registered application environments.', '',
'Production changes validated by this campaign:', '']
for name,rev in revisions.items(): lines.append(f'- {name}: `{rev}`')
lines += ['', 'Registered application AOS/HIL pins remain unchanged. Full GPI capture and zero-allocation captured HIL staging require publishing the AOS changes and then updating the application AOS pin; no release or deployment was performed. Launcher `--check` prepares without connecting to PipeWire or starting an RTC.', '']
(aos/'benchmarks/results/platform/2026-10-21-instrument-capture-validation.md').write_text('\n'.join(lines))
print('Persisted verified results and evidence')
