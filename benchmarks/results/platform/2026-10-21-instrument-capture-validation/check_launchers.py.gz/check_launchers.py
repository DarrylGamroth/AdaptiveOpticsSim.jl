import subprocess, os
from pathlib import Path
base=Path('/tmp/aos-hil-capture-20261021')
workspace=Path('/home/dgamroth/workspaces/codex/worktrees/explicit-execution-policy-20261021')
env=dict(os.environ,JULIA_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
for name in ('classic','copper','gpi2'):
    scenario=workspace/'scenarios'/f'{name}.toml'
    cmd=['taskset','-c','2','julia','--startup-file=no','--threads=1,0','--gcthreads=1',f'--project={base}/app-{name}',str(workspace/'scripts/run.jl'),str(scenario),'--check']
    with (base/f'launcher-{name}.log').open('w') as log:
        subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    if name=='gpi2':
        cmd[-2]=str(base/'gpi2-captured.toml')
        with (base/'launcher-gpi2-captured.log').open('w') as log:
            subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
