import os, subprocess
from pathlib import Path
base=Path('/tmp/aos-hil-capture-20261021')
source=Path('/home/dgamroth/workspaces/codex/AdaptiveOpticsSim-hil-capture')
for repetition in range(1,4):
    names=('classic','copper','gpi2') if repetition % 2 else ('gpi2','copper','classic')
    variants=('before','after') if repetition % 2 else ('after','before')
    for name in names:
        for variant in variants:
            output=base/f'{name}-{variant}-{repetition}.toml'
            env=dict(os.environ,JULIA_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',AOS_INSTRUMENT_SAMPLES='128',AOS_INSTRUMENT_RESULTS=str(output))
            project=base/f"{'app' if variant == 'after' else 'before'}-{name}"
            cmd=['taskset','-c','2','julia','--startup-file=no','--threads=1,0','--gcthreads=1',f'--project={project}',str(source/'benchmarks/profile_instrument_workspace_cuda.jl'),name]
            with (base/f'{name}-{variant}-{repetition}.log').open('w') as log:
                subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
            print(output,flush=True)
