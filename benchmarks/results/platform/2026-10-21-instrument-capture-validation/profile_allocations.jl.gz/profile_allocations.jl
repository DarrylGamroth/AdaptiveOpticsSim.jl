using AdaptiveOpticsSim
using AdaptiveOpticsSim.AlgorithmGraphs
using CUDA, Profile, LinearAlgebra
include("/home/dgamroth/workspaces/codex/REVOLTClassicSim.jl/src/REVOLTClassicSim.jl")
function cycle!(boundary)
    seq = step_hil_frame!(boundary)
    adopt_hil_command!(boundary, seq)
    return nothing
end
function main()
    CUDA.allowscalar(false)
    BLAS.set_num_threads(1)
    AdaptiveOpticsSim.Backends.set_fft_provider_threads!(1)
    target=AdaptiveOpticsSim.Backends.compute_device(CUDA.zeros(Float32,1))
    system=REVOLTClassicSim.prepare_hil_system(;target,execution=CapturedGraphExecution())
    for _ in 1:64
        cycle!(system.boundary)
    end
    println("bytes=",@allocated(cycle!(system.boundary)))
    Profile.Allocs.clear()
    Profile.Allocs.@profile sample_rate=1.0 cycle!(system.boundary)
    for a in Profile.Allocs.fetch().allocs
        println("allocation size=",a.size," type=",a.type)
        for frame in a.stacktrace
            occursin("profile_allocations",string(frame.file)) && break
            println("  ",frame.func," ",frame.file,":",frame.line)
        end
    end
end
main()
