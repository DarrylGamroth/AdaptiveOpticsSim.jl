import subprocess,os,json
from pathlib import Path
r=Path(__file__).parent
env=os.environ|{'OPENBLAS_NUM_THREADS':'1','JULIA_NUM_THREADS':'1'}
for case in ('copper_fast','gpi_default','copper_default','gpi_fine','copper_fine'):
 cmd=['taskset','-c','2','julia','--startup-file=no','--threads=1','--project='+str(r/'baseline-env'),str(r/'profile_physical_pyramid_cuda.jl'),str(r/('before-'+case+'.toml')),case]
 print('START',case,flush=True)
 with (r/('before-'+case+'.log')).open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',case,flush=True)
