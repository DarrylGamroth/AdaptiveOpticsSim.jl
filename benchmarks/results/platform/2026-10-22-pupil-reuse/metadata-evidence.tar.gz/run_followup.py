from pathlib import Path
import subprocess,os,time,json
r=Path(__file__).parent
while Path('/proc/1425435').exists():time.sleep(1)
repo=r.parent/'AdaptiveOpticsSim-pupil-profile'
env=os.environ|{'OPENBLAS_NUM_THREADS':'1','JULIA_NUM_THREADS':'1'}
base=['taskset','-c','2','julia','--startup-file=no','--threads=1']
def run(label,project,script,args=[],extra={},prefix=[]):
 cmd=prefix+base+['--project='+str(project),str(script)]+list(map(str,args))
 print('START',label,flush=True)
 with (r/'commands.jsonl').open('a') as f:f.write(json.dumps({'label':label,'command':cmd,'extra':extra})+'\n')
 with (r/(label+'.log')).open('w') as f:subprocess.run(cmd,env=env|extra,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',label,flush=True)
run('optional-pyramid',r/'env',r/'optional-pyramid.jl')
for case in ('gpi_fine','copper_fine'):
 run('repeat-before-'+case,r/'baseline-env',r/'profile_physical_pyramid_cuda.jl',[r/('repeat-before-'+case+'.toml'),case])
 run('repeat-after-'+case,r/'env',repo/'benchmarks/profile_physical_pyramid_cuda.jl',[r/('repeat-after-'+case+'.toml'),case])
for mode in ('computed','dense','separable'):
 label='warm-'+mode+'-copper_fast'
 run(label,r/'env',repo/'benchmarks/compare_pupil_storage_cuda.jl',[r/(label+'.toml'),'copper_fast'],{'AOS_PUPIL_STORAGE':mode,'AOS_PROFILE_WARMUPS':'1024'})
label='trace-after-copper_fine'
prefix=['nsys','profile','--trace=cuda','--sample=none','--cpuctxsw=none','--cuda-graph-trace=node','--capture-range=cudaProfilerApi','--capture-range-end=stop','--force-overwrite=true','--output='+str(r/'after-copper_fine')]
run(label,r/'env',repo/'benchmarks/profile_physical_pyramid_cuda.jl',[r/'trace-after-copper_fine.toml','copper_fine'],{'AOS_PROFILE_EXTERNAL':'1'},prefix)
with (r/'stats-after-copper_fine.log').open('w') as f:subprocess.run(['nsys','stats','--report=cuda_gpu_kern_sum,cuda_gpu_mem_time_sum','--format=csv',str(r/'after-copper_fine.nsys-rep')],stdout=f,stderr=subprocess.STDOUT,check=True)
