import CUDA
include("/home/dgamroth/workspaces/codex/AdaptiveOpticsSim-pupil-profile/test/runtests_gpu_target_common.jl")
@testset "CUDA physical Pyramid fractional-shift contract" begin
    run_optional_pyramid_fractional_shift_checks(CUDABackendTag, CUDA.CuArray)
end
