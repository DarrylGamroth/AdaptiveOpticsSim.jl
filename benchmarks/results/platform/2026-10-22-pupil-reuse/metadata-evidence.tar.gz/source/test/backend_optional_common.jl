if !isdefined(@__MODULE__, :assert_prepared_device_execution_context_conformance)
    include(joinpath(@__DIR__, "backend_execution_context_conformance.jl"))
end

backend_package_name(::Type{AdaptiveOpticsSim.Backends.CUDABackendTag}) = "CUDA"
backend_package_name(::Type{AdaptiveOpticsSim.Backends.AMDGPUBackendTag}) = "AMDGPU"

backend_label(::Type{AdaptiveOpticsSim.Backends.CUDABackendTag}) = "CUDA"
backend_label(::Type{AdaptiveOpticsSim.Backends.AMDGPUBackendTag}) = "AMDGPU"

backend_full_smoke_env(::Type{AdaptiveOpticsSim.Backends.CUDABackendTag}) = "ADAPTIVEOPTICS_TEST_FULL_CUDA"
backend_full_smoke_env(::Type{AdaptiveOpticsSim.Backends.AMDGPUBackendTag}) = "ADAPTIVEOPTICS_TEST_FULL_AMDGPU"

if !isdefined(@__MODULE__, :ContractRateModel)
    include(joinpath(@__DIR__, "wfs_stage_contract_fixtures.jl"))
end

backend_selector(::Type{AdaptiveOpticsSim.Backends.CUDABackendTag}) = AdaptiveOpticsSim.Backends.CUDABackend()
backend_selector(::Type{AdaptiveOpticsSim.Backends.AMDGPUBackendTag}) = AdaptiveOpticsSim.Backends.AMDGPUBackend()

alternate_compute_device_identifier(
    ::Type{AdaptiveOpticsSim.Backends.CUDABackendTag},
    identifier::Integer,
) = iszero(identifier) ? one(identifier) : zero(identifier)

alternate_compute_device_identifier(
    ::Type{AdaptiveOpticsSim.Backends.AMDGPUBackendTag},
    identifier::Integer,
) = isone(identifier) ? identifier + one(identifier) : one(identifier)

function backend_current_stream(
    ::Type{AdaptiveOpticsSim.Backends.CUDABackendTag})
    return Base.invokelatest(
        getproperty(getfield(Main, :CUDA), :stream))
end

function backend_current_stream(
    ::Type{AdaptiveOpticsSim.Backends.AMDGPUBackendTag})
    return Base.invokelatest(
        getproperty(getfield(Main, :AMDGPU), :stream))
end

function backend_stream_isdone(
    ::Type{AdaptiveOpticsSim.Backends.CUDABackendTag}, stream)
    return Base.invokelatest(
        getproperty(getfield(Main, :CUDA), :isdone), stream)
end

function backend_stream_isdone(
    ::Type{AdaptiveOpticsSim.Backends.AMDGPUBackendTag}, stream)
    return Base.invokelatest(
        getproperty(getfield(getfield(Main, :AMDGPU), :HIP), :isdone),
        stream)
end

function run_optional_exact_compute_device_checks(
    ::Type{B},
    BackendArray,
) where {B<:AdaptiveOpticsSim.Backends.GPUBackendTag}
    seed_storage = BackendArray(zeros(Float32, 1))
    device = compute_device(seed_storage)
    availability = AdaptiveOpticsSim.Backends.compute_device_availability(
        device)
    @test typeof(availability) ===
        AdaptiveOpticsSim.Backends.ComputeDeviceAvailable
    @test AdaptiveOpticsSim.Backends.compute_device_is_available(availability)
    @test isnothing(
        AdaptiveOpticsSim.Backends.compute_device_unavailable_reason(
            availability))

    alternate_device = AdaptiveOpticsSim.Backends.AcceleratorComputeDevice(
        backend_selector(B),
        alternate_compute_device_identifier(
            B,
            AdaptiveOpticsSim.Backends.compute_device_identifier(device),
        ),
    )
    alternate_availability =
        AdaptiveOpticsSim.Backends.compute_device_availability(
            alternate_device)
    selected_device =
        AdaptiveOpticsSim.Backends.compute_device_is_available(
            alternate_availability) ? alternate_device : device
    caller_device = compute_device(BackendArray(zeros(Float32, 1)))

    storage = AdaptiveOpticsSim.Backends.allocate_device_array(
        selected_device, Float32, 2, 3)
    @test storage isa BackendArray
    @test size(storage) == (2, 3)
    @test compute_device(storage) == selected_device
    @test compute_device(BackendArray(zeros(Float32, 1))) == caller_device

    context = AdaptiveOpticsSim.Backends._prepare_device_execution_context(
        selected_device)
    retained_stream = getfield(context, :stream)
    caller_stream = backend_current_stream(B)
    prepared_device =
        AdaptiveOpticsSim.Backends._prepared_device_execution_compute_device(
            context)
    @test prepared_device == selected_device
    @test compute_device(BackendArray(zeros(Float32, 1))) == caller_device
    observe_context() = (
        compute_device(BackendArray(zeros(Float32, 1))),
        backend_current_stream(B),
    )
    assert_prepared_device_execution_context_conformance(
        context,
        selected_device,
        observe_context,
        (selected_device, retained_stream),
    )
    context_observation =
        AdaptiveOpticsSim.Backends._with_prepared_device_execution_context(
            context) do
            (
                compute_device(BackendArray(zeros(Float32, 1))),
                backend_current_stream(B),
            )
        end
    @test context_observation[1] == selected_device
    @test context_observation[2] === retained_stream
    @test compute_device(BackendArray(zeros(Float32, 1))) == caller_device
    @test backend_current_stream(B) === caller_stream

    nested_context =
        AdaptiveOpticsSim.Backends._prepare_device_execution_context(
            selected_device)
    nested_stream = getfield(nested_context, :stream)
    nested_error =
        AdaptiveOpticsSim.Backends._with_prepared_device_execution_context(
            context) do
            @test backend_current_stream(B) === retained_stream
            AdaptiveOpticsSim.Backends._with_prepared_device_execution_context(
                nested_context) do
                @test backend_current_stream(B) === nested_stream
            end
            @test backend_current_stream(B) === retained_stream
            caught_error = try
                AdaptiveOpticsSim.Backends._with_prepared_device_execution_context(
                    nested_context) do
                    @test backend_current_stream(B) === nested_stream
                    error("injected nested prepared-context failure")
                end
                nothing
            catch caught
                caught
            end
            @test backend_current_stream(B) === retained_stream
            caught_error
        end
    @test nested_error isa ErrorException
    @test backend_current_stream(B) === caller_stream

    prepared_error = try
        AdaptiveOpticsSim.Backends._with_prepared_device_execution_context(
            context) do
            @test backend_current_stream(B) === retained_stream
            error("injected prepared-context failure")
        end
        nothing
    catch caught
        caught
    end
    @test prepared_error isa ErrorException
    @test compute_device(BackendArray(zeros(Float32, 1))) == caller_device
    @test backend_current_stream(B) === caller_stream

    if AdaptiveOpticsSim.Backends.compute_device_is_available(
        alternate_availability)
        caller_context =
            AdaptiveOpticsSim.Backends._prepare_device_execution_context(
                caller_device)
        alternate_context =
            AdaptiveOpticsSim.Backends._prepare_device_execution_context(
                alternate_device)
        caller_context_stream = getfield(caller_context, :stream)
        alternate_context_stream = getfield(alternate_context, :stream)
        alternate_error =
            AdaptiveOpticsSim.Backends._with_prepared_device_execution_context(
                caller_context) do
                @test backend_current_stream(B) === caller_context_stream
                AdaptiveOpticsSim.Backends._with_prepared_device_execution_context(
                    alternate_context) do
                    @test compute_device(BackendArray(zeros(Float32, 1))) ==
                        alternate_device
                    @test backend_current_stream(B) ===
                        alternate_context_stream
                end
                @test compute_device(BackendArray(zeros(Float32, 1))) ==
                    caller_device
                @test backend_current_stream(B) === caller_context_stream
                caught_error = try
                    AdaptiveOpticsSim.Backends._with_prepared_device_execution_context(
                        alternate_context) do
                        error("injected alternate-device context failure")
                    end
                    nothing
                catch caught
                    caught
                end
                @test compute_device(BackendArray(zeros(Float32, 1))) ==
                    caller_device
                @test backend_current_stream(B) === caller_context_stream
                caught_error
            end
        @test alternate_error isa ErrorException
        @test compute_device(BackendArray(zeros(Float32, 1))) == caller_device
        @test backend_current_stream(B) === caller_stream
    end

    injected_error = try
        AdaptiveOpticsSim.Backends._with_compute_device(
            selected_device) do
            @test compute_device(BackendArray(zeros(Float32, 1))) ==
                selected_device
            error("injected exact-device context failure")
        end
        nothing
    catch error
        error
    end
    @test injected_error isa ErrorException
    @test compute_device(BackendArray(zeros(Float32, 1))) == caller_device

    invalid_device = AdaptiveOpticsSim.Backends.AcceleratorComputeDevice(
        backend_selector(B), 1.0f0)
    invalid_availability =
        AdaptiveOpticsSim.Backends.compute_device_availability(invalid_device)
    @test typeof(invalid_availability) ===
        AdaptiveOpticsSim.Backends.ComputeDeviceUnavailable
    @test AdaptiveOpticsSim.Backends.compute_device_unavailable_reason(
        invalid_availability) == :invalid_device_identifier
    invalid_error = try
        AdaptiveOpticsSim.Backends.allocate_device_array(
            invalid_device, Float32, 1)
        nothing
    catch error
        error
    end
    @test typeof(invalid_error) <:
        AdaptiveOpticsSim.Backends.ComputeDeviceError
    @test invalid_error.reason == :invalid_device_identifier

    foreign_device = AdaptiveOpticsSim.Backends.AcceleratorComputeDevice(
        backend_selector(B), Int(typemax(Int32)))
    foreign_availability =
        AdaptiveOpticsSim.Backends.compute_device_availability(foreign_device)
    @test typeof(foreign_availability) ===
        AdaptiveOpticsSim.Backends.ComputeDeviceUnavailable
    @test AdaptiveOpticsSim.Backends.compute_device_unavailable_reason(
        foreign_availability) == :device_unavailable
    foreign_error = try
        AdaptiveOpticsSim.Backends.allocate_device_array(
            foreign_device, Float32, 1)
        nothing
    catch error
        error
    end
    @test typeof(foreign_error) <:
        AdaptiveOpticsSim.Backends.ComputeDeviceError
    @test foreign_error.reason == :device_unavailable
    return nothing
end

function run_optional_cycle_averaged_modulation_checks(::Type{B},
    BackendArray) where {B<:AdaptiveOpticsSim.Backends.GPUBackendTag}
    T = Float32
    policy = CircularModulation(T(2);
        samples=5, phase_offset_rad=T(0.3), T=T)
    cpu = AdaptiveOpticsSim.Optics.prepare_focal_plane_modulation(
        policy, 8, zeros(T, 8, 8), T)
    device = AdaptiveOpticsSim.Optics.prepare_focal_plane_modulation(
        policy, 8, BackendArray(zeros(T, 8, 8)), T)
    weights = copy(device.amplitude_weights)

    AdaptiveOpticsSim.Optics.update_cycle_averaged_circular_modulation!(
        cpu, T(1.5))
    AdaptiveOpticsSim.Optics.update_cycle_averaged_circular_modulation!(
        device, T(1.5))
    @test device.phases isa BackendArray
    @test device.amplitude_weights == weights
    @test isapprox(sum(abs2, device.amplitude_weights), one(T);
        rtol=8eps(T))
    @test isapprox(Array(device.phases), cpu.phases;
        rtol=8eps(T), atol=8eps(T))

    AdaptiveOpticsSim.Optics.update_cycle_averaged_circular_modulation!(
        device, T(1.5); enabled=false)
    @test Array(device.phases) == ones(Complex{T}, 8, 8, 5)
    @test device.amplitude_weights == weights
    return nothing
end

function optional_detector_calibration_signature_allocation_bytes(
    det, seed::UInt)
    AdaptiveOpticsSim.WavefrontSensors.detector_calibration_signature(det, seed)
    return @allocated AdaptiveOpticsSim.WavefrontSensors.detector_calibration_signature(
        det, seed)
end

@inline function optional_detector_response_device_resident(
    response::GaussianPixelResponse,
    device,
    BackendArray,
)
    return response.kernel isa BackendArray &&
        compute_device(response.kernel) == device
end

@inline function optional_detector_response_device_resident(
    response::SampledFrameResponse,
    device,
    BackendArray,
)
    return response.kernel isa BackendArray &&
        compute_device(response.kernel) == device
end

@inline function optional_detector_response_device_resident(
    response::RectangularPixelAperture,
    device,
    BackendArray,
)
    return response.kernel_x isa BackendArray &&
        response.kernel_y isa BackendArray &&
        compute_device(response.kernel_x) == device &&
        compute_device(response.kernel_y) == device
end

function optional_detector_readout_owner_device_resident(
    owner,
    device,
    BackendArray,
)
    for name in fieldnames(typeof(owner))
        name === :read_offsets_s && continue
        value = getfield(owner, name)
        if value isa AbstractArray
            value isa BackendArray || return false
            compute_device(value) == device || return false
        end
    end
    return true
end

function optional_detector_runtime_owners_device_resident(
    detector::Detector,
    device,
    BackendArray,
)
    state = detector.state
    workspace = detector.workspace
    products = detector.products
    arrays = (
        products.frame,
        workspace.presampling_buffer,
        workspace.presampling_scratch,
        workspace.response_buffer,
        workspace.bin_buffer,
        workspace.temporal_buffer,
        workspace.noise_buffer,
        state.accum_buffer,
        state.latent_buffer,
    )
    all(
        array -> array isa BackendArray &&
            compute_device(array) == device,
        arrays,
    ) || return false
    products.output_buffer === nothing || (
        products.output_buffer isa BackendArray &&
        compute_device(products.output_buffer) == device
    ) || return false
    workspace.output_buffer_host === nothing || return false
    return optional_detector_readout_owner_device_resident(
        detector.products.readout,
        device,
        BackendArray,
    ) && optional_detector_readout_owner_device_resident(
        detector.workspace.readout, device, BackendArray)
end

function run_optional_cmos_family_checks(
    ::Type{B},
    BackendArray,
) where {B<:AdaptiveOpticsSim.Backends.GPUBackendTag}
    T = Float32
    selector = backend_selector(B)
    zero_input = BackendArray(zeros(T, 4, 4))

    column_detector = Detector(
        noise=NoiseNone(),
        qe=one(T),
        sensor=CMOSSensor(column_readout_sigma=one(T), T=T,
            backend=selector),
        response_model=NullFrameResponse(),
        T=T,
        backend=selector,
    )
    column_output = capture!(column_detector, zero_input,
        MersenneTwister(5101))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(column_output))
    column_host = Array(column_output)
    @test column_output isa BackendArray
    @test all(j -> all(==(column_host[1, j]), column_host[:, j]),
        axes(column_host, 2))
    @test !all(iszero, column_host)

    row_detector = Detector(
        noise=NoiseNone(),
        qe=one(T),
        sensor=CMOSSensor(row_readout_sigma=one(T), T=T,
            backend=selector),
        response_model=NullFrameResponse(),
        T=T,
        backend=selector,
    )
    row_output = capture!(row_detector, zero_input,
        MersenneTwister(5102))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(row_output))
    row_host = Array(row_output)
    @test row_output isa BackendArray
    @test all(i -> all(==(row_host[i, 1]), row_host[i, :]),
        axes(row_host, 1))
    @test !all(iszero, row_host)

    sigma_map = zeros(T, 4, 4)
    sigma_map[2, 3] = T(2)
    pixel_detector = Detector(
        noise=NoiseNone(),
        qe=one(T),
        sensor=CMOSSensor(
            readout_noise_model=CMOSReadNoiseMap(sigma_map;
                T=T, backend=selector),
            T=T,
            backend=selector,
        ),
        response_model=NullFrameResponse(),
        T=T,
        backend=selector,
    )
    pixel_output = capture!(pixel_detector, zero_input,
        MersenneTwister(5103))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(pixel_output))
    pixel_host = Array(pixel_output)
    @test pixel_output isa BackendArray
    @test count(!iszero, pixel_host) == 1
    @test !iszero(pixel_host[2, 3])

    output_pattern = AdaptiveOpticsSim.Detectors.StaticCMOSOutputPattern(
        2, T[1, 2], T[0, 10]; T=T, backend=selector)
    output_detector = Detector(
        noise=NoiseNone(),
        qe=one(T),
        sensor=CMOSSensor(output_model=output_pattern, T=T,
            backend=selector),
        response_model=NullFrameResponse(),
        T=T,
        backend=selector,
    )
    output = capture!(output_detector,
        BackendArray(fill(T(2), 4, 4)), MersenneTwister(5104))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(output))
    @test output isa BackendArray
    @test Array(output) == T[
        2 2 14 14
        2 2 14 14
        2 2 14 14
        2 2 14 14
    ]
    return nothing
end

function run_optional_shared_detector_ipc_checks(
    ::Type{B},
    BackendArray,
) where {B<:AdaptiveOpticsSim.Backends.GPUBackendTag}
    T = Float32
    selector = backend_selector(B)
    response_kernel = T[
        0.00 0.05 0.00
        0.10 0.55 0.20
        0.00 0.10 0.00
    ]
    ipc_kernel = T[
        0.00 0.02 0.00
        0.03 0.90 0.01
        0.00 0.04 0.00
    ]
    rate_values_host = zeros(T, 9, 9)
    rate_values_host[5, 5] = T(4)
    rate_values = BackendArray(rate_values_host)
    rate_metadata = OpticalPlaneMetadata(
        DetectorPlane(),
        rate_values;
        coordinate_domain=AngularCoordinates(),
        sampling=(one(T), one(T)),
        normalization=PhotonRateNormalization(),
        spatial_measure=CellIntegratedMeasure(),
        coherence=IncoherentIntensityAddition(),
        spectral=MonochromaticChannel(T(0.8e-6)),
    )
    map = IntensityMap(rate_metadata, rate_values)
    detector = Detector(
        noise=NoiseNone(),
        exposure_duration=T(0.75),
        qe=T(0.4),
        sensor=CMOSSensor(T=T, backend=selector),
        response_model=SampledFrameResponse(response_kernel;
            T, backend=selector),
        charge_coupling_model=InterpixelCapacitance(ipc_kernel;
            T, backend=selector),
        T=T,
        backend=selector,
    )
    acquisition = prepare_detector_acquisition(detector, map)
    response_mtf_before = detector_mtf(detector, T(0.19), T(0.31))
    output = capture!(acquisition, Xoshiro(0x7_502))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(output),
    )

    expected = optional_zero_extended_response(
        rate_values_host, response_kernel)
    expected .*= T(0.75 * 0.4)
    expected = optional_zero_extended_response(expected,
        ipc_kernel)
    device = compute_device(output)
    coupling = detector.params.charge_coupling_model

    @test output isa BackendArray
    @test isapprox(Array(output), expected; rtol=8f-6, atol=8f-7)
    @test coupling isa InterpixelCapacitance
    @test coupling.response.kernel isa BackendArray
    @test compute_device(coupling.response.kernel) == device
    @test optional_detector_runtime_owners_device_resident(detector, device,
        BackendArray)
    @test AdaptiveOpticsSim.Detectors.detector_acquisition_input(
        acquisition).values === map.values
    @test detector_export_metadata(detector).charge_coupling ==
        :interpixel_capacitance
    @test detector_mtf(detector, T(0.19), T(0.31)) ==
        response_mtf_before
    return nothing
end

function optional_zero_extended_response(
    input::AbstractMatrix{T},
    kernel::AbstractMatrix{T},
) where {T<:AbstractFloat}
    output = zeros(T, size(input))
    radius_i = fld(size(kernel, 1), 2)
    radius_j = fld(size(kernel, 2), 2)
    @inbounds for j in axes(output, 2), i in axes(output, 1)
        value = zero(T)
        for kj in axes(kernel, 2), ki in axes(kernel, 1)
            ii = i - (ki - radius_i - 1)
            jj = j - (kj - radius_j - 1)
            if checkbounds(Bool, input, ii, jj)
                value = muladd(kernel[ki, kj], input[ii, jj], value)
            end
        end
        output[i, j] = value
    end
    return output
end

function run_optional_backend_selector_smoke(::Type{B}, BackendArray) where {B<:AdaptiveOpticsSim.Backends.GPUBackendTag}
    selector = backend_selector(B)
    array_backend = AdaptiveOpticsSim.Backends._resolve_array_backend(selector)
    T = Float32
    tel = Telescope(resolution=8, diameter=T(1), central_obstruction=T(0),
        T=T, backend=selector)
    dm = DeformableMirror(tel; n_act=2, influence_width=T(0.3), T=T, backend=selector)
    dm_dense = DeformableMirror(tel; n_act=2, influence_model=DenseInfluenceMatrix(Array(dm.state.modes)), T=T, backend=selector)
    native_command = BackendArray(T[1, 0, 0, 0])
    set_command!(dm, native_command)
    update_surface!(dm)
    zernike_modal = ModalControllableOptic(tel, ZernikeOpticBasis([2, 3]); T=T, backend=selector)
    cartesian_modal = ModalControllableOptic(tel, CartesianTiltBasis(; scale=T(0.1)); T=T, backend=selector)
    wfs = ShackHartmannWFS(tel; n_lenslets=2, T=T, backend=selector)
    det = Detector(noise=NoiseNone(), exposure_duration=T(1), qe=T(1), binning=1, T=T, backend=selector)
    sampled_response = SampledFrameResponse(
        T[0 0.1 0; 0.1 0.6 0.1; 0 0.1 0]; T=T,
        backend=selector)
    sampled_qe = AdaptiveOpticsSim.Detectors.SampledQuantumEfficiency(
        T[0.5e-6, 0.6e-6, 0.7e-6], T[0.2, 0.8, 0.4]; T=T)
    calibration_det = Detector(noise=NoiseNone(), exposure_duration=T(1),
        qe=sampled_qe, response_model=sampled_response, T=T,
        backend=selector)
    pupil = PupilFunction(tel; T=T, backend=selector)
    device = compute_device(pupil.opd)
    @test device isa AdaptiveOpticsSim.Backends.AcceleratorComputeDevice
    @test typeof(AdaptiveOpticsSim.Backends.compute_device_backend(device)) ===
        typeof(selector)
    @test !isnothing(
        AdaptiveOpticsSim.Backends.compute_device_identifier(device))
    @test compute_device(pupil.amplitude) == device
    compute_device(pupil.opd)
    @test @allocated(compute_device(pupil.opd)) == 0
    @test pupil.opd isa BackendArray
    @test dm.state.coefs isa BackendArray
    @test dm.state.modes isa
        AdaptiveOpticsSim.Optics.GaussianInfluenceOperator
    @test typeof(backend(dm.state.modes)) === typeof(selector)
    @test similar(dm.state.modes, T, 2, 2) isa BackendArray
    @test AdaptiveOpticsSim.Optics.materialize_influence_matrix(dm) isa
        BackendArray
    @test dm_dense.state.coefs isa BackendArray
    @test dm_dense.state.modes isa BackendArray
    @test Array(dm_dense.state.modes) ≈ Array(dm.state.modes) atol=0 rtol=0
    @test zernike_modal.state.coefs isa BackendArray
    @test zernike_modal.state.modes isa BackendArray
    @test cartesian_modal.state.coefs isa BackendArray
    @test cartesian_modal.state.modes isa BackendArray
    @test det.products.frame isa BackendArray
    @test calibration_det.params.response_model.kernel isa BackendArray
    seed = UInt(0x51a7)
    AdaptiveOpticsSim.WavefrontSensors.detector_calibration_signature(calibration_det, seed)
    optional_detector_calibration_signature_allocation_bytes(
        calibration_det, seed)
    @test optional_detector_calibration_signature_allocation_bytes(
        calibration_det, seed) == 0

    gain_map = reshape(T.(range(T(0.6), T(1.2); length=16)), 4, 4)
    bad_mask = falses(4, 4)
    bad_mask[2, 3] = true
    defect_det = Detector(noise=NoiseNone(), sensor=CMOSSensor(T=T,
            backend=selector),
        defect_model=CompositeDetectorDefectModel(
            PixelResponseNonuniformity(gain_map; T=T, backend=selector),
            BadPixelMask(bad_mask; T=T, backend=selector)),
        T=T, backend=selector)
    photon_rate = array_backend(fill(T(2), 4, 4))
    calibration_frame = AdaptiveOpticsSim.WavefrontSensors.detector_calibration_frame!(
        defect_det, photon_rate, one(T))
    expected_frame = T(2) .* gain_map
    expected_frame[2, 3] = zero(T)
    @test Array(calibration_frame) ≈ expected_frame rtol=T(1e-6)
    @test optional_detector_calibration_signature_allocation_bytes(
        defect_det, seed) == 0

    invalid_values = array_backend(T[-1 1; 1 1])
    invalid_metadata = OpticalPlaneMetadata(FocalPlane(), invalid_values;
        coordinate_domain=AngularCoordinates(), sampling=(one(T), one(T)),
        normalization=PhotonRateNormalization(),
        spatial_measure=CellIntegratedMeasure(),
        coherence=IncoherentIntensityAddition())
    invalid_map = IntensityMap(invalid_metadata, invalid_values)
    @test_throws InvalidConfiguration prepare_detector_acquisition(
        det, invalid_map)
    return nothing
end

function run_optional_lgs_convolution_normalization(::Type{B}) where {B<:AdaptiveOpticsSim.Backends.GPUBackendTag}
    selector = backend_selector(B)
    array_backend = AdaptiveOpticsSim.Backends._resolve_array_backend(selector)
    T = Float32
    n = 8
    expected = reshape(collect(range(T(0.25), T(2); length=n * n)), n, n)
    expected_stack = cat(expected, reverse(expected; dims=2); dims=3)
    intensity_stack = array_backend(copy(expected_stack))
    kernel_fft = array_backend(ones(Complex{T}, n, n, 2))
    fft_stack = array_backend(zeros(Complex{T}, n, n, 2))
    fft_plan = AdaptiveOpticsSim.Backends.plan_fft_backend!(fft_stack, (1, 2))
    ifft_plan = AdaptiveOpticsSim.Backends.plan_ifft_backend!(fft_stack, (1, 2))

    WavefrontSensors.apply_lgs_convolution_stack!(
        intensity_stack, kernel_fft, fft_stack, fft_plan, ifft_plan)
    actual = Array(intensity_stack)
    @test actual ≈ expected_stack rtol=T(1e-5) atol=T(1e-6)
    @test vec(sum(actual; dims=(1, 2))) ≈
          vec(sum(expected_stack; dims=(1, 2))) rtol=T(1e-5)
    return nothing
end

function run_optional_sodium_layer_profile_wfs(::Type{B},
    BackendArray) where {B<:AdaptiveOpticsSim.Backends.GPUBackendTag}
    selector = backend_selector(B)
    T = Float32
    tel = Telescope(resolution=16, diameter=T(8),
        central_obstruction=zero(T), T=T, backend=selector)
    pupil = PupilFunction(tel; T=T, backend=selector)

    @testset "Pyramid sodium-layer physical rate" begin
        src = LGSSource(
            sodium_layer_profile=SodiumLayerProfile(
                T[80_000, 90_000, 100_000], T[0.2, 0.6, 0.2]),
            laser_launch_xy_m=(T(1), T(-0.5)),
            fwhm_spot_up=T(0.8),
            photon_irradiance=one(T),
            T=T,
        )
        wfs = PyramidWFS(tel; pupil_samples=4,
            modulation=zero(T), T=T, backend=selector)
        front_end = PyramidOpticalFrontEnd(wfs, src)
        rate = pyramid_rate_map(front_end, pupil)
        optics = prepare_wfs_optics(front_end, pupil, rate)
        form_wfs_optical_products!(rate, pupil, optics)

        cpu_tel = Telescope(resolution=16, diameter=T(8),
            central_obstruction=zero(T), T=T, backend=CPUBackend())
        cpu_pupil = PupilFunction(cpu_tel; T=T, backend=CPUBackend())
        copyto!(cpu_pupil.opd, Array(pupil.opd))
        cpu_wfs = PyramidWFS(cpu_tel; pupil_samples=4,
            modulation=zero(T), T=T, backend=CPUBackend())
        cpu_front_end = PyramidOpticalFrontEnd(cpu_wfs, src)
        cpu_rate = pyramid_rate_map(cpu_front_end, cpu_pupil)
        cpu_optics = prepare_wfs_optics(
            cpu_front_end, cpu_pupil, cpu_rate)
        form_wfs_optical_products!(cpu_rate, cpu_pupil, cpu_optics)

        AdaptiveOpticsSim.Backends.synchronize_backend!(
            AdaptiveOpticsSim.Backends.execution_style(rate.values))
        @test rate.values isa BackendArray
        @test all(isfinite, Array(rate.values))
        @test isapprox(Array(rate.values), cpu_rate.values;
            rtol=T(5e-5), atol=T(5e-5))

        prepared_kernel = optics.plan.lgs_model.kernel_fft
        @test prepared_kernel isa BackendArray
        original_kernel = Array(prepared_kernel)

        changed_src = LGSSource(
            sodium_layer_profile=SodiumLayerProfile(
                T[80_000, 90_000, 100_000], T[0.8, 0.1, 0.1]),
            laser_launch_xy_m=(T(1), T(-0.5)),
            fwhm_spot_up=T(0.8),
            photon_irradiance=one(T),
            T=T,
        )
        changed_front_end = PyramidOpticalFrontEnd(wfs, changed_src)
        changed_rate = pyramid_rate_map(changed_front_end, pupil)
        changed_optics = prepare_wfs_optics(
            changed_front_end, pupil, changed_rate)
        changed_kernel = changed_optics.plan.lgs_model.kernel_fft
        @test changed_kernel isa BackendArray
        @test Array(prepared_kernel) == original_kernel
        @test !isapprox(Array(changed_kernel), original_kernel;
            rtol=T(1e-5), atol=T(1e-6))
        form_wfs_optical_products!(changed_rate, pupil, changed_optics)

        cpu_changed_front_end = PyramidOpticalFrontEnd(cpu_wfs, changed_src)
        cpu_changed_rate = pyramid_rate_map(cpu_changed_front_end, cpu_pupil)
        cpu_changed_optics = prepare_wfs_optics(
            cpu_changed_front_end, cpu_pupil, cpu_changed_rate)
        form_wfs_optical_products!(
            cpu_changed_rate, cpu_pupil, cpu_changed_optics)
        AdaptiveOpticsSim.Backends.synchronize_backend!(
            AdaptiveOpticsSim.Backends.execution_style(changed_rate.values))
        @test isapprox(Array(changed_rate.values), cpu_changed_rate.values;
            rtol=T(5e-5), atol=T(5e-5))
        @test !isapprox(Array(changed_rate.values), Array(rate.values);
            rtol=T(1e-5), atol=T(1e-6))
    end

    @testset "Bi-O-edge sodium-layer profile" begin
        src = LGSSource(
            sodium_layer_profile=SodiumLayerProfile(
                T[80_000, 90_000, 100_000], T[0.2, 0.6, 0.2]),
            laser_launch_xy_m=(T(1), T(-0.5)),
            fwhm_spot_up=T(0.8),
            photon_irradiance=one(T),
            T=T,
        )
        wfs = BiOEdgeWFS(tel; pupil_samples=4,
            modulation=zero(T), T=T, backend=selector)

        front_end = BiOEdgeOpticalFrontEnd(wfs, src)
        rate = bi_o_edge_rate_map(front_end, pupil)
        optics = prepare_wfs_optics(front_end, pupil, rate)
        prepared_kernel = optics.plan.lgs_model.kernel_fft
        @test prepared_kernel isa BackendArray
        original_kernel = Array(prepared_kernel)
        @test all(isfinite, original_kernel)
        form_wfs_optical_products!(rate, pupil, optics)
        AdaptiveOpticsSim.Backends.synchronize_backend!(
            AdaptiveOpticsSim.Backends.execution_style(rate.values))
        @test rate.values isa BackendArray
        @test all(isfinite, Array(rate.values))

        changed_src = LGSSource(
            sodium_layer_profile=SodiumLayerProfile(
                T[80_000, 90_000, 100_000], T[0.8, 0.1, 0.1]),
            laser_launch_xy_m=(T(1), T(-0.5)),
            fwhm_spot_up=T(0.8), photon_irradiance=one(T), T=T)
        changed_front_end = BiOEdgeOpticalFrontEnd(wfs, changed_src)
        changed_rate = bi_o_edge_rate_map(changed_front_end, pupil)
        changed_optics = prepare_wfs_optics(
            changed_front_end, pupil, changed_rate)
        @test !isapprox(
            Array(changed_optics.plan.lgs_model.kernel_fft), original_kernel;
            rtol=T(1e-5), atol=T(1e-6))
    end
    return nothing
end


function run_optional_generic_wfs_acquisition_checks(
    ::Type{B}, BackendArray) where {
    B<:AdaptiveOpticsSim.Backends.GPUBackendTag,
}
    selector = backend_selector(B)
    T = Float32
    rate_values = BackendArray(reshape(T.(1:4), 2, 2))
    metadata = OpticalPlaneMetadata(DetectorPlane(), rate_values;
        coordinate_domain=NormalizedPupilCoordinates(),
        sampling=(T(0.25), T(0.25)),
        spectral=MonochromaticChannel(T(0.75e-6)),
        normalization=PhotonRateNormalization(),
        spatial_measure=CellIntegratedMeasure(),
        coherence=IncoherentIntensityAddition())
    rate = IntensityMap(metadata, rate_values)

    detector = Detector(noise=NoiseNone(), exposure_duration=T(0.25),
        qe=one(T), response_model=NullFrameResponse(), T=T,
        backend=selector)
    observation = WFSObservation(similar(rate_values);
        units=:electron_count, layout=:detector_frame)
    acquisition = prepare_wfs_acquisition(detector, rate, observation)
    @test WavefrontSensors.wfs_acquisition_plan(acquisition) isa
        WavefrontSensors.WFSDetectorAcquisitionPlan
    @test validate_wfs_target(acquisition, compute_device(rate_values)) ===
        acquisition
    @test @inferred(acquire_wfs_observation!(
        observation, rate, acquisition, Xoshiro(0x50453541))) === observation
    synchronize_backend!(execution_style(observation.storage))
    @test observation.storage isa BackendArray
    @test Array(observation.storage) == Array(rate_values) .* T(0.25)

    spad = SPADArrayDetector((2, 2); exposure_duration=T(0.5),
        noise=NoiseNone(), sensor=SPADArraySensor(
            active_area_detection_efficiency=one(T),
            dark_count_rate=zero(T), fill_factor=one(T), T=T),
        T=T, backend=selector)
    counting_observation = WFSObservation(similar(rate_values);
        units=:photon_count, layout=:counting_channels)
    counting = prepare_wfs_acquisition(spad, rate, counting_observation)
    @test WavefrontSensors.wfs_acquisition_plan(counting) isa
        WavefrontSensors.WFSCountingAcquisitionPlan
    @test validate_wfs_target(counting, compute_device(rate_values)) ===
        counting
    @test @inferred(acquire_wfs_observation!(counting_observation, rate,
        counting, Xoshiro(0x50453542))) === counting_observation
    synchronize_backend!(execution_style(counting_observation.storage))
    @test counting_observation.storage isa BackendArray
    @test Array(counting_observation.storage) ==
        Array(rate_values) .* T(0.5)

    second_rate_values = copy(rate_values)
    second_rate = IntensityMap(metadata, second_rate_values)
    second_detector = Detector(noise=NoiseNone(),
        exposure_duration=T(0.5), qe=one(T),
        response_model=NullFrameResponse(), T=T, backend=selector)
    second_observation = WFSObservation(similar(rate_values);
        units=:electron_count, layout=:detector_frame)
    fanout = prepare_wfs_acquisition((detector, second_detector),
        (rate, second_rate), (observation, second_observation))
    @test WavefrontSensors.wfs_acquisition_plan(fanout) isa
        WavefrontSensors.WFSMultipleDetectorAcquisitionPlan
    @test validate_wfs_target(fanout, compute_device(rate_values)) === fanout
    @test @inferred(acquire_wfs_observation!(
        (observation, second_observation), (rate, second_rate), fanout,
        Xoshiro(0x50453543))) === (observation, second_observation)
    synchronize_backend!(execution_style(second_observation.storage))
    @test Array(second_observation.storage) ==
        Array(second_rate_values) .* T(0.5)

    aliased_observation = WFSObservation(rate.values;
        units=:electron_count, layout=:detector_frame)
    alias_error = try
        prepare_wfs_acquisition(detector, rate, aliased_observation)
        nothing
    catch error
        error
    end
    @test alias_error isa WFSPreparationError
    @test alias_error.reason === :ownership
    return nothing
end

function run_optional_wfs_stage_contracts(
    ::Type{B}, BackendArray) where {B<:AdaptiveOpticsSim.Backends.GPUBackendTag}
    selector = backend_selector(B)
    T = Float32
    tel = Telescope(resolution=4, diameter=T(2),
        central_obstruction=zero(T), T=T, backend=selector)
    src = Source(band=:custom, wavelength=T(0.75e-6),
        photon_irradiance=T(4), T=T)
    pupil = PupilFunction(tel; T=T, backend=selector)
    fill!(pupil.opd, T(2e-9))
    field = ElectricField(pupil, src; zero_padding=1, T=T)
    field_formation = prepare_pupil_field(pupil, src, field;
        center_even_grid=false)
    fill_electric_field!(field, pupil, field_formation)

    rate_values = BackendArray(zeros(T, 4, 4))
    rate_metadata = OpticalPlaneMetadata(DetectorPlane(), rate_values;
        coordinate_domain=AngularCoordinates(),
        sampling=(one(T), one(T)),
        spectral=MonochromaticChannel(T(wavelength(src))),
        normalization=PhotonRateNormalization(),
        spatial_measure=CellIntegratedMeasure(),
        coherence=IncoherentIntensityAddition())
    rate = IntensityMap(rate_metadata, rate_values)
    optical_model = ContractRateModel(T(3), T(1e6), rate.metadata)
    optics_plan = prepare_wfs_optics(optical_model, pupil, rate)

    detector = Detector(noise=NoiseNone(), exposure_duration=T(0.4),
        qe=T(0.5), response_model=NullFrameResponse(), T=T,
        backend=selector)
    binding = contract_detector_binding(detector, rate)
    observation = binding.observation
    acquisition_plan = prepare_wfs_acquisition(
        ContractDetectorAcquisitionModel((binding,)), rate, observation)
    measurement_values = similar(observation.storage)
    measurement = WFSMeasurement(measurement_values;
        units=:detector_signal, kind=:copied_detector_frame)
    estimator_plan = prepare_wfs_estimation(ContractCopyEstimator(
        :detector_signal, :copied_detector_frame),
        observation, measurement)
    rng = Xoshiro(0x574653)

    @test @inferred(form_wfs_optical_products!(rate, pupil,
        optics_plan)) === rate
    @test @inferred(acquire_wfs_observation!(observation, rate,
        acquisition_plan, rng)) === observation
    @test @inferred(estimate_wfs_measurement!(measurement, observation,
        estimator_plan)) === measurement
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(measurement.storage))
    @test rate.values isa BackendArray
    @test observation.storage isa BackendArray
    @test measurement.storage isa BackendArray
    @test observation.metadata.device == compute_device(observation.storage)
    @test measurement.metadata.device == compute_device(measurement.storage)
    @test Array(measurement.storage) == Array(observation.storage)
    @test sum(Array(observation.storage)) ≈
        sum(Array(rate.values)) * T(0.4) * T(0.5) rtol=T(2e-6)

    direct_values = similar(rate.values)
    direct_measurement = WFSMeasurement(direct_values;
        units=:field_intensity, kind=:direct_field_measurement)
    direct_plan = prepare_wfs_estimation(ContractDirectCopyEstimator(
        :field_intensity, :direct_field_measurement), field,
        direct_measurement)
    @test wfs_measurement_path(direct_plan) isa DirectMeasurementPath
    @test @inferred(estimate_wfs_measurement!(direct_measurement, field,
        direct_plan)) === direct_measurement
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(direct_measurement.storage))
    @test direct_measurement.storage isa BackendArray
    @test Array(direct_measurement.storage) ≈ abs2.(Array(field.values))

    second_values = BackendArray(zeros(T, 4, 4))
    second_metadata = OpticalPlaneMetadata(DetectorPlane(), second_values;
        coordinate_domain=AngularCoordinates(),
        sampling=(T(0.5), T(0.5)),
        spectral=MonochromaticChannel(T(0.9e-6)),
        normalization=PhotonRateNormalization(),
        spatial_measure=CellIntegratedMeasure(),
        coherence=IncoherentIntensityAddition())
    second_rate = IntensityMap(second_metadata, second_values)
    bundle = OpticalProductBundle(rate, second_rate)
    bundle_model = ContractBundleRateModel((
        ContractRateModel(T(2), T(1e6), rate.metadata),
        ContractRateModel(T(5), T(1e6), second_rate.metadata),
    ))
    optics_bundle = prepare_wfs_optics(bundle_model, pupil, bundle)
    form_wfs_optical_products!(bundle, pupil, optics_bundle)
    second_detector = Detector(noise=NoiseNone(), exposure_duration=T(0.7),
        qe=T(0.25), response_model=NullFrameResponse(), T=T,
        backend=selector)
    first_binding = contract_detector_binding(detector, rate)
    second_binding = contract_detector_binding(second_detector, second_rate)
    observations = (first_binding.observation, second_binding.observation)
    multi_acquisition = prepare_wfs_acquisition(
        ContractDetectorAcquisitionModel((first_binding, second_binding)),
        bundle, observations)
    @test @inferred(acquire_wfs_observation!(observations, bundle,
        multi_acquisition, (Xoshiro(1), Xoshiro(2)))) === observations
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(second_binding.observation.storage))
    @test first_binding.observation.storage isa BackendArray
    @test second_binding.observation.storage isa BackendArray
    @test first_binding.observation.metadata.device ==
        second_binding.observation.metadata.device

    packed_values = BackendArray(zeros(T, 8, 4))
    regions = ((1:4, 1:4), (5:8, 1:4))
    packed = WFSObservation(packed_values; units=:detector_signal,
        layout=regions)
    packed_plan = prepare_wfs_acquisition(
        ContractPackedAcquisition(regions, T(0.2)), bundle, packed)
    @test @inferred(acquire_wfs_observation!(packed, bundle, packed_plan,
        Xoshiro(3))) === packed
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(packed.storage))
    @test packed.storage isa BackendArray
    packed_host = Array(packed.storage)
    @test packed_host[1:4, :] ≈ Array(rate.values) .* T(0.2)
    @test packed_host[5:8, :] ≈ Array(second_rate.values) .* T(0.2)

    physical_wfs = ShackHartmannWFS(tel; n_lenslets=2,
        n_pix_subap=2, T=T, backend=selector)
    physical_rate = shack_hartmann_rate_map(physical_wfs, pupil, src)
    physical_optics = shack_hartmann_optics(
        physical_wfs, src)
    @test !hasfield(typeof(physical_optics), :sensor)
    @test physical_optics.propagation.workspace.fft_stack isa BackendArray
    prepared_physical_optics = prepare_wfs_optics(
        physical_optics, pupil, physical_rate)
    form_wfs_optical_products!(physical_rate, pupil, prepared_physical_optics)
    @test physical_rate.values isa BackendArray
    @test all(isfinite, Array(physical_rate.values))
    @test sum(Array(physical_rate.values)) > zero(T)

    changed_src = Source(band=:custom, wavelength=T(0.8e-6),
        photon_irradiance=photon_irradiance(src), T=T)
    failed_reprepare = try
        prepare_wfs_optics(
            shack_hartmann_optics(physical_wfs, changed_src),
            pupil, physical_rate)
        nothing
    catch err
        err
    end
    @test failed_reprepare isa WFSPreparationError
    @test failed_reprepare.reason === :plane_metadata
    @test form_wfs_optical_products!(physical_rate, pupil,
        prepared_physical_optics) === physical_rate

    sodium_lgs = LGSSource(wavelength=wavelength(src),
        photon_irradiance=T(4),
        sodium_layer_profile=SodiumLayerProfile(
            T[80_000, 90_000, 100_000], T[0.2, 0.6, 0.2]),
        laser_launch_xy_m=(T(1), T(-0.5)), fwhm_spot_up=T(0.8), T=T)
    spectral_sodium = with_spectrum(sodium_lgs, SpectralBundle(
        T[0.9 * wavelength(src), 1.1 * wavelength(src)], T[0.4, 0.6];
        T=T))
    spectral_sodium_wfs = ShackHartmannWFS(tel; n_lenslets=2,
        n_pix_subap=2, T=T, backend=selector)
    spectral_sodium_rates = shack_hartmann_rate_map(
        spectral_sodium_wfs, pupil, spectral_sodium)
    spectral_sodium_plan = @inferred prepare_wfs_optics(
        shack_hartmann_optics(spectral_sodium_wfs,
            spectral_sodium), pupil, spectral_sodium_rates)
    @test spectral_sodium_plan.components[1].workspace !==
        spectral_sodium_plan.components[2].workspace
    @test spectral_sodium_plan.components[1].workspace.lgs_kernel_fft isa
        BackendArray
    @test spectral_sodium_plan.components[2].workspace.lgs_kernel_fft isa
        BackendArray
    @test compute_device(
        spectral_sodium_plan.components[1].workspace.lgs_kernel_fft) ==
        compute_device(pupil.opd)
    @test form_wfs_optical_products!(spectral_sodium_rates, pupil,
        spectral_sodium_plan) === spectral_sodium_rates
    @test all(isfinite, Array(spectral_sodium_rates[1].values))
    @test all(isfinite, Array(spectral_sodium_rates[2].values))
    @test sum(Array(spectral_sodium_rates[1].values)) > zero(T)
    @test sum(Array(spectral_sodium_rates[2].values)) > zero(T)

    physical_field_wfs = ShackHartmannWFS(tel; n_lenslets=2,
        n_pix_subap=2, T=T, backend=selector)
    physical_field_rate = shack_hartmann_rate_map(physical_field_wfs, field)
    physical_field_front_end = prepare_wfs_optics(
        shack_hartmann_optics(physical_field_wfs), field,
        physical_field_rate)
    form_wfs_optical_products!(physical_field_rate, field,
        physical_field_front_end)
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(physical_field_rate.values))
    @test physical_field_rate.values isa BackendArray
    @test isapprox(Array(physical_field_rate.values),
        Array(physical_rate.values); rtol=T(2e-5), atol=T(2e-5))

    physical_asterism = Asterism([
        Source(band=:custom, wavelength=wavelength(src),
            photon_irradiance=T(1), T=T),
        Source(band=:custom, wavelength=wavelength(src),
            photon_irradiance=T(3), T=T),
    ])
    physical_asterism_wfs = ShackHartmannWFS(tel; n_lenslets=2,
        n_pix_subap=2, T=T, backend=selector)
    physical_asterism_rate = shack_hartmann_rate_map(
        physical_asterism_wfs, pupil, physical_asterism)
    physical_asterism_plan = prepare_wfs_optics(
        shack_hartmann_optics(physical_asterism_wfs,
            physical_asterism), pupil, physical_asterism_rate)
    form_wfs_optical_products!(physical_asterism_rate, pupil,
        physical_asterism_plan)
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(physical_asterism_rate.values))
    @test physical_asterism_rate.values isa BackendArray
    @test isapprox(Array(physical_asterism_rate.values),
        Array(physical_rate.values); rtol=T(2e-5), atol=T(2e-5))

    physical_detector = Detector(noise=NoiseNone(), exposure_duration=T(0.4),
        qe=T(0.5), response_model=NullFrameResponse(), T=T,
        backend=selector)
    physical_observation = WFSObservation(similar(physical_rate.values);
        units=:electron_count, layout=:lenslet_mosaic)
    physical_acquisition = prepare_wfs_acquisition(physical_detector,
        physical_rate, physical_observation)
    acquire_wfs_observation!(physical_observation, physical_rate,
        physical_acquisition, Xoshiro(0x5348))
    @test physical_observation.storage isa BackendArray
    @test sum(Array(physical_observation.storage)) ≈
        sum(Array(physical_rate.values)) * T(0.4) * T(0.5) rtol=T(2e-5)

    cpu_tel = Telescope(resolution=4, diameter=T(2),
        central_obstruction=zero(T), T=T)
    cpu_wfs = ShackHartmannWFS(cpu_tel; n_lenslets=2,
        n_pix_subap=2, T=T)
    mixed_backend_rate = shack_hartmann_rate_map(cpu_wfs, pupil, src)
    mixed_optical_error = try
        prepare_wfs_optics(
            shack_hartmann_optics(cpu_wfs, src), pupil,
            mixed_backend_rate)
        nothing
    catch err
        err
    end
    @test mixed_optical_error isa WFSPreparationError
    @test mixed_optical_error.reason === :backend

    four_pupil_cpu_tel = Telescope(resolution=4, diameter=T(2),
        central_obstruction=zero(T), T=T, backend=CPUBackend())
    four_pupil_cpu = PupilFunction(four_pupil_cpu_tel; T=T)
    copyto!(four_pupil_cpu.opd, Array(pupil.opd))
    @testset "Bi-O-edge prepared plant stages" begin
        cpu_sensor = BiOEdgeWFS(four_pupil_cpu_tel; pupil_samples=2,
            modulation=0, T=T)
        gpu_sensor = BiOEdgeWFS(tel; pupil_samples=2,
            modulation=0, T=T, backend=selector)
        cpu_front_end = BiOEdgeOpticalFrontEnd(cpu_sensor, src)
        gpu_front_end = BiOEdgeOpticalFrontEnd(gpu_sensor, src)
        cpu_rate = bi_o_edge_rate_map(cpu_front_end, four_pupil_cpu)
        gpu_rate = bi_o_edge_rate_map(gpu_front_end, pupil)
        cpu_plan = prepare_wfs_optics(cpu_front_end,
            four_pupil_cpu, cpu_rate)
        gpu_plan = prepare_wfs_optics(gpu_front_end, pupil,
            gpu_rate)
        form_wfs_optical_products!(cpu_rate, four_pupil_cpu, cpu_plan)
        form_wfs_optical_products!(gpu_rate, pupil, gpu_plan)
        AdaptiveOpticsSim.Backends.synchronize_backend!(
            AdaptiveOpticsSim.Backends.execution_style(gpu_rate.values))
        @test gpu_rate.values isa BackendArray
        @test isapprox(Array(gpu_rate.values), cpu_rate.values;
            rtol=T(3e-5), atol=T(3e-5))

        field_sensor = BiOEdgeWFS(tel; pupil_samples=2,
            modulation=0, T=T, backend=selector)
        field_front_end = BiOEdgeOpticalFrontEnd(field_sensor)
        field_rate = bi_o_edge_rate_map(field_front_end, field)
        field_plan = prepare_wfs_optics(field_front_end, field,
            field_rate)
        form_wfs_optical_products!(field_rate, field, field_plan)
        AdaptiveOpticsSim.Backends.synchronize_backend!(
            AdaptiveOpticsSim.Backends.execution_style(field_rate.values))
        @test field_rate.values isa BackendArray
        @test isapprox(Array(field_rate.values), Array(gpu_rate.values);
            rtol=T(3e-5), atol=T(3e-5))

        four_pupil_detector = Detector(noise=NoiseNone(),
            exposure_duration=T(0.4), qe=T(0.5),
            response_model=NullFrameResponse(), T=T, backend=selector)
        four_pupil_observation = WFSObservation(similar(gpu_rate.values);
            units=:electron_count, layout=:four_pupil_mosaic)
        four_pupil_acquisition = prepare_wfs_acquisition(
            four_pupil_detector, gpu_rate, four_pupil_observation)
        acquire_wfs_observation!(four_pupil_observation, gpu_rate,
            four_pupil_acquisition, Xoshiro(0x5042))
        AdaptiveOpticsSim.Backends.synchronize_backend!(
            AdaptiveOpticsSim.Backends.execution_style(
                four_pupil_observation.storage))
        @test four_pupil_observation.storage isa BackendArray
        @test isapprox(Array(four_pupil_observation.storage),
            Array(gpu_rate.values) .* T(0.2); rtol=T(3e-5), atol=T(3e-5))

        spectral_source = with_spectrum(src,
            SpectralBundle(T[0.7e-6, 0.9e-6], T[0.25, 0.75]; T=T))
        spectral_front_end = BiOEdgeOpticalFrontEnd(
            gpu_sensor, spectral_source)
        spectral_rates = bi_o_edge_rate_map(spectral_front_end, pupil)
        spectral_plan = prepare_wfs_optics(spectral_front_end,
            pupil, spectral_rates)
        form_wfs_optical_products!(spectral_rates, pupil, spectral_plan)
        @test all(product -> product.values isa BackendArray,
            spectral_rates)

        path_source = Asterism([
            Source(band=:custom, wavelength=wavelength(src),
                photon_irradiance=T(1), T=T),
            Source(band=:custom, wavelength=wavelength(src),
                photon_irradiance=T(3), T=T),
        ])
        second_pupil = PupilFunction(tel; T=T, backend=selector)
        copyto!(second_pupil.opd, pupil.opd)
        path_front_end = BiOEdgeOpticalFrontEnd(gpu_sensor, path_source)
        path_inputs = (pupil, second_pupil)
        path_rates = bi_o_edge_rate_map(path_front_end, path_inputs)
        path_plan = prepare_wfs_optics(path_front_end,
            path_inputs, path_rates)
        form_wfs_optical_products!(path_rates, path_inputs, path_plan)
        @test all(product -> product.values isa BackendArray, path_rates)
        @test isapprox(sum(Array(path_rates[1].values)) /
            sum(Array(path_rates[2].values)), T(1 / 3); rtol=T(3e-5))

        for lgs in (
            LGSSource(wavelength=wavelength(src),
                photon_irradiance=T(4), elongation_factor=T(1.8), T=T),
            LGSSource(wavelength=wavelength(src),
                photon_irradiance=T(4),
                sodium_layer_profile=SodiumLayerProfile(
                    T[80_000, 90_000, 100_000], T[0.2, 0.6, 0.2]),
                laser_launch_xy_m=(T(1), T(-0.5)),
                fwhm_spot_up=T(0.8), T=T),
        )
            cpu_lgs_sensor = BiOEdgeWFS(four_pupil_cpu_tel;
                pupil_samples=2, modulation=0, T=T)
            gpu_lgs_sensor = BiOEdgeWFS(tel; pupil_samples=2,
                modulation=0, T=T, backend=selector)
            cpu_lgs_front_end = BiOEdgeOpticalFrontEnd(cpu_lgs_sensor, lgs)
            gpu_lgs_front_end = BiOEdgeOpticalFrontEnd(gpu_lgs_sensor, lgs)
            cpu_lgs_rate = bi_o_edge_rate_map(
                cpu_lgs_front_end, four_pupil_cpu)
            gpu_lgs_rate = bi_o_edge_rate_map(gpu_lgs_front_end, pupil)
            cpu_lgs_plan = prepare_wfs_optics(
                cpu_lgs_front_end, four_pupil_cpu, cpu_lgs_rate)
            gpu_lgs_plan = prepare_wfs_optics(
                gpu_lgs_front_end, pupil, gpu_lgs_rate)
            form_wfs_optical_products!(cpu_lgs_rate, four_pupil_cpu,
                cpu_lgs_plan)
            form_wfs_optical_products!(gpu_lgs_rate, pupil, gpu_lgs_plan)
            AdaptiveOpticsSim.Backends.synchronize_backend!(
                AdaptiveOpticsSim.Backends.execution_style(gpu_lgs_rate.values))
            @test isapprox(Array(gpu_lgs_rate.values), cpu_lgs_rate.values;
                rtol=T(5e-5), atol=T(5e-5))
        end
    end

    cpu_measurement = WFSMeasurement(zeros(T, 4, 4);
        units=:detector_signal, kind=:cpu_copy)
    mismatch = try
        prepare_wfs_estimation(ContractCopyEstimator(
            :detector_signal, :cpu_copy), observation,
            cpu_measurement)
        nothing
    catch err
        err
    end
    @test mismatch isa WFSPreparationError
    @test mismatch.reason === :backend
    run_optional_zernike_curvature_stages(B, BackendArray)
    return nothing
end

function run_optional_zernike_curvature_stages(
    ::Type{B}, BackendArray) where {B<:AdaptiveOpticsSim.Backends.GPUBackendTag}
    selector = backend_selector(B)
    T = Float32
    cpu_tel = Telescope(resolution=8, diameter=T(4),
        central_obstruction=zero(T), T=T, backend=CPUBackend())
    gpu_tel = Telescope(resolution=8, diameter=T(4),
        central_obstruction=zero(T), T=T, backend=selector)
    source = Source(band=:custom, wavelength=T(0.75e-6),
        photon_irradiance=T(8), T=T)
    cpu_pupil = PupilFunction(cpu_tel; T=T)
    gpu_pupil = PupilFunction(gpu_tel; T=T, backend=selector)
    opd = reshape(T.(1:64), 8, 8) .* T(1e-10)
    copyto!(cpu_pupil.opd, opd)
    copyto!(gpu_pupil.opd, opd)

    cpu_zernike = ZernikeWFS(cpu_tel; pupil_samples=4, T=T)
    gpu_zernike = ZernikeWFS(gpu_tel; pupil_samples=4, T=T,
        backend=selector)
    cpu_zernike_rate = zernike_rate_map(
        ZernikeOpticalFrontEnd(cpu_zernike, source), cpu_pupil)
    gpu_zernike_rate = zernike_rate_map(
        ZernikeOpticalFrontEnd(gpu_zernike, source), gpu_pupil)
    cpu_zernike_plan = prepare_wfs_optics(
        ZernikeOpticalFrontEnd(cpu_zernike, source), cpu_pupil,
        cpu_zernike_rate)
    gpu_zernike_plan = prepare_wfs_optics(
        ZernikeOpticalFrontEnd(gpu_zernike, source), gpu_pupil,
        gpu_zernike_rate)
    form_wfs_optical_products!(cpu_zernike_rate, cpu_pupil,
        cpu_zernike_plan)
    form_wfs_optical_products!(gpu_zernike_rate, gpu_pupil,
        gpu_zernike_plan)
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(gpu_zernike_rate.values))
    @test gpu_zernike_rate.values isa BackendArray
    @test isapprox(Array(gpu_zernike_rate.values),
        cpu_zernike_rate.values; rtol=T(4e-5), atol=T(4e-5))

    zernike_detector = Detector(noise=NoiseNone(),
        exposure_duration=T(0.25), qe=T(0.4),
        response_model=NullFrameResponse(), T=T, backend=selector)
    zernike_observation = WFSObservation(similar(gpu_zernike_rate.values);
        units=:electron_count, layout=:zernike_pupil_image)
    zernike_acquisition = prepare_wfs_acquisition(zernike_detector,
        gpu_zernike_rate, zernike_observation)
    acquire_wfs_observation!(zernike_observation, gpu_zernike_rate,
        zernike_acquisition, Xoshiro(0x5a47))
    @test zernike_observation.storage isa BackendArray
    @test all(isfinite, Array(zernike_observation.storage))

    cpu_curvature = CurvatureWFS(cpu_tel; pupil_samples=4, T=T)
    gpu_curvature = CurvatureWFS(gpu_tel; pupil_samples=4, T=T,
        backend=selector)
    cpu_rates = curvature_rate_maps(
        CurvatureOpticalFrontEnd(cpu_curvature, source), cpu_pupil)
    gpu_rates = curvature_rate_maps(
        CurvatureOpticalFrontEnd(gpu_curvature, source), gpu_pupil)
    cpu_curvature_plan = prepare_wfs_optics(
        CurvatureOpticalFrontEnd(cpu_curvature, source), cpu_pupil,
        cpu_rates)
    gpu_curvature_plan = prepare_wfs_optics(
        CurvatureOpticalFrontEnd(gpu_curvature, source), gpu_pupil,
        gpu_rates)
    form_wfs_optical_products!(cpu_rates, cpu_pupil, cpu_curvature_plan)
    form_wfs_optical_products!(gpu_rates, gpu_pupil, gpu_curvature_plan)
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(gpu_rates[1].values))
    @test all(rate -> rate.values isa BackendArray, gpu_rates)
    @test isapprox(Array(gpu_rates[1].values), cpu_rates[1].values;
        rtol=T(5e-5), atol=T(5e-5))
    @test isapprox(Array(gpu_rates[2].values), cpu_rates[2].values;
        rtol=T(5e-5), atol=T(5e-5))

    plus_detector = Detector(noise=NoiseNone(),
        exposure_duration=T(0.25), qe=T(0.4),
        response_model=NullFrameResponse(), T=T, backend=selector)
    minus_detector = Detector(noise=NoiseNone(),
        exposure_duration=T(0.5), qe=T(0.5),
        response_model=NullFrameResponse(), T=T, backend=selector)
    plus_observation = WFSObservation(similar(gpu_rates[1].values);
        units=:electron_count, layout=:curvature_branch_image)
    minus_observation = WFSObservation(similar(gpu_rates[2].values);
        units=:electron_count, layout=:curvature_branch_image)
    observations = (plus_observation, minus_observation)
    multiple_acquisition = prepare_wfs_acquisition(
        (plus_detector, minus_detector), gpu_rates, observations;
        source=source)
    acquire_wfs_observation!(observations, gpu_rates,
        multiple_acquisition, Xoshiro(0x4355))
    @test isapprox(Array(plus_observation.storage),
        Array(gpu_rates[1].values) .* T(0.1);
        rtol=T(3e-5), atol=T(3e-5))
    @test isapprox(Array(minus_observation.storage),
        Array(gpu_rates[2].values) .* T(0.25);
        rtol=T(3e-5), atol=T(3e-5))

    packed_detector = Detector(noise=NoiseNone(),
        exposure_duration=T(0.25), qe=T(0.5),
        response_model=NullFrameResponse(), T=T, backend=selector)
    packed_model = CurvaturePackedAcquisition(packed_detector)
    packed_storage = similar(gpu_rates[1].values, T, 8, 4)
    packed_observation = WFSObservation(packed_storage;
        units=:electron_count, layout=:curvature_branch_regions)
    packed_acquisition = prepare_wfs_acquisition(packed_model, gpu_rates,
        packed_observation)
    acquire_wfs_observation!(packed_observation, gpu_rates,
        packed_acquisition, Xoshiro(0x4356))
    packed_host = Array(packed_observation.storage)
    @test packed_observation.storage isa BackendArray
    @test isapprox(packed_host[1:4, :],
        Array(gpu_rates[1].values) .* T(0.125);
        rtol=T(3e-5), atol=T(3e-5))
    @test isapprox(packed_host[5:8, :],
        Array(gpu_rates[2].values) .* T(0.125);
        rtol=T(3e-5), atol=T(3e-5))

    spad = SPADArrayDetector((2, 16); exposure_duration=T(0.25),
        noise=NoiseNone(),
        sensor=SPADArraySensor(active_area_detection_efficiency=T(0.5),
            dark_count_rate=zero(T), fill_factor=one(T)),
        T=T, backend=selector)
    counting_model = CurvaturePackedAcquisition(spad;
        readout_model=CurvatureChannelReadout(), source=source)
    counting_storage = similar(gpu_rates[1].values, T, 2, 16)
    counting_observation = WFSObservation(counting_storage;
        units=:photon_count, layout=:curvature_branch_channels)
    counting_acquisition = prepare_wfs_acquisition(counting_model,
        gpu_rates, counting_observation)
    acquire_wfs_observation!(counting_observation, gpu_rates,
        counting_acquisition, Xoshiro(0x4357))
    counting_host = Array(counting_observation.storage)
    expected_counting = zeros(T, 2, 16)
    counting_plus_host = Array(gpu_rates[1].values)
    counting_minus_host = Array(gpu_rates[2].values)
    @inbounds for i in 1:4, j in 1:4
        index = (i - 1) * 4 + j
        expected_counting[1, index] = counting_plus_host[i, j] * T(0.125)
        expected_counting[2, index] = counting_minus_host[i, j] * T(0.125)
    end
    @test counting_observation.storage isa BackendArray
    @test all(isfinite, counting_host)
    @test isapprox(counting_host, expected_counting;
        rtol=T(3e-5), atol=T(3e-5))

    linear_apd = LinearAPDDetector(
        topology=LinearAPDChannelBank(32),
        exposure_duration=T(0.25), qe=T(0.5), avalanche_gain=T(2),
        conversion_gain=T(2), noise=NoiseNone(), T=T,
        backend=selector)
    linear_model = CurvaturePackedAcquisition(linear_apd;
        readout_model=CurvatureChannelReadout())
    linear_storage = similar(gpu_rates[1].values, T, 2, 16)
    linear_observation = WFSObservation(linear_storage;
        units=:detector_count, layout=:curvature_branch_channels)
    linear_acquisition = prepare_wfs_acquisition(linear_model,
        gpu_rates, linear_observation)
    acquire_wfs_observation!(linear_observation, gpu_rates,
        linear_acquisition, Xoshiro(0x4358))
    linear_host = Array(linear_observation.storage)
    expected_linear = zeros(T, 2, 16)
    plus_host = Array(gpu_rates[1].values)
    minus_host = Array(gpu_rates[2].values)
    @inbounds for i in 1:4, j in 1:4
        index = (i - 1) * 4 + j
        expected_linear[1, index] = plus_host[i, j] * T(0.5)
        expected_linear[2, index] = minus_host[i, j] * T(0.5)
    end
    @test linear_observation.storage isa BackendArray
    @test isapprox(linear_host, expected_linear;
        rtol=T(3e-5), atol=T(3e-5))

    return nothing
end

function run_optional_plane_product_checks(tel::Telescope,
    src::AdaptiveOpticsSim.Optics.AbstractSource,
    selector::AdaptiveOpticsSim.Backends.AbstractArrayBackend, BackendArray,
    ::Type{T}) where {T<:AbstractFloat}
    wavefront = PupilFunction(tel; T=T, backend=selector)
    field = ElectricField(wavefront, src; zero_padding=2, T=T)
    formation = prepare_pupil_field(wavefront, src, field)
    fill_electric_field!(field, wavefront, formation)
    @test wavefront.amplitude isa BackendArray
    @test wavefront.opd isa BackendArray
    @test field.values isa BackendArray
    @test field.metadata.device == compute_device(field.values)
    field_view = @view field.values[:, :]
    for wrapper in (
        field_view,
        reshape(field_view, 1, length(field_view)),
        transpose(field_view),
        PermutedDimsArray(field_view, (2, 1)),
    )
        @test compute_device(wrapper) == field.metadata.device
    end

    wrapped_intensity_parent = similar(wavefront.opd, T, 4, 4)
    fill!(wrapped_intensity_parent, one(T))
    wrapped_intensity_view = @view wrapped_intensity_parent[:, :]
    for wrapper in (
        wrapped_intensity_view,
        reshape(wrapped_intensity_view, 1, length(wrapped_intensity_view)),
        transpose(wrapped_intensity_view),
        PermutedDimsArray(wrapped_intensity_view, (2, 1)),
    )
        @test typeof(backend(wrapper)) === typeof(selector)
        @test typeof(AdaptiveOpticsSim.Backends.array_backend_selector(
            typeof(wrapper))) === typeof(selector)
        wrapper_metadata = OpticalPlaneMetadata(FocalPlane(), wrapper;
            coordinate_domain=AngularCoordinates(),
            sampling=(one(T), one(T)),
            normalization=PhotonRateNormalization(),
            spatial_measure=CellIntegratedMeasure(),
            coherence=IncoherentIntensityAddition())
        wrapper_map = IntensityMap(wrapper_metadata, wrapper)
        @test wrapper_map.values === wrapper
        @test wrapper_map.metadata.device == field.metadata.device
    end

    prepared = prepare_direct_imaging(wavefront, src; zero_padding=2)
    formed = form_direct_image!(prepared)
    @test formed.values isa BackendArray
    @test formed.metadata.device == wavefront.metadata.device
    @test sum(Array(formed.values)) ≈
        sum(Array(pupil_photon_rate_map(tel, src))) atol=T(2e-5) rtol=T(2e-5)

    off_axis_src = Source(band=:I, magnitude=zero(T),
        separation_arcsec=T(0.08), position_angle_deg=T(90), T=T)
    off_axis = prepare_direct_imaging(wavefront, off_axis_src; zero_padding=2)
    off_axis_map = form_direct_image!(off_axis)
    @test off_axis_map.values isa BackendArray
    @test off_axis_map.metadata.device == formed.metadata.device
    @test off_axis.plan.shift_samples isa NTuple{2,Int}
    @test off_axis.plan.shift_samples != (0, 0)
    @test Array(off_axis_map.values) ≈ circshift(Array(formed.values),
        off_axis.plan.shift_samples) rtol=T(2e-5) atol=T(2e-5)

    spectral_src = with_spectrum(src,
        SpectralBundle(T[0.7e-6, 0.9e-6], T[0.4, 0.6]; T=T))
    spectral = prepare_direct_imaging(wavefront, spectral_src; zero_padding=2)
    spectral_products = form_direct_image!(spectral)
    @test spectral_products isa OpticalProductBundle
    @test length(spectral_products) == 2
    @test all(product -> product.values isa BackendArray,
        spectral_products)
    @test all(product -> product.metadata.device == formed.metadata.device,
        spectral_products)
    @test spectral_products[1].metadata.sampling !=
        spectral_products[2].metadata.sampling

    extended_src = with_extended_source(src,
        GaussianDiskSourceModel(sigma_arcsec=T(0.02), n_side=5, T=T))
    extended = prepare_direct_imaging(wavefront,
        extended_source_asterism(extended_src); zero_padding=1)
    @test extended.components isa FixedSizeVector
    @test extended.products isa FixedSizeVector
    @test isconcretetype(eltype(extended.components))
    @test isconcretetype(eltype(extended.products))
    @test length(extended.components) == 25
    extended_map = form_direct_image!(extended)
    @test extended_map.values isa BackendArray
    @test all(product -> product.values isa BackendArray,
        extended.products)
    @test all(product -> product.metadata.device == formed.metadata.device,
        extended.products)
    @test sum(Array(extended_map.values)) ≈
        sum(Array(pupil_photon_rate_map(tel, src))) atol=T(2e-5) rtol=T(2e-5)

    host_values = zeros(T, size(formed.values))
    host_metadata = OpticalPlaneMetadata(FocalPlane(), host_values;
        coordinate_domain=AngularCoordinates(),
        sampling=formed.metadata.sampling,
        origin=formed.metadata.origin,
        spectral=formed.metadata.spectral,
        normalization=PhotonRateNormalization(),
        spatial_measure=CellIntegratedMeasure(),
        coherence=IncoherentIntensityAddition())
    host_output = IntensityMap(host_metadata, host_values)
    @test_throws InvalidConfiguration prepare_direct_imaging(
        wavefront, src, prepared.field, host_output)

    sum_output_values = similar(formed.values)
    first_sum_values = similar(formed.values)
    second_sum_values = similar(formed.values)
    fill!(first_sum_values, one(T))
    fill!(second_sum_values, T(2))
    sum_output = IntensityMap(formed.metadata, sum_output_values)
    first_sum_input = IntensityMap(formed.metadata, first_sum_values)
    second_sum_input = IntensityMap(formed.metadata, second_sum_values)
    sum_plan = prepare_incoherent_sum(sum_output, first_sum_input,
        second_sum_input)
    accumulate_intensity!(sum_output,
        (first_sum_input, second_sum_input), sum_plan)
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(sum_output.values))
    @test sum_output.values isa BackendArray
    @test Array(sum_output.values) == fill(T(3), size(sum_output.values))

    detector = Detector(exposure_duration=T(0.5), noise=NoiseNone(),
        qe=T(0.5), response_model=NullFrameResponse(), T=T,
        backend=selector)
    acquisition = prepare_detector_acquisition(detector, prepared.output)
    detector_frame = capture!(acquisition; rng=MersenneTwister(301))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(detector_frame))
    @test detector_frame isa BackendArray
    @test sum(Array(detector_frame)) ≈
        sum(Array(prepared.output.values)) * T(0.25) atol=T(2e-5) rtol=T(2e-5)
    identical_detector = Detector(exposure_duration=T(0.5), noise=NoiseNone(),
        qe=T(0.5), response_model=NullFrameResponse(), T=T,
        backend=selector)
    @test identical_detector.params === detector.params
    @test identical_detector.state !== detector.state
    @test !applicable(capture!, identical_detector, prepared.output,
        acquisition, MersenneTwister(301))

    long_detector = Detector(exposure_duration=T(1.0), noise=NoiseNone(),
        qe=T(0.5), response_model=NullFrameResponse(), T=T,
        backend=selector)
    long_acquisition = prepare_detector_acquisition(long_detector,
        prepared.output)
    @test Detectors.detector_acquisition_input(acquisition).values ===
        prepared.output.values
    @test Detectors.detector_acquisition_input(long_acquisition).values ===
        prepared.output.values
    short_snapshot = copy(Array(detector_frame))
    long_frame = capture!(long_acquisition; rng=MersenneTwister(307))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(long_frame))
    @test Array(long_frame) ≈ 2 .* short_snapshot atol=T(2e-5) rtol=T(2e-5)

    incremental_detector = Detector(exposure_duration=T(0.5),
        noise=NoiseNone(), qe=T(0.5), response_model=NullFrameResponse(),
        T=T, backend=selector)
    incremental_acquisition = prepare_detector_acquisition(
        incremental_detector, prepared.output)
    capture!(incremental_acquisition; rng=MersenneTwister(305),
        integration_duration=T(0.2))
    @test !readout_ready(incremental_detector)
    incremental_frame = capture!(incremental_acquisition;
        rng=MersenneTwister(306),
        integration_duration=T(0.3))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(incremental_frame))
    @test incremental_frame isa BackendArray
    @test readout_ready(incremental_detector)
    @test sum(Array(incremental_frame)) ≈
        sum(Array(prepared.output.values)) * T(0.25) atol=T(2e-5) rtol=T(2e-5)
    cpu_detector = Detector(exposure_duration=T(0.5), noise=NoiseNone(),
        qe=T(0.5), response_model=NullFrameResponse(), T=T,
        backend=CPUBackend())
    @test_throws InvalidConfiguration prepare_detector_acquisition(
        cpu_detector, prepared.output)
    @test !applicable(capture!, cpu_detector, prepared.output,
        acquisition, MersenneTwister(306))

    density_host = zeros(T, 9, 9)
    density_host[3, 5] = T(8)
    density_values = BackendArray(density_host)
    density_metadata = OpticalPlaneMetadata(FocalPlane(), density_values;
        coordinate_domain=AngularCoordinates(), sampling=(T(0.5), T(0.25)),
        spectral=MonochromaticChannel(T(wavelength(src))),
        normalization=AdaptiveOpticsSim.Optics.PhotonRateNormalization(),
        spatial_measure=AdaptiveOpticsSim.Optics.SpatialDensityMeasure(),
        coherence=AdaptiveOpticsSim.Optics.IncoherentIntensityAddition())
    density_map = IntensityMap(density_metadata, density_values)
    response_kernel = T[0 0.1 0; 0.1 0.6 0.1; 0 0.1 0]
    response_detector = Detector(exposure_duration=T(2), noise=NoiseNone(),
        qe=T(0.5), binning=3,
        response_model=SampledFrameResponse(response_kernel; T=T), T=T,
        backend=selector)
    response_acquisition = prepare_detector_acquisition(response_detector,
        density_map)
    response_frame = capture!(response_acquisition;
        rng=MersenneTwister(302))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(response_frame))
    manual_response = zeros(T, 9, 9)
    manual_response[3, 5] = T(4.8)
    manual_response[2, 5] = T(0.8)
    manual_response[4, 5] = T(0.8)
    manual_response[3, 4] = T(0.8)
    manual_response[3, 6] = T(0.8)
    manual_binned = zeros(T, 3, 3)
    AdaptiveOpticsSim.bin2d!(manual_binned, manual_response, 3)
    @test Array(response_frame) ≈ manual_binned .* T(0.125) atol=T(1e-6) rtol=T(1e-6)

    asymmetric_kernel = T[0 0 0; 0.1 0.2 0.7; 0 0 0]
    edge_host = zeros(T, 9, 9)
    edge_host[5, end] = one(T)
    edge_values = BackendArray(edge_host)
    edge_metadata = OpticalPlaneMetadata(FocalPlane(), edge_values;
        coordinate_domain=AngularCoordinates(), sampling=(one(T), one(T)),
        spectral=MonochromaticChannel(T(wavelength(src))),
        normalization=AdaptiveOpticsSim.Optics.PhotonRateNormalization(),
        spatial_measure=AdaptiveOpticsSim.Optics.CellIntegratedMeasure(),
        coherence=AdaptiveOpticsSim.Optics.IncoherentIntensityAddition())
    edge_map = IntensityMap(edge_metadata, edge_values)
    edge_detector = Detector(exposure_duration=one(T), noise=NoiseNone(),
        qe=one(T), response_model=SampledFrameResponse(asymmetric_kernel; T=T),
        T=T, backend=selector)
    edge_acquisition = prepare_detector_acquisition(edge_detector, edge_map)
    edge_frame = capture!(edge_acquisition; rng=MersenneTwister(303))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(edge_frame))
    @test sum(Array(edge_frame)) ≈ T(0.3) atol=T(2e-6) rtol=T(2e-6)
    @test sum(Array(edge_frame)) <= sum(edge_host) + T(2e-6)

    edge_cube_host = zeros(T, 2, 9, 9)
    edge_cube_host[1, 5, end] = one(T)
    edge_cube_host[2, 5, 1] = one(T)
    edge_cube = BackendArray(edge_cube_host)
    edge_scratch = similar(edge_cube)
    edge_stack = AdaptiveOpticsSim.Detectors.capture_stack!(edge_detector, edge_cube,
        edge_scratch; rng=MersenneTwister(304))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(edge_stack))
    edge_stack_host = Array(edge_stack)
    @test sum(@view(edge_stack_host[1, :, :])) ≈ T(0.3) atol=T(2e-6) rtol=T(2e-6)
    @test sum(@view(edge_stack_host[2, :, :])) ≈ T(0.9) atol=T(2e-6) rtol=T(2e-6)

    fraunhofer = FraunhoferPropagation(field)
    propagated = propagation_output(field, fraunhofer)
    propagate_field!(propagated, field, fraunhofer)
    @test propagated.values isa BackendArray
    @test propagated.metadata.kind isa FocalPlane

    spatial_filter = SpatialFilter(tel; shape=SquareFilter(), diameter=5,
        zero_padding=2, T=T, backend=selector)
    spatial_field = ElectricField(wavefront, src; zero_padding=2, T=T,
        normalization=DimensionlessNormalization(),
        spatial_measure=PointSampledMeasure(),
        coherence=CoherentFieldCombination())
    spatial_formation = prepare_pupil_field(wavefront, src, spatial_field;
        center_even_grid=false, amplitude_scale=1)
    fill_electric_field!(spatial_field, wavefront, spatial_formation)
    filtered = PupilFunction(tel; T=T, backend=selector)
    prepared_spatial_filter = prepare_spatial_filter(
        tel, spatial_filter, spatial_field,
        filtered)
    filter!(prepared_spatial_filter)
    @test filtered.opd isa BackendArray
    @test filtered.amplitude isa BackendArray
    @test all(isfinite, Array(filtered.opd))
    @test all(isfinite, Array(filtered.amplitude))

    independent_path = PupilFunction(tel; T=T, backend=selector)
    independent_opd = copy(Array(independent_path.opd))
    dm = DeformableMirror(tel; n_act=4, influence_width=T(0.3), T=T,
        backend=selector)
    fill!(dm.state.coefs, T(1e-8))
    update_surface!(dm)
    apply_surface!(wavefront, dm, DMReplace())
    @test Array(wavefront.opd) ≈ Array(surface_opd(dm)) atol=zero(T) rtol=zero(T)
    @test Array(independent_path.opd) == independent_opd
    return nothing
end

function _build_optional_low_order_wfs(tel::Telescope, backend, ::Type{T}, ::Val{:pyr}) where {T<:AbstractFloat}
    return PyramidWFS(tel; pupil_samples=4, modulation=T(1.0), T=T, backend=backend)
end

function _build_optional_low_order_wfs(tel::Telescope, backend, ::Type{T}, ::Val{:bio}) where {T<:AbstractFloat}
    return BiOEdgeWFS(tel; pupil_samples=4, modulation=T(1.0), T=T, backend=backend)
end

function _build_optional_low_order_optic(tel::Telescope, backend,
    ::Type{T}, ::Val{:tiptilt}) where {T<:AbstractFloat}
    return TipTiltMirror(
        tel;
        scale=T(0.1),
        T=T,
        backend=backend,
        label=:tiptilt,
    )
end

function _build_optional_low_order_optic(tel::Telescope, backend,
    ::Type{T}, ::Val{:steering}) where {T<:AbstractFloat}
    return ModalControllableOptic(
        tel,
        CartesianTiltBasis(; scale=T(0.1));
        labels=:steering,
        T=T,
        backend=backend,
    )
end

function _build_optional_low_order_optic(tel::Telescope, backend,
    ::Type{T}, ::Val{:focus}) where {T<:AbstractFloat}
    return FocusStage(
        tel;
        scale=T(0.1),
        T=T,
        backend=backend,
        label=:focus,
    )
end

function _optional_low_order_commands(::Type{T}, ::Val{:focus}) where {T<:AbstractFloat}
    return fill(T(1.25e-7), 1), fill(T(2.5e-7), 1), fill(T(2e-8), 16)
end

function _optional_low_order_commands(::Type{T}, ::Union{Val{:tiptilt},Val{:steering}}) where {T<:AbstractFloat}
    # These coefficients produce nanometre-scale OPD. Centimetre-scale test
    # commands make diffraction output chaotic under otherwise sub-ulp
    # Float32 backend differences and do not represent an AO operating point.
    return fill(T(1.25e-7), 2), fill(T(2.5e-7), 2), fill(T(2e-8), 16)
end

function _optional_low_order_tolerances(::Val{:focus}, ::Val{:pyr}=Val(:pyr))
    return (product_rtol=5f-3, product_atol=6f-3, frame_rtol=6f-3, frame_atol=1f6)
end

function _optional_low_order_tolerances(::Union{Val{:tiptilt},Val{:steering}}, ::Val{:pyr})
    return (product_rtol=3f-3, product_atol=4f-3, frame_rtol=4f-3, frame_atol=1f6)
end

function _optional_low_order_tolerances(::Val{:tiptilt}, ::Val{:bio})
    return (product_rtol=1.5f-1, product_atol=4f-3, frame_rtol=6f-1, frame_atol=1f6)
end

function _prepare_optional_independent_wfs(wfs::PyramidWFS, pupil,
    source, detector)
    front_end = PyramidOpticalFrontEnd(wfs, source)
    rate = pyramid_rate_map(front_end, pupil)
    optics = prepare_wfs_optics(front_end, pupil, rate)
    observation = WFSObservation(
        similar(intensity_values(rate));
        units=:electron_count,
        layout=:four_pupil_mosaic,
    )
    acquisition = prepare_wfs_acquisition(
        detector, rate, observation; source)
    return (; rate, optics, observation, acquisition)
end

function _prepare_optional_independent_wfs(wfs::BiOEdgeWFS, pupil,
    source, detector)
    front_end = BiOEdgeOpticalFrontEnd(wfs, source)
    rate = bi_o_edge_rate_map(front_end, pupil)
    optics = prepare_wfs_optics(front_end, pupil, rate)
    observation = WFSObservation(
        similar(intensity_values(rate));
        units=:electron_count,
        layout=:four_pupil_mosaic,
    )
    acquisition = prepare_wfs_acquisition(
        detector, rate, observation; source)
    return (; rate, optics, observation, acquisition)
end

function _build_optional_independent_optics_case(backend, ::Type{T},
    case::Val, wfs_case::Val) where {T<:AbstractFloat}
    tel = Telescope(
        resolution=16,
        diameter=T(8),
        central_obstruction=zero(T),
        T=T,
        backend=backend,
    )
    source = Source(band=:I, magnitude=0, T=T)
    pupil = PupilFunction(tel; T=T, backend=backend)
    low_order = _build_optional_low_order_optic(tel, backend, T, case)
    dm = DeformableMirror(
        tel;
        n_act=4,
        influence_width=T(0.3),
        T=T,
        backend=backend,
    )
    wfs = _build_optional_low_order_wfs(
        tel,
        backend,
        T,
        wfs_case,
    )
    detector = Detector(
        noise=NoiseNone(),
        exposure_duration=one(T),
        qe=one(T),
        binning=1,
        T=T,
        backend=backend,
    )
    prepare_runtime_wfs!(wfs, pupil, source)
    prepared_wfs = _prepare_optional_independent_wfs(
        wfs, pupil, source, detector)
    return (; pupil, source, low_order, dm, wfs, detector, prepared_wfs...)
end

function _optional_independent_wfs_products!(prepared,
    ::Union{PyramidWFS,BiOEdgeWFS})
    form_wfs_optical_products!(
        prepared.rate, prepared.pupil, prepared.optics)
    acquire_wfs_observation!(
        prepared.observation,
        prepared.rate,
        prepared.acquisition,
        MersenneTwister(91),
    )
    return intensity_values(prepared.rate),
        observation_storage(prepared.observation)
end

function _optional_independent_optics_snapshot!(prepared,
    low_order_command, dm_command)
    set_command!(prepared.low_order, low_order_command)
    set_command!(prepared.dm, dm_command)
    reset_opd!(prepared.pupil)
    for optic in (prepared.low_order, prepared.dm)
        update_surface!(optic)
        apply_surface!(prepared.pupil, optic, DMAdditive())
    end
    product, frame = _optional_independent_wfs_products!(
        prepared, prepared.wfs)
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(product))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(frame))
    return (
        low_order_command=copy(AdaptiveOpticsSim.Optics.command_storage(
            prepared.low_order)),
        dm_command=copy(AdaptiveOpticsSim.Optics.command_storage(prepared.dm)),
        product=copy(product),
        frame=copy(frame),
    )
end

function _run_optional_independent_optics_case(::Type{B}, case::Val{K},
    wfs_case::Val{W}=Val(:pyr)) where {
    B<:AdaptiveOpticsSim.Backends.GPUBackendTag,K,W,
}
    T = Float32
    cpu = _build_optional_independent_optics_case(
        CPUBackend(),
        T,
        case,
        wfs_case,
    )
    gpu = _build_optional_independent_optics_case(
        backend_selector(B),
        T,
        case,
        wfs_case,
    )
    initial_low_order, updated_low_order, dm_cmd = _optional_low_order_commands(T, case)
    tol = _optional_low_order_tolerances(case, wfs_case)

    cpu_initial = _optional_independent_optics_snapshot!(
        cpu,
        initial_low_order,
        dm_cmd,
    )
    gpu_initial = _optional_independent_optics_snapshot!(
        gpu,
        initial_low_order,
        dm_cmd,
    )
    @test Array(gpu_initial.low_order_command) ==
        Array(cpu_initial.low_order_command)
    @test Array(gpu_initial.dm_command) == Array(cpu_initial.dm_command)
    @test isapprox(
        Array(gpu_initial.product),
        Array(cpu_initial.product);
        rtol=tol.product_rtol,
        atol=tol.product_atol,
    )
    @test isapprox(
        Array(gpu_initial.frame),
        Array(cpu_initial.frame);
        rtol=tol.frame_rtol,
        atol=tol.frame_atol,
    )

    cpu_updated = _optional_independent_optics_snapshot!(
        cpu,
        updated_low_order,
        dm_cmd,
    )
    gpu_updated = _optional_independent_optics_snapshot!(
        gpu,
        updated_low_order,
        dm_cmd,
    )
    @test Array(gpu_updated.dm_command) == Array(gpu_initial.dm_command)
    @test isapprox(
        Array(gpu_updated.product),
        Array(cpu_updated.product);
        rtol=tol.product_rtol,
        atol=tol.product_atol,
    )
    @test isapprox(
        Array(gpu_updated.frame),
        Array(cpu_updated.frame);
        rtol=tol.frame_rtol,
        atol=tol.frame_atol,
    )
    return nothing
end

function run_optional_independent_optics_parity(
    ::Type{B},
    BackendArray,
) where {B<:AdaptiveOpticsSim.Backends.GPUBackendTag}
    _run_optional_independent_optics_case(B, Val(:tiptilt), Val(:pyr))
    _run_optional_independent_optics_case(B, Val(:tiptilt), Val(:bio))
    _run_optional_independent_optics_case(B, Val(:steering), Val(:pyr))
    _run_optional_independent_optics_case(B, Val(:focus), Val(:pyr))
    return nothing
end

function run_optional_counting_detector_parity(::Type{B}, BackendArray) where {B<:AdaptiveOpticsSim.Backends.GPUBackendTag}
    T = Float32
    selector = backend_selector(B)
    sensor_kwargs = (
        qe=T(1),
        dark_count_rate=T(0),
        fill_factor=T(1),
        characteristics=MKIDArrayCharacteristics(
            energy_resolving_power=T(12),
            photon_arrival_time_resolution_s=T(2e-6),
            wavelength_passband_m=(T(0.8e-6), T(1.4e-6)),
            T=T),
        T=T,
    )
    cpu = MKIDArrayDetector(
        noise=NoiseNone(),
        sensor=MKIDArraySensor(; sensor_kwargs...),
        output_type=UInt16,
        T=T,
        backend=CPUBackend(),
    )
    gpu = MKIDArrayDetector(
        noise=NoiseNone(),
        sensor=MKIDArraySensor(; sensor_kwargs...),
        output_type=UInt16,
        T=T,
        backend=selector,
    )
    input = reshape(T.(1:25), 5, 5)
    cpu_output = capture!(cpu, input, MersenneTwister(19))
    gpu_output = capture!(gpu, BackendArray(input), MersenneTwister(19))
    AdaptiveOpticsSim.Backends.synchronize_backend!(AdaptiveOpticsSim.Backends.execution_style(gpu_output))
    @test gpu_output isa BackendArray
    @test isapprox(Array(gpu_output), cpu_output; rtol=1f-6, atol=1f-6)
    @test isapprox(sum(Array(gpu_output)), sum(cpu_output); rtol=1f-6, atol=1f-6)

    inside_band = Source(band=:custom, wavelength=T(1.0e-6), T=T)
    outside_band = Source(band=:custom, wavelength=T(0.55e-6), T=T)
    gpu_inside = capture!(gpu, BackendArray(fill(T(2), 2, 2)), inside_band,
        MersenneTwister(20))
    AdaptiveOpticsSim.Backends.synchronize_backend!(AdaptiveOpticsSim.Backends.execution_style(gpu_inside))
    inside_host = Array(gpu_inside)
    gpu_outside = capture!(gpu, BackendArray(fill(T(2), 2, 2)), outside_band,
        MersenneTwister(20))
    AdaptiveOpticsSim.Backends.synchronize_backend!(AdaptiveOpticsSim.Backends.execution_style(gpu_outside))
    outside_host = Array(gpu_outside)
    @test inside_host == fill(T(2), 2, 2)
    @test outside_host == zeros(T, 2, 2)
    return nothing
end

function run_optional_avalanche_detector_parity(::Type{B}, BackendArray) where {B<:AdaptiveOpticsSim.Backends.GPUBackendTag}
    T = Float32
    selector = backend_selector(B)
    input = BackendArray(fill(one(T), 128, 128))

    pc_detector = Detector(noise=NoiseNone(), qe=one(T), gain=T(10),
        sensor=EMCCDSensor(operating_mode=PhotonCountingEMMode(
            threshold=T(5), detection_efficiency=T(0.5)), T=T),
        response_model=NullFrameResponse(), T=T, backend=selector)
    pc_output = capture!(pc_detector, input; rng=MersenneTwister(2026))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(pc_output))
    pc_host = Array(pc_output)
    @test all(x -> x == zero(T) || x == one(T), pc_host)
    @test T(0.47) <= sum(pc_host) / length(pc_host) <= T(0.53)

    stochastic_detector = Detector(noise=NoiseNone(), qe=one(T), gain=T(5),
        sensor=EMCCDSensor(excess_noise_factor=T(1.4),
            multiplication_model=AdaptiveOpticsSim.Detectors.
                ClippedGaussianMultiplicationApproximation(
                    minimum_conditional_noise_factor=T(0.6), T=T),
            T=T), response_model=NullFrameResponse(), T=T, backend=selector)
    stochastic_input = BackendArray(fill(T(50), 128, 128))
    stochastic_output = capture!(stochastic_detector, stochastic_input;
        rng=MersenneTwister(2027))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(stochastic_output))
    stochastic_host = Array(stochastic_output)
    @test all(x -> x >= zero(T), stochastic_host)
    @test isapprox(sum(stochastic_host) / length(stochastic_host), T(250);
        rtol=T(0.03))

    hgcdte_avalanche_detector = Detector(
        noise=NoiseNone(), qe=one(T),
        sensor=HgCdTeAvalancheArraySensor(
            avalanche_gain=T(5),
            excess_noise_factor=T(1.5),
            multiplication_model=AdaptiveOpticsSim.Detectors.
                ClippedGaussianAvalancheMultiplicationApproximation(),
            T=T),
        response_model=NullFrameResponse(), T=T, backend=selector)
    hgcdte_avalanche_input =
        BackendArray(fill(T(64), 128, 128))
    hgcdte_avalanche_output = capture!(
        hgcdte_avalanche_detector, hgcdte_avalanche_input;
        rng=MersenneTwister(2028))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(
            hgcdte_avalanche_output))
    hgcdte_avalanche_host = Array(hgcdte_avalanche_output)
    @test hgcdte_avalanche_output isa BackendArray
    @test all(>=(zero(T)), hgcdte_avalanche_host)
    @test isapprox(mean(hgcdte_avalanche_host), T(320);
        rtol=T(0.02))
    @test isapprox(var(hgcdte_avalanche_host), T(800);
        rtol=T(0.08))
    @test_throws InvalidConfiguration Detector(
        noise=NoiseNone(), qe=one(T),
        sensor=HgCdTeAvalancheArraySensor(
            avalanche_gain=T(5),
            excess_noise_factor=T(1.5),
            multiplication_model=AdaptiveOpticsSim.Detectors.
                ConditionalGammaAvalancheMultiplication(),
            T=T),
        response_model=NullFrameResponse(), T=T, backend=selector)

    ramp_detector = Detector(exposure_duration=T(2), noise=NoiseNone(),
        qe=one(T), gain=one(T),
        sensor=HgCdTeSensor(read_duration=zero(T),
            sampling_mode=UpTheRampSampling(5), T=T),
        response_model=NullFrameResponse(), T=T, backend=selector)
    ramp_output = capture!(ramp_detector,
        BackendArray(fill(T(3), 32, 32)); rng=MersenneTwister(2028))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(ramp_output))
    @test Array(ramp_output) == fill(T(6), 32, 32)
    @test Array(detector_ramp_slope(ramp_detector)) == fill(T(3), 32, 32)
    @test maximum(abs, Array(detector_ramp_intercept(ramp_detector))) <= eps(T)
    @test size(detector_ramp_cube(ramp_detector)) == (32, 32, 5)
    @test detector_ramp_read_offsets_s(ramp_detector) == T[0, 0.5, 1, 1.5, 2]
    @test AdaptiveOpticsSim.Detectors.detector_ramp_acquisition(
        ramp_detector) == :synthesized_final_charge

    linear_apd = LinearAPDDetector(topology=LinearAPDChannelBank(4),
        exposure_duration=T(0.5), qe=T(0.5), avalanche_gain=T(4),
        conversion_gain=T(2), noise=NoiseNone(), T=T, backend=selector)
    linear_output = capture!(linear_apd, BackendArray(fill(T(10), 4));
        rng=MersenneTwister(2029))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(linear_output))
    @test linear_output isa BackendArray
    @test Array(linear_output) == fill(T(20), 4)
    return nothing
end

function run_optional_skipper_ccd_checks(
    ::Type{B}, BackendArray) where {
    B<:AdaptiveOpticsSim.Backends.GPUBackendTag}
    T = Float32
    selector = backend_selector(B)
    detector = Detector(
        exposure_duration=one(T),
        noise=NoiseReadout(T(4)),
        qe=one(T),
        sensor=CCDSensor(
            sampling_mode=SkipperSampling(16),
            sample_duration=T(2e-6),
            T=T),
        response_model=NullFrameResponse(),
        T=T,
        backend=selector,
    )
    output = capture!(
        detector, BackendArray(zeros(T, 128, 128));
        rng=MersenneTwister(2031))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(output))
    host = Array(output)
    products = readout_products(detector)
    @test output isa BackendArray
    @test products isa SkipperReadoutProducts
    @test products.mean_frame isa BackendArray
    @test products.sample_count == 16
    @test detector_read_cube(detector) === nothing
    @test isapprox(mean(host), zero(T); atol=T(0.05))
    @test isapprox(var(host), one(T); rtol=T(0.05))
    metadata = detector_export_metadata(detector)
    @test metadata.sampling_read_duration == T(2e-6)
    @test metadata.sampling_acquisition_duration ==
        one(T) + T(16) * T(2e-6)
    return nothing
end

function run_optional_ingaas_deterministic_checks(
    ::Type{B}, BackendArray) where {
    B<:AdaptiveOpticsSim.Backends.GPUBackendTag}
    T = Float32
    selector = backend_selector(B)
    function persistence_detector(gain)
        return Detector(
            exposure_duration=one(T),
            noise=NoiseNone(),
            qe=one(T),
            gain=gain,
            sensor=InGaAsSensor(
                persistence_model=ExponentialPersistence(T(0.25), T(0.5)),
                T=T),
            T=T,
            backend=selector,
        )
    end
    detector = persistence_detector(T(4))
    unit_gain_detector = persistence_detector(one(T))
    illumination = BackendArray(fill(T(8), 16, 16))
    dark = BackendArray(zeros(T, 16, 16))
    first = copy(capture!(detector, illumination, MersenneTwister(2041)))
    second = copy(capture!(detector, dark, MersenneTwister(2042)))
    third = copy(capture!(detector, dark, MersenneTwister(2043)))
    unit_first = copy(capture!(
        unit_gain_detector, illumination, MersenneTwister(2041)))
    unit_second = copy(capture!(
        unit_gain_detector, dark, MersenneTwister(2042)))
    unit_third = copy(capture!(
        unit_gain_detector, dark, MersenneTwister(2043)))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(third))
    @test first isa BackendArray
    @test second isa BackendArray
    @test third isa BackendArray
    @test detector.state.latent_buffer isa BackendArray
    @test unit_gain_detector.state.latent_buffer isa BackendArray
    @test Array(first) == T(4) .* Array(unit_first) == fill(T(32), 16, 16)
    @test Array(second) == T(4) .* Array(unit_second) == fill(T(8), 16, 16)
    @test Array(third) == T(4) .* Array(unit_third) == fill(T(6), 16, 16)
    @test Array(detector.state.latent_buffer) ==
        Array(unit_gain_detector.state.latent_buffer) ==
        fill(T(1.125), 16, 16)
    metadata = detector_export_metadata(detector)
    @test metadata.frame_response == :none
    @test metadata.persistence_model == :exponential
    @test !supports_detector_mtf(detector)
    return nothing
end

function run_optional_spad_moment_checks(
    ::Type{B}, BackendArray) where {
    B<:AdaptiveOpticsSim.Backends.GPUBackendTag}
    T = Float32
    selector = backend_selector(B)
    stochastic = SPADArrayDetector((128, 128); noise=NoisePhoton(),
        sensor=SPADArraySensor(active_area_detection_efficiency=one(T),
            dead_time_model=NonParalyzableDeadTime(T(0.05)), T=T),
        T=T, backend=selector)
    stochastic_output = capture!(stochastic,
        BackendArray(fill(T(100), 128, 128)), Xoshiro(0x53504146))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(stochastic_output))
    stochastic_host = Array(stochastic_output)
    expected_mean = T(100 / 6)
    @test stochastic_output isa BackendArray
    @test isapprox(mean(stochastic_host), expected_mean; atol=T(0.2))
    @test isapprox(var(stochastic_host), expected_mean; rtol=T(0.1))
    return nothing
end

# AMDGPU/GPUCompiler on the maintained Julia 1.12.6 host can segfault while
# compiling the portable Poisson kernel. Keep deterministic SPAD semantics in
# the release target without silently promoting a stochastic AMDGPU claim.
run_optional_spad_moment_checks(
    ::Type{AdaptiveOpticsSim.Backends.AMDGPUBackendTag}, BackendArray) = nothing

function run_optional_spad_qualification_checks(
    ::Type{B}, BackendArray) where {
    B<:AdaptiveOpticsSim.Backends.GPUBackendTag}
    T = Float32
    selector = backend_selector(B)

    deterministic = SPADArrayDetector((3, 3);
        exposure_duration=T(2), noise=NoiseNone(),
        gate_model=DutyCycleGate(T(0.5)),
        sensor=SPADArraySensor(
            active_area_detection_efficiency=T(0.5),
            fill_factor=T(0.8),
            dead_time_model=NonParalyzableDeadTime(T(0.1)),
            mean_response_model=NearestNeighborCountRedistribution(T(0.4)),
            T=T),
        output_type=UInt16, T=T, backend=selector)
    impulse_host = zeros(T, 3, 3)
    impulse_host[2, 2] = T(10)
    deterministic_output = capture!(deterministic,
        BackendArray(impulse_host), Xoshiro(0x53504144))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(deterministic_output))
    # The live time is one second. The center expectation before redistribution
    # is (10 * 0.5 * 0.8) / (1 + 4 * 0.1) = 20/7 counts.
    expected = zeros(T, 3, 3)
    expected[2, 2] = T(12 / 7)
    expected[1, 2] = expected[2, 1] = expected[2, 3] =
        expected[3, 2] = T(2 / 7)
    @test deterministic.products.counts isa BackendArray
    @test deterministic.workspace.noise_buffer isa BackendArray
    @test deterministic_output isa BackendArray
    @test Array(deterministic.products.counts) ≈ expected rtol=T(2e-6)
    @test Array(deterministic_output) == round.(UInt16, expected)

    paralyzable = SPADArrayDetector((1, 3); noise=NoiseNone(),
        sensor=SPADArraySensor(active_area_detection_efficiency=one(T),
            dead_time_model=ParalyzableDeadTime(T(0.1)), T=T),
        T=T, backend=selector)
    paralyzable_input = BackendArray(reshape(T[0, 10, 1000], 1, 3))
    paralyzable_output = capture!(paralyzable, paralyzable_input,
        Xoshiro(0x53504145))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(paralyzable_output))
    @test Array(paralyzable_output) ≈
        reshape(T[0, 10exp(-1), 1000exp(-100)], 1, 3) rtol=T(2e-5)

    run_optional_spad_moment_checks(B, BackendArray)

    fixed_counts = deterministic.products.counts
    @test_throws DimensionMismatchError capture!(deterministic,
        BackendArray(zeros(T, 2, 2)), Xoshiro(0x53504147))
    @test deterministic.products.counts === fixed_counts
    return nothing
end

function run_optional_ingaas_moment_checks(
    ::Type{B}, BackendArray) where {
    B<:AdaptiveOpticsSim.Backends.GPUBackendTag}
    T = Float32
    selector = backend_selector(B)
    stochastic = Detector(
        exposure_duration=T(2),
        noise=NoiseNone(),
        qe=one(T),
        dark_current=T(1.5),
        sensor=InGaAsSensor(glow_rate=T(2.5), T=T),
        response_model=NullFrameResponse(),
        T=T,
        backend=selector,
    )
    stochastic_output = capture!(stochastic,
        BackendArray(zeros(T, 128, 128)), MersenneTwister(2044))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(stochastic_output))
    stochastic_host = Array(stochastic_output)
    @test stochastic_output isa BackendArray
    @test isapprox(mean(stochastic_host), T(8); atol=T(0.15))
    @test isapprox(var(stochastic_host), T(8); rtol=T(0.08))
    return nothing
end

# AMDGPU/GPUCompiler on the maintained Julia 1.12.6 host can segfault while
# compiling the portable Poisson kernel. Deterministic InGaAs persistence and
# residency remain release-target checks; stochastic moment qualification is a
# CUDA and CPU claim until that compiler failure is resolved.
run_optional_ingaas_moment_checks(
    ::Type{AdaptiveOpticsSim.Backends.AMDGPUBackendTag}, BackendArray) = nothing

function run_optional_ingaas_checks(
    ::Type{B}, BackendArray) where {
    B<:AdaptiveOpticsSim.Backends.GPUBackendTag}
    run_optional_ingaas_deterministic_checks(B, BackendArray)
    run_optional_ingaas_moment_checks(B, BackendArray)
    return nothing
end

backend_module_name(::Type{AdaptiveOpticsSim.Backends.CUDABackendTag}) = :CUDA
backend_module_name(::Type{AdaptiveOpticsSim.Backends.AMDGPUBackendTag}) = :AMDGPU

function backend_preloaded(::Type{B}) where {
    B<:AdaptiveOpticsSim.Backends.GPUBackendTag}
    return isdefined(Main, backend_module_name(B))
end

function backend_functional(::Type{AdaptiveOpticsSim.Backends.CUDABackendTag})
    return Base.invokelatest(getproperty(getfield(Main, :CUDA), :functional))
end

function backend_functional(::Type{AdaptiveOpticsSim.Backends.AMDGPUBackendTag})
    return Base.invokelatest(getproperty(getfield(Main, :AMDGPU), :functional))
end

run_optional_backend_plan_checks(::Type{<:AdaptiveOpticsSim.Backends.GPUBackendTag}, tel, backend) = nothing

function run_optional_pyramid_fractional_shift_checks(
    ::Type{B}, BackendArray,
) where {B<:AdaptiveOpticsSim.Backends.GPUBackendTag}
    T = Float32
    selector = backend_selector(B)
    cpu_tel = Telescope(resolution=16, diameter=T(8), T=T, backend=CPUBackend())
    device_tel = Telescope(resolution=16, diameter=T(8), T=T, backend=selector)
    cpu_pupil = PupilFunction(cpu_tel; T=T)
    device_pupil = PupilFunction(device_tel; T=T, backend=selector)
    cpu_pupil.opd .= reshape(T.(1:256), 16, 16) .* T(1e-10)
    copyto!(device_pupil.opd, cpu_pupil.opd)
    source = Source(band=:custom, wavelength=T(0.75e-6),
        photon_irradiance=one(T), T=T)
    shifts = (
        ((0.25, -0.125, -0.125, 0.25), (0.125, 0.125, -0.25, -0.25)),
        ((0.25, -0.125, 0.375, -0.25), (0.125, -0.375, 0.25, -0.125)),
    )
    policies = (
        (modulation=T(0.7), modulation_points=4),
        (modulation=zero(T), user_modulation_path=(
            (T(1.3), T(0.7), zero(T)), (T(-0.4), T(1.1), T(2)),
            (T(-0.9), T(-0.5), one(T)))),
    )
    @testset "fractional Pyramid shifts: $(backend_label(B))" begin
        for (sx, sy) in shifts, policy in policies
            options = (; pupil_samples=4,
                diffraction_padding=4, n_pix_separation=2, n_pix_edge=1,
                pupil_shift_x_pixels=sx, pupil_shift_y_pixels=sy,
                T=T, policy...)
            cpu_sensor = PyramidWFS(cpu_tel; options...)
            device_sensor = PyramidWFS(device_tel; options..., backend=selector)
            cpu_front = PyramidOpticalFrontEnd(cpu_sensor, source)
            device_front = PyramidOpticalFrontEnd(device_sensor, source)
            cpu_rate = pyramid_rate_map(cpu_front, cpu_pupil)
            device_rate = pyramid_rate_map(device_front, device_pupil)
            cpu_plan = prepare_wfs_optics(cpu_front, cpu_pupil, cpu_rate)
            device_plan = prepare_wfs_optics(device_front, device_pupil, device_rate)
            form_wfs_optical_products!(cpu_rate, cpu_pupil, cpu_plan)
            form_wfs_optical_products!(device_rate, device_pupil, device_plan)
            synchronize_backend!(execution_style(device_rate.values))
            @test device_rate.values isa BackendArray
            @test Array(pyramid_focal_mask(device_sensor)) ≈
                pyramid_focal_mask(cpu_sensor) rtol=3f-5 atol=1f-6
            device_modulation = device_sensor.front_end.modulation
            axis_1 = Array(device_modulation.axis_1_factors)
            axis_2 = Array(device_modulation.axis_2_factors)
            for point in axes(cpu_sensor.front_end.modulation.phases, 3)
                @test axis_1[:, point] * transpose(axis_2[:, point]) ≈
                    cpu_sensor.front_end.modulation.phases[:, :, point] rtol=3f-5 atol=1f-6
            end
            @test Array(device_rate.values) ≈ cpu_rate.values rtol=3f-4 atol=1f-6
            @test sum(Array(device_rate.values)) ≈ sum(cpu_rate.values) rtol=3f-5
        end
    end
    return nothing
end

function run_optional_lift_pipeline_checks(::Type{B}, array_backend,
    ::Type{T}) where {B<:AdaptiveOpticsSim.Backends.GPUBackendTag,T<:AbstractFloat}
    selector = backend_selector(B)
    lift_src = Source(band=:I, magnitude=zero(T), T=T)
    cpu_tel = Telescope(resolution=8, diameter=T(8),
        central_obstruction=zero(T), T=T, backend=CPUBackend())
    lift_tel = Telescope(resolution=8, diameter=T(8),
        central_obstruction=zero(T), T=T, backend=selector)
    zernike = ZernikeBasis(cpu_tel, 5; T=T)
    compute_zernike!(zernike, cpu_tel)
    basis_host = copy(@view zernike.modes[:, :, 2:4])
    diversity_host = T(30e-9) .* @view(zernike.modes[:, :, 5])
    truth_coefficients = T[8e-9, -4e-9, 2e-9]
    truth_opd_host = copy(diversity_host)
    @inbounds for mode_id in eachindex(truth_coefficients)
        @views @. truth_opd_host += truth_coefficients[mode_id] *
            basis_host[:, :, mode_id]
    end
    lift_basis = array_backend(basis_host)
    lift_diversity = array_backend(copy(diversity_host))
    truth_opd = array_backend(truth_opd_host)
    lift_object_kernel_host = T[0 1 0; 1 4 1; 0 1 0]
    lift_object_kernel = array_backend(lift_object_kernel_host)

    cpu_forward = prepare_lift_forward_model(cpu_tel, lift_src,
        basis_host, truth_opd_host; diversity_opd=copy(diversity_host), focal_resolution=8,
        object_kernel=lift_object_kernel_host)
    lift_forward = prepare_lift_forward_model(lift_tel, lift_src,
        lift_basis, truth_opd; diversity_opd=lift_diversity, focal_resolution=8,
        object_kernel=lift_object_kernel)
    cpu_rate = copy(intensity_values(evaluate_lift_forward!(cpu_forward)))
    lift_rate = copy(intensity_values(evaluate_lift_forward!(lift_forward)))
    @test lift_rate isa array_backend
    @test Array(lift_rate) ≈ cpu_rate rtol=T(2e-4) atol=T(1e-3)

    cpu_response = GaussianPixelResponse(response_width_px=T(0.6), T=T,
        backend=CPUBackend())
    lift_response = GaussianPixelResponse(response_width_px=T(0.6), T=T,
        backend=selector)
    cpu_response_forward = prepare_lift_forward_model(cpu_tel, lift_src,
        basis_host, truth_opd_host; diversity_opd=copy(diversity_host),
        focal_resolution=8,
        mapping=LiFTFrameMapping(response=cpu_response))
    lift_response_forward = prepare_lift_forward_model(lift_tel, lift_src,
        lift_basis, truth_opd; diversity_opd=lift_diversity,
        focal_resolution=8,
        mapping=LiFTFrameMapping(response=lift_response))
    cpu_response_rate = copy(intensity_values(evaluate_lift_forward!(
        cpu_response_forward)))
    lift_response_rate = copy(intensity_values(evaluate_lift_forward!(
        lift_response_forward)))
    prepared_response = WavefrontSensors.lift_forward_plan(
        lift_response_forward).mapping.response
    @test prepared_response.kernel !== lift_response.kernel
    @test prepared_response.kernel isa array_backend
    @test Array(lift_response_rate) ≈ cpu_response_rate rtol=T(2e-4) atol=T(1e-3)

    exposure = T(0.002)
    quantum_efficiency = T(0.8)
    photon_rate_per_unit = T(sum(cpu_rate))
    cpu_count_values = similar(cpu_rate)
    cpu_normalized_values = similar(cpu_rate)
    count_values = similar(lift_rate)
    normalized_values = similar(lift_rate)
    @. cpu_count_values = cpu_rate * exposure * quantum_efficiency
    @. cpu_normalized_values = cpu_rate / photon_rate_per_unit
    @. count_values = lift_rate * exposure * quantum_efficiency
    @. normalized_values = lift_rate / photon_rate_per_unit

    aoc_cpu_model = LiFTForwardModel(cpu_forward)
    aoc_device_model = LiFTForwardModel(lift_forward)
    @test aoc_device_model.plan === WavefrontSensors.lift_forward_plan(lift_forward)
    @test aoc_device_model.plan.pupil_amplitude isa array_backend
    @test AOCPhaseRetrieval.coefficient_count(aoc_device_model) == 3
    @test AOCPhaseRetrieval.observation_axes(aoc_device_model) == axes(lift_rate)
    aoc_device_backend = KernelAbstractions.get_backend(lift_rate)

    aoc_device_model_workspace = AOCPhaseRetrieval.allocate_model_workspace(
        aoc_device_model)
    aoc_device_prediction = AOCPhaseRetrieval.allocate_photon_rate(
        aoc_device_model)
    aoc_device_coefficients = array_backend(copy(truth_coefficients))
    @test (@inferred AOCPhaseRetrieval.predict_photon_rate!(
        aoc_device_prediction,
        aoc_device_model,
        aoc_device_model_workspace,
        aoc_device_coefficients,
    )) === aoc_device_prediction
    @test aoc_device_prediction isa array_backend
    @test aoc_device_model_workspace.opd isa array_backend
    @test compute_device(aoc_device_prediction) == compute_device(lift_rate)
    @test Array(aoc_device_prediction) ≈ Array(lift_rate) rtol=T(2e-4) atol=T(1e-3)

    plan_output_snapshot = Array(aoc_device_model.plan.diversity_opd)
    @test_throws InvalidConfiguration AOCPhaseRetrieval.predict_photon_rate!(
        aoc_device_model.plan.diversity_opd,
        aoc_device_model,
        aoc_device_model_workspace,
        aoc_device_coefficients,
    )
    @test Array(aoc_device_model.plan.diversity_opd) == plan_output_snapshot
    aliased_coefficients = @view vec(aoc_device_model_workspace.opd)[1:3]
    @test_throws InvalidConfiguration AOCPhaseRetrieval.predict_photon_rate!(
        aoc_device_prediction,
        aoc_device_model,
        aoc_device_model_workspace,
        aliased_coefficients,
    )

    aoc_domains = (
        (
            AOCPhaseRetrieval.LiFTPhotonRate(
                noise_equivalent_exposure_s=exposure,
                quantum_efficiency=quantum_efficiency,
            ),
            cpu_rate,
            lift_rate,
        ),
        (
            AOCPhaseRetrieval.LiFTExpectedCounts(exposure;
                quantum_efficiency=quantum_efficiency),
            cpu_count_values,
            count_values,
        ),
        (
            AOCPhaseRetrieval.LiFTNormalizedIntensity(photon_rate_per_unit;
                noise_equivalent_exposure_s=exposure,
                quantum_efficiency=quantum_efficiency),
            cpu_normalized_values,
            normalized_values,
        ),
    )
    aoc_rate_domain = first(first(aoc_domains))
    aoc_domain_reference_coefficients = Dict{DataType,Vector{T}}()

    # AOC KernelExecution synchronizes and may allocate host-side solver state;
    # it has no zero-Julia-allocation steady-state contract on accelerators.
    for (domain, cpu_observation, device_observation) in aoc_domains,
        jacobian_method in (
        AOCPhaseRetrieval.LiFTAnalyticJacobian(),
        AOCPhaseRetrieval.LiFTNumericalJacobian(T(1e-9)),
    )
        aoc_method = AOCPhaseRetrieval.LiFT(
            iterations=2,
            jacobian_method=jacobian_method,
            solve_mode=AOCPhaseRetrieval.LiFTSolveNormalEquations(),
            damping=AOCPhaseRetrieval.LiFTAdaptiveLevenbergMarquardt(),
            mode_indices=(1, 2),
            model_scaling=AOCPhaseRetrieval.LiFTPhysicalRatePreservation(),
            check_convergence=false,
        )
        aoc_cpu_plan = AdaptiveOpticsCalibration.prepare(
            aoc_method, AOCPhaseRetrieval.LiFTSpecification(
                aoc_cpu_model, domain))
        aoc_device_plan = AdaptiveOpticsCalibration.prepare(
            aoc_method,
            AdaptiveOpticsCalibration.KernelExecution(
                AOCPhaseRetrieval.LiFTSpecification(aoc_device_model, domain),
                aoc_device_backend;
                workgroup_size=64))
        aoc_cpu_result = AdaptiveOpticsCalibration.allocate_result(
            aoc_cpu_plan)
        aoc_device_result = AdaptiveOpticsCalibration.allocate_result(
            aoc_device_plan)
        aoc_cpu_workspace = AdaptiveOpticsCalibration.allocate_workspace(
            aoc_cpu_plan)
        aoc_device_workspace = AdaptiveOpticsCalibration.allocate_workspace(
            aoc_device_plan)
        aoc_cpu_inputs = AOCPhaseRetrieval.LiFTInputs(copy(cpu_observation))
        aoc_device_observation = copy(device_observation)
        aoc_device_observation_snapshot = Array(aoc_device_observation)
        aoc_device_inputs = AOCPhaseRetrieval.LiFTInputs(
            aoc_device_observation)

        @test (@inferred AdaptiveOpticsCalibration.process!(
            aoc_cpu_result, aoc_cpu_workspace, aoc_cpu_plan,
            aoc_cpu_inputs)) === aoc_cpu_result
        @test (@inferred AdaptiveOpticsCalibration.process!(
            aoc_device_result, aoc_device_workspace, aoc_device_plan,
            aoc_device_inputs)) === aoc_device_result
        @test AOCPhaseRetrieval.lift_coefficients(aoc_device_result) isa
            array_backend
        @test aoc_device_workspace.inverse.jacobian isa array_backend
        @test aoc_device_workspace.inverse.model_workspace.opd isa
            array_backend
        @test compute_device(AOCPhaseRetrieval.lift_coefficients(
            aoc_device_result)) == compute_device(lift_rate)
        @test all(isfinite,
            Array(AOCPhaseRetrieval.lift_coefficients(aoc_device_result)))
        device_coefficients = Array(AOCPhaseRetrieval.lift_coefficients(
            aoc_device_result))
        @test device_coefficients ≈ AOCPhaseRetrieval.lift_coefficients(
            aoc_cpu_result) rtol=T(2e-3) atol=T(2e-11)
        if haskey(aoc_domain_reference_coefficients, typeof(jacobian_method))
            @test device_coefficients ≈
                aoc_domain_reference_coefficients[typeof(jacobian_method)] rtol=T(5e-4) atol=T(1e-11)
        else
            aoc_domain_reference_coefficients[typeof(jacobian_method)] =
                device_coefficients
        end
        @test Array(aoc_device_inputs.observation) ==
            aoc_device_observation_snapshot

        result_before_host_input_rejection = Array(AOCPhaseRetrieval.lift_coefficients(
            aoc_device_result))
        @test_throws ArgumentError AdaptiveOpticsCalibration.process!(
            aoc_device_result,
            aoc_device_workspace,
            aoc_device_plan,
            AOCPhaseRetrieval.LiFTInputs(copy(cpu_observation)),
        )
        @test Array(AOCPhaseRetrieval.lift_coefficients(aoc_device_result)) ==
            result_before_host_input_rejection
    end

    mismatched_aoc_method = AOCPhaseRetrieval.LiFT(
        iterations=1, mode_indices=(1, 2), check_convergence=false)
    @test_throws ArgumentError AdaptiveOpticsCalibration.prepare(
        mismatched_aoc_method,
        AdaptiveOpticsCalibration.KernelExecution(
            AOCPhaseRetrieval.LiFTSpecification(
                aoc_device_model, aoc_rate_domain), KernelAbstractions.CPU()))

    ordered_method = AOCPhaseRetrieval.LiFT(
        iterations=2,
        jacobian_method=AOCPhaseRetrieval.LiFTAnalyticJacobian(),
        solve_mode=AOCPhaseRetrieval.LiFTSolveNormalEquations(),
        damping=AOCPhaseRetrieval.LiFTAdaptiveLevenbergMarquardt(),
        mode_indices=(3, 1),
        model_scaling=AOCPhaseRetrieval.LiFTPhysicalRatePreservation(),
        check_convergence=false,
    )
    ordered_cpu_plan = AdaptiveOpticsCalibration.prepare(
        ordered_method,
        AOCPhaseRetrieval.LiFTSpecification(
            aoc_cpu_model, aoc_rate_domain))
    ordered_device_plan = AdaptiveOpticsCalibration.prepare(
        ordered_method,
        AdaptiveOpticsCalibration.KernelExecution(
            AOCPhaseRetrieval.LiFTSpecification(
                aoc_device_model, aoc_rate_domain),
            aoc_device_backend;
            workgroup_size=64))
    @test ordered_device_plan.plan.mode_indices == [3, 1]
    @test Array(ordered_device_plan.execution.mode_indices) == [3, 1]
    ordered_cpu_result = AdaptiveOpticsCalibration.process(
        ordered_cpu_plan,
        AOCPhaseRetrieval.LiFTInputs(copy(cpu_rate);
            initial_coefficients=T[zero(T), truth_coefficients[2], zero(T)]))
    ordered_device_result = AdaptiveOpticsCalibration.process(
        ordered_device_plan,
        AOCPhaseRetrieval.LiFTInputs(copy(lift_rate);
            initial_coefficients=array_backend(
                T[zero(T), truth_coefficients[2], zero(T)])))
    @test Array(AOCPhaseRetrieval.lift_coefficients(ordered_device_result)) ≈
        AOCPhaseRetrieval.lift_coefficients(ordered_cpu_result) rtol=T(2e-3) atol=T(2e-11)
    @test Array(AOCPhaseRetrieval.lift_coefficients(ordered_device_result)) ≈
        truth_coefficients[[3, 1]] rtol=T(2e-3) atol=T(2e-11)

    aoc_cpu_workspace = AOCPhaseRetrieval.allocate_model_workspace(aoc_cpu_model)
    cpu_H = zeros(T, length(cpu_rate), 2)
    gpu_H = similar(lift_rate, T, length(lift_rate), 2)
    @test (@inferred AOCPhaseRetrieval.analytic_photon_rate_jacobian!(
        cpu_H,
        aoc_cpu_model,
        aoc_cpu_workspace,
        zeros(T, 3),
        [1, 2],
    )) === cpu_H
    @test (@inferred AOCPhaseRetrieval.analytic_photon_rate_jacobian!(
        gpu_H,
        aoc_device_model,
        aoc_device_model_workspace,
        array_backend(zeros(T, 3)),
        [1, 2],
    )) === gpu_H
    @test Array(gpu_H) ≈ cpu_H rtol=T(5e-4) atol=T(1e3)

    variance = similar(lift_rate)
    fill!(variance, one(T))
    variance_method = AOCPhaseRetrieval.LiFT(
        iterations=1,
        mode_indices=(1, 2),
        weighting=AOCPhaseRetrieval.LiFTVarianceMapWeighting(variance),
        check_convergence=false,
    )
    variance_plan = AdaptiveOpticsCalibration.prepare(
        variance_method,
        AdaptiveOpticsCalibration.KernelExecution(
            AOCPhaseRetrieval.LiFTSpecification(
                aoc_device_model, aoc_rate_domain),
            aoc_device_backend;
            workgroup_size=64))
    prepared_variance = variance_plan.plan.weighting.variance
    @test prepared_variance !== variance
    @test prepared_variance isa array_backend
    fill!(variance, T(2))
    @test all(isone, Array(prepared_variance))

    predicted_counts = similar(lift_rate)
    predict_lift_observation!(predicted_counts, lift_forward,
        LiFTExpectedCounts(exposure; quantum_efficiency=quantum_efficiency))
    @test isapprox(Array(predicted_counts), Array(count_values);
        rtol=T(2e-5), atol=T(1e-3))
    @test_throws InvalidConfiguration LiFTObservation(lift_forward,
        Array(lift_rate))
    @test_throws InvalidConfiguration prepare_lift_forward_model(lift_tel,
        lift_src, basis_host, truth_opd; diversity_opd=lift_diversity,
        focal_resolution=8)
    @test_throws ArgumentError AdaptiveOpticsCalibration.prepare(
        AOCPhaseRetrieval.LiFT(
            mode_indices=(1, 2),
            weighting=AOCPhaseRetrieval.LiFTVarianceMapWeighting(
                ones(T, 8, 8)),
        ),
        AdaptiveOpticsCalibration.KernelExecution(
            AOCPhaseRetrieval.LiFTSpecification(
                aoc_device_model, aoc_rate_domain),
            aoc_device_backend;
            workgroup_size=64))

    convolution_source_host = reshape(T.(1:64), 8, 8)
    convolution_source = array_backend(convolution_source_host)
    dense_convolution = similar(convolution_source)
    dense_expected = similar(convolution_source_host)
    AdaptiveOpticsSim.WavefrontSensors.conv2d_same!(dense_convolution,
        convolution_source, lift_object_kernel)
    AdaptiveOpticsSim.WavefrontSensors.conv2d_same!(dense_expected,
        convolution_source_host, lift_object_kernel_host)
    @test Array(dense_convolution) ≈ dense_expected rtol=T(1e-5) atol=T(1e-5)

    row_kernel_host = T[1, 2, 1]
    col_kernel_host = T[1, 0.5, 1]
    row_kernel = array_backend(row_kernel_host)
    col_kernel = array_backend(col_kernel_host)
    separable_convolution = similar(convolution_source)
    separable_scratch = similar(convolution_source)
    separable_expected = similar(convolution_source_host)
    separable_expected_scratch = similar(convolution_source_host)
    AdaptiveOpticsSim.WavefrontSensors.conv2d_same_separable!(
        separable_convolution,
        separable_scratch, convolution_source, row_kernel, col_kernel)
    AdaptiveOpticsSim.WavefrontSensors.conv2d_same_separable!(
        separable_expected,
        separable_expected_scratch, convolution_source_host,
        row_kernel_host, col_kernel_host)
    @test isapprox(Array(separable_convolution), separable_expected;
        rtol=T(1e-5), atol=T(1e-5))
    return nothing
end

function run_optional_backend_plan_checks(::Type{AdaptiveOpticsSim.Backends.AMDGPUBackendTag}, tel, backend)
    T = Float32
    array_backend = AdaptiveOpticsSim.Backends._resolve_array_backend(backend)
    pyr = PyramidWFS(tel; pupil_samples=4, modulation=T(1.0), T=T, backend=backend)
    bio = BiOEdgeWFS(tel; pupil_samples=4, modulation=T(1.0), T=T, backend=backend)
    det = Detector(noise=NoiseReadout(T(1.0)), qe=1.0, sensor=HgCdTeSensor(T=T), T=T, backend=backend)
    det_capture = Detector(noise=NoiseReadout(T(1.0)), qe=1.0, bits=12, full_well=T(100),
        sensor=CMOSSensor(T=T), T=T, backend=backend)
    src = Source(band=:I, magnitude=0.0, T=T)
    pupil = PupilFunction(tel; T=T, backend=backend)
    atm = MultiLayerAtmosphere(tel;
        r0=T(0.2),
        reference_wavelength_m=T(500e-9),
        L0=T(25.0),
        fractional_cn2=T[1.0],
        wind_speed=T[0.0],
        wind_direction_deg=T[0.0],
        altitude=T[0.0],
        T=T,
        backend=backend,
    )
    geom_prop = AtmosphericFieldPropagation(atm, pupil, src;
        model=GeometricAtmosphericPropagation(T=T),
        zero_padding=1,
        T=T)
    fresnel_prop = AtmosphericFieldPropagation(atm, pupil, src;
        model=LayeredFresnelAtmosphericPropagation(T=T),
        zero_padding=1,
        T=T)
    pyr_propagation = WavefrontSensors.pyramid_propagation_workspace(pyr)
    bio_propagation = WavefrontSensors.bi_o_edge_propagation_workspace(bio)
    @test pyr_propagation.modulation_batch isa
        WavefrontSensors.PyramidModulationBatchWorkspace
    @test pyr_propagation.modulation_batch.batch_size == 8
    @test size(pyr_propagation.modulation_batch.field_stack, 3) == 8
    @test WavefrontSensors.grouped_accumulation_strategy(
        AdaptiveOpticsSim.Backends.execution_style(
            pyr_propagation.intensity), pyr) isa
        WavefrontSensors.GroupedStaged2DStrategy
    @test WavefrontSensors.grouped_accumulation_strategy(
        AdaptiveOpticsSim.Backends.execution_style(
            bio_propagation.intensity), bio) isa
        WavefrontSensors.GroupedStaged2DStrategy
    sh = ShackHartmannWFS(tel; n_lenslets=4, T=T, backend=backend)
    sh_rate = shack_hartmann_rate_map(sh, pupil, src)
    sh_plan = prepare_wfs_optics(shack_hartmann_optics(sh, src), pupil,
        sh_rate)
    @test form_wfs_optical_products!(sh_rate, pupil, sh_plan) === sh_rate
    @test sh_rate.values isa array_backend
    @test all(isfinite, Array(sh_rate.values))
    @test AdaptiveOpticsSim.Detectors.detector_execution_strategy(typeof(AdaptiveOpticsSim.Backends.execution_style(det.products.frame)), typeof(det)) isa AdaptiveOpticsSim.Detectors.DetectorHostMirrorStrategy
    capture_photon_arrival_rate = array_backend{T}(undef, 4, 4)
    fill!(capture_photon_arrival_rate, T(10))
    captured = capture!(det_capture, capture_photon_arrival_rate;
        rng=MersenneTwister(2))
    @test captured isa array_backend
    @test maximum(Array(captured)) <= Float64(exp2(T(12)) - one(T))
    cpu_poisson_det = Detector(noise=NoisePhoton(), exposure_duration=T(1.0), qe=T(1.0),
        sensor=CMOSSensor(T=T), response_model=NullFrameResponse(), T=T,
        backend=CPUBackend())
    gpu_poisson_det = Detector(noise=NoisePhoton(), exposure_duration=T(1.0), qe=T(1.0),
        sensor=CMOSSensor(T=T), response_model=NullFrameResponse(), T=T,
        backend=backend)
    poisson_input = fill(T(10), 4, 4)
    cpu_poisson = capture!(cpu_poisson_det, copy(poisson_input); rng=MersenneTwister(23))
    gpu_poisson = capture!(gpu_poisson_det, array_backend(copy(poisson_input));
        rng=MersenneTwister(23))
    @test Array(gpu_poisson) == cpu_poisson
    poisson_method = which(
        AdaptiveOpticsSim.Detectors._poisson_noise_frame!,
        (
            AdaptiveOpticsSim.Detectors.DetectorHostMirrorStrategy,
            typeof(gpu_poisson_det),
            typeof(MersenneTwister(1)),
            typeof(gpu_poisson_det.products.frame),
        ),
    )
    @test occursin("AdaptiveOpticsSimAMDGPUExt", String(poisson_method.file))
    @test AdaptiveOpticsSim.Backends.reduction_execution_strategy(pyr_propagation.intensity) isa AdaptiveOpticsSim.Backends.HostMirrorReductionStrategy
    @test AdaptiveOpticsSim.Backends.backend_sum_value(
        capture_photon_arrival_rate) == T(160)

    phase_freqs = T[-0.2, -0.1, 0.1, 0.2]
    cpu_phase_psd = zeros(T, 4, 4)
    gpu_phase_freqs = array_backend(phase_freqs)
    gpu_phase_psd = array_backend(zeros(T, 4, 4))
    phase_args = (T(0.02), T(0.01), T(-11 / 6), zero(T), 4)
    AdaptiveOpticsSim.Atmospheres._fill_phase_psd!(AdaptiveOpticsSim.Backends.ScalarCPUStyle(),
        cpu_phase_psd, phase_freqs, phase_args...)
    phase_style = AdaptiveOpticsSim.Backends.execution_style(gpu_phase_psd)
    AdaptiveOpticsSim.Atmospheres._fill_phase_psd!(phase_style, gpu_phase_psd,
        gpu_phase_freqs, phase_args...)
    @test isapprox(Array(gpu_phase_psd), cpu_phase_psd; rtol=1f-6, atol=1f-7)
    phase_method = which(
        AdaptiveOpticsSim.Atmospheres._fill_phase_psd!,
        (typeof(phase_style), typeof(gpu_phase_psd), typeof(gpu_phase_freqs),
            T, T, T, T, Int),
    )
    @test occursin("AdaptiveOpticsSimAMDGPUExt", String(phase_method.file))

    host_opd = reshape(T.(1:256), 16, 16) .* T(1e-9)
    host_valid = trues(4, 4)
    cpu_geometric_slopes = zeros(T, 32)
    gpu_geometric_slopes = array_backend(zeros(T, 32))
    gpu_opd = array_backend(host_opd)
    gpu_valid = array_backend(host_valid)
    AdaptiveOpticsSim.WavefrontSensors.geometric_slopes!(
        cpu_geometric_slopes, host_opd, host_valid)
    AdaptiveOpticsSim.WavefrontSensors.geometric_slopes!(
        gpu_geometric_slopes, gpu_opd, gpu_valid)
    @test isapprox(Array(gpu_geometric_slopes), cpu_geometric_slopes;
        rtol=1f-6, atol=1f-8)
    geometric_method = which(
        AdaptiveOpticsSim.WavefrontSensors._geometric_slopes!,
        (typeof(AdaptiveOpticsSim.Backends.execution_style(gpu_geometric_slopes)),
            typeof(gpu_geometric_slopes), typeof(gpu_opd), typeof(gpu_valid),
            Int, Int, Int),
    )
    @test occursin("AdaptiveOpticsSimAMDGPUExt", String(geometric_method.file))
    randn_method = which(
        AdaptiveOpticsSim.Detectors._randn_frame_noise!,
        (
            AdaptiveOpticsSim.Detectors.DetectorHostMirrorStrategy,
            typeof(det),
            typeof(MersenneTwister(1)),
            typeof(det.products.frame),
        ),
    )
    @test occursin("AdaptiveOpticsSimAMDGPUExt", String(randn_method.file))
    @test AdaptiveOpticsSim.Atmospheres.atmospheric_field_execution_strategy(
        AdaptiveOpticsSim.Backends.execution_style(first(geom_prop.state.slices).field.values),
        geom_prop.params.model,
    ) isa AdaptiveOpticsSim.Atmospheres.GeometricFieldAsyncStrategy
    @test AdaptiveOpticsSim.Atmospheres.atmospheric_field_execution_strategy(
        AdaptiveOpticsSim.Backends.execution_style(first(fresnel_prop.state.slices).field.values),
        fresnel_prop.params.model,
    ) isa AdaptiveOpticsSim.Atmospheres.LayeredFresnelFieldAsyncStrategy
    correction_models = (
        ReferencePixelCommonModeCorrection(1, 1),
        ReferenceRowCommonModeCorrection(1),
        ReferenceColumnCommonModeCorrection(1),
        ReferenceOutputCommonModeCorrection(2; edge_rows=1, edge_cols=1),
        CompositeFrameReadoutCorrection((
            ReferenceRowCommonModeCorrection(1),
            ReferenceColumnCommonModeCorrection(1),
        )),
    )
    corr_input = reshape(T.(1:96), 2, 6, 8)
    cpu_quant_det = Detector(noise=NoiseNone(), exposure_duration=T(1.0), qe=T(1.0),
        bits=8, full_well=T(100), sensor=CMOSSensor(T=T),
        response_model=NullFrameResponse(), T=T, backend=CPUBackend())
    gpu_quant_det = Detector(noise=NoiseNone(), exposure_duration=T(1.0), qe=T(1.0),
        bits=8, full_well=T(100), sensor=CMOSSensor(T=T),
        response_model=NullFrameResponse(), T=T, backend=backend)
    quant_input = reshape(T.(1:48), 6, 8) .* T(3)
    cpu_quant_frame = capture!(cpu_quant_det, copy(quant_input); rng=MersenneTwister(13))
    gpu_quant_frame = capture!(gpu_quant_det, array_backend(copy(quant_input)); rng=MersenneTwister(13))
    @test gpu_quant_frame isa array_backend
    @test isapprox(Array(gpu_quant_frame), cpu_quant_frame; rtol=1f-5, atol=1f-4)

    for correction_model in correction_models
        cpu_frame_det = Detector(noise=NoiseNone(), exposure_duration=T(1.0), qe=T(1.0),
            sensor=HgCdTeSensor(T=T),
            response_model=NullFrameResponse(),
            correction_model=correction_model,
            T=T,
            backend=CPUBackend())
        gpu_frame_det = Detector(noise=NoiseNone(), exposure_duration=T(1.0), qe=T(1.0),
            sensor=HgCdTeSensor(T=T),
            response_model=NullFrameResponse(),
            correction_model=correction_model,
            T=T,
            backend=backend)
        frame_input = reshape(T.(1:48), 6, 8)
        cpu_frame = capture!(cpu_frame_det, frame_input; rng=MersenneTwister(12))
        gpu_frame = capture!(gpu_frame_det, array_backend(copy(frame_input)); rng=MersenneTwister(12))
        @test gpu_frame isa array_backend
        @test isapprox(Array(gpu_frame), cpu_frame; rtol=1f-5, atol=1f-4)

        cpu_corr_det = Detector(noise=NoiseNone(), exposure_duration=T(1.0), qe=T(1.0),
            sensor=HgCdTeSensor(T=T),
            response_model=NullFrameResponse(),
            correction_model=correction_model,
            T=T,
            backend=CPUBackend())
        gpu_corr_det = Detector(noise=NoiseNone(), exposure_duration=T(1.0), qe=T(1.0),
            sensor=HgCdTeSensor(T=T),
            response_model=NullFrameResponse(),
            correction_model=correction_model,
            T=T,
            backend=backend)
        cpu_corr_cube = copy(corr_input)
        gpu_corr_cube = array_backend(copy(corr_input))
        cpu_corr_scratch = similar(cpu_corr_cube)
        gpu_corr_scratch = similar(gpu_corr_cube)
        AdaptiveOpticsSim.Detectors.capture_stack!(cpu_corr_det, cpu_corr_cube, cpu_corr_scratch; rng=MersenneTwister(11))
        AdaptiveOpticsSim.Detectors.capture_stack!(gpu_corr_det, gpu_corr_cube, gpu_corr_scratch; rng=MersenneTwister(11))
        @test gpu_corr_cube isa array_backend
        @test isapprox(Array(gpu_corr_cube), cpu_corr_cube; rtol=1f-5, atol=1f-4)
    end

    generalized_correction = CompositeFrameReadoutCorrection((
        ReferenceRowCommonModeCorrection(1),
        ReferenceColumnCommonModeCorrection(1),
    ))
    cpu_gen_det = Detector(noise=NoiseNone(), exposure_duration=T(1.0), qe=T(1.0),
        bits=8, full_well=T(100), readout_window=AdaptiveOpticsSim.Detectors.FrameWindow(2:5, 3:7), output_type=UInt16,
        sensor=HgCdTeSensor(T=T),
        response_model=NullFrameResponse(),
        correction_model=generalized_correction,
        T=T,
        backend=CPUBackend())
    gpu_gen_det = Detector(noise=NoiseNone(), exposure_duration=T(1.0), qe=T(1.0),
        bits=8, full_well=T(100), readout_window=AdaptiveOpticsSim.Detectors.FrameWindow(2:5, 3:7), output_type=UInt16,
        sensor=HgCdTeSensor(T=T),
        response_model=NullFrameResponse(),
        correction_model=generalized_correction,
        T=T,
        backend=backend)
    cpu_gen_input = copy(corr_input)
    gpu_gen_input = array_backend(copy(corr_input))
    cpu_gen_out = Array{UInt16}(undef, 2, 4, 5)
    gpu_gen_out = array_backend{UInt16}(undef, 2, 4, 5)
    AdaptiveOpticsSim.Detectors.capture_stack!(cpu_gen_det, cpu_gen_out, cpu_gen_input; rng=MersenneTwister(14))
    AdaptiveOpticsSim.Detectors.capture_stack!(gpu_gen_det, gpu_gen_out, gpu_gen_input; rng=MersenneTwister(14))
    @test gpu_gen_out isa array_backend
    @test Array(gpu_gen_out) == cpu_gen_out

    cpu_windowed_det = Detector(noise=NoiseNone(), exposure_duration=T(1.0), qe=T(1.0), binning=1,
        gain=T(1.0),
        sensor=HgCdTeSensor(T=T, sampling_mode=CorrelatedDoubleSampling()),
        response_model=NullFrameResponse(),
        readout_window=AdaptiveOpticsSim.Detectors.FrameWindow(2:3, 2:3),
        T=T,
        backend=CPUBackend())
    gpu_windowed_det = Detector(noise=NoiseNone(), exposure_duration=T(1.0), qe=T(1.0), binning=1,
        gain=T(1.0),
        sensor=HgCdTeSensor(T=T, sampling_mode=CorrelatedDoubleSampling()),
        response_model=NullFrameResponse(),
        readout_window=AdaptiveOpticsSim.Detectors.FrameWindow(2:3, 2:3),
        T=T,
        backend=backend)
    windowed_input = fill(T(10), 4, 4)
    cpu_windowed_frame = capture!(cpu_windowed_det, windowed_input; rng=MersenneTwister(15))
    gpu_windowed_frame = capture!(gpu_windowed_det, array_backend(copy(windowed_input)); rng=MersenneTwister(15))
    @test isapprox(Array(gpu_windowed_frame), cpu_windowed_frame; rtol=1f-5, atol=1f-4)
    @test isapprox(Array(AdaptiveOpticsSim.Detectors.detector_reference_frame(gpu_windowed_det)), AdaptiveOpticsSim.Detectors.detector_reference_frame(cpu_windowed_det); rtol=1f-5, atol=1f-4)
    @test isapprox(Array(AdaptiveOpticsSim.Detectors.detector_signal_frame(gpu_windowed_det)), AdaptiveOpticsSim.Detectors.detector_signal_frame(cpu_windowed_det); rtol=1f-5, atol=1f-4)
    @test isapprox(Array(AdaptiveOpticsSim.Detectors.detector_combined_frame(gpu_windowed_det)), AdaptiveOpticsSim.Detectors.detector_combined_frame(cpu_windowed_det); rtol=1f-5, atol=1f-4)
    @test isapprox(Array(AdaptiveOpticsSim.Detectors.detector_reference_cube(gpu_windowed_det)), AdaptiveOpticsSim.Detectors.detector_reference_cube(cpu_windowed_det); rtol=1f-5, atol=1f-4)
    @test isapprox(Array(AdaptiveOpticsSim.Detectors.detector_signal_cube(gpu_windowed_det)), AdaptiveOpticsSim.Detectors.detector_signal_cube(cpu_windowed_det); rtol=1f-5, atol=1f-4)
    @test isapprox(Array(AdaptiveOpticsSim.Detectors.detector_read_cube(gpu_windowed_det)), AdaptiveOpticsSim.Detectors.detector_read_cube(cpu_windowed_det); rtol=1f-5, atol=1f-4)
    @test AdaptiveOpticsSim.Detectors.detector_read_offsets_s(gpu_windowed_det) == AdaptiveOpticsSim.Detectors.detector_read_offsets_s(cpu_windowed_det)

    return nothing
end

function run_optional_backend_plan_checks(::Type{AdaptiveOpticsSim.Backends.CUDABackendTag}, tel, backend)
    T = Float32
    array_backend = AdaptiveOpticsSim.Backends._resolve_array_backend(backend)
    pyr = PyramidWFS(tel; pupil_samples=4, modulation=T(1.0), T=T, backend=backend)
    bio = BiOEdgeWFS(tel; pupil_samples=4, modulation=T(1.0), T=T, backend=backend)
    det = Detector(noise=NoiseReadout(T(1.0)), qe=1.0, sensor=HgCdTeSensor(T=T), T=T, backend=backend)
    src = Source(band=:I, magnitude=0.0, T=T)
    pupil = PupilFunction(tel; T=T, backend=backend)
    atm = MultiLayerAtmosphere(tel;
        r0=T(0.2),
        reference_wavelength_m=T(500e-9),
        L0=T(25.0),
        fractional_cn2=T[1.0],
        wind_speed=T[0.0],
        wind_direction_deg=T[0.0],
        altitude=T[0.0],
        T=T,
        backend=backend,
    )
    geom_prop = AtmosphericFieldPropagation(atm, pupil, src;
        model=GeometricAtmosphericPropagation(T=T),
        zero_padding=1,
        T=T)
    fresnel_prop = AtmosphericFieldPropagation(atm, pupil, src;
        model=LayeredFresnelAtmosphericPropagation(T=T),
        zero_padding=1,
        T=T)
    pyr_propagation = WavefrontSensors.pyramid_propagation_workspace(pyr)
    bio_propagation = WavefrontSensors.bi_o_edge_propagation_workspace(bio)
    @test pyr_propagation.modulation_batch isa
        WavefrontSensors.PyramidModulationBatchWorkspace
    @test pyr_propagation.modulation_batch.batch_size == 8
    @test size(pyr_propagation.modulation_batch.field_stack, 3) == 8
    @test WavefrontSensors.grouped_accumulation_strategy(
        AdaptiveOpticsSim.Backends.execution_style(
            pyr_propagation.intensity), pyr) isa
        WavefrontSensors.GroupedStackReduceStrategy
    @test WavefrontSensors.grouped_accumulation_strategy(
        AdaptiveOpticsSim.Backends.execution_style(
            bio_propagation.intensity), bio) isa
        WavefrontSensors.GroupedStackReduceStrategy
    @test AdaptiveOpticsSim.Detectors.detector_execution_strategy(typeof(AdaptiveOpticsSim.Backends.execution_style(det.products.frame)), typeof(det)) isa AdaptiveOpticsSim.Detectors.DetectorDirectStrategy
    @test AdaptiveOpticsSim.Backends.reduction_execution_strategy(pyr_propagation.intensity) isa AdaptiveOpticsSim.Backends.DirectReductionStrategy
    @test AdaptiveOpticsSim.Atmospheres.atmospheric_field_execution_strategy(
        AdaptiveOpticsSim.Backends.execution_style(first(geom_prop.state.slices).field.values),
        geom_prop.params.model,
    ) isa AdaptiveOpticsSim.Atmospheres.GeometricFieldAsyncStrategy
    @test AdaptiveOpticsSim.Atmospheres.atmospheric_field_execution_strategy(
        AdaptiveOpticsSim.Backends.execution_style(first(fresnel_prop.state.slices).field.values),
        fresnel_prop.params.model,
    ) isa AdaptiveOpticsSim.Atmospheres.LayeredFresnelFieldAsyncStrategy
    cpu_tel = Telescope(resolution=16, diameter=8.0f0,
        central_obstruction=0.0f0, T=T, backend=CPUBackend())
    gpu_tel = Telescope(resolution=16, diameter=8.0f0,
        central_obstruction=0.0f0, T=T, backend=backend)
    cpu_src = Source(band=:I, magnitude=0.0, T=T)
    gpu_src = Source(band=:I, magnitude=0.0, T=T)
    cpu_sh = ShackHartmannWFS(cpu_tel; n_lenslets=4, T=T,
        backend=CPUBackend())
    gpu_sh = ShackHartmannWFS(gpu_tel; n_lenslets=4, T=T,
        backend=backend)
    cpu_det = Detector(noise=NoiseNone(), exposure_duration=T(1.0), qe=T(1.0),
        sensor=CMOSSensor(T=T), response_model=NullFrameResponse(), T=T, backend=CPUBackend())
    gpu_det = Detector(noise=NoiseNone(), exposure_duration=T(1.0), qe=T(1.0),
        sensor=CMOSSensor(T=T), response_model=NullFrameResponse(), T=T, backend=backend)
    cpu_pupil = PupilFunction(cpu_tel; T=T, backend=CPUBackend())
    gpu_pupil = PupilFunction(gpu_tel; T=T, backend=backend)
    cpu_rate = shack_hartmann_rate_map(cpu_sh, cpu_pupil, cpu_src)
    gpu_rate = shack_hartmann_rate_map(gpu_sh, gpu_pupil, gpu_src)
    cpu_plan = prepare_wfs_optics(shack_hartmann_optics(cpu_sh, cpu_src),
        cpu_pupil, cpu_rate)
    gpu_plan = prepare_wfs_optics(shack_hartmann_optics(gpu_sh, gpu_src),
        gpu_pupil, gpu_rate)
    form_wfs_optical_products!(cpu_rate, cpu_pupil, cpu_plan)
    form_wfs_optical_products!(gpu_rate, gpu_pupil, gpu_plan)
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(gpu_rate.values))
    @test gpu_rate.values isa array_backend
    @test isapprox(Array(gpu_rate.values), cpu_rate.values; rtol=1f-5,
        atol=1f-4)
    cpu_observation = WFSObservation(similar(cpu_rate.values);
        units=:electron_count, layout=:lenslet_mosaic)
    gpu_observation = WFSObservation(similar(gpu_rate.values);
        units=:electron_count, layout=:lenslet_mosaic)
    cpu_acquisition = prepare_wfs_acquisition(cpu_det, cpu_rate,
        cpu_observation)
    gpu_acquisition = prepare_wfs_acquisition(gpu_det, gpu_rate,
        gpu_observation)
    acquire_wfs_observation!(cpu_observation, cpu_rate, cpu_acquisition,
        MersenneTwister(3))
    acquire_wfs_observation!(gpu_observation, gpu_rate, gpu_acquisition,
        MersenneTwister(3))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(gpu_observation.storage))
    @test isapprox(Array(gpu_observation.storage), cpu_observation.storage;
        rtol=1f-5, atol=1f-4)

    correction_models = (
        ReferencePixelCommonModeCorrection(1, 1),
        ReferenceRowCommonModeCorrection(1),
        ReferenceColumnCommonModeCorrection(1),
        ReferenceOutputCommonModeCorrection(2; edge_rows=1, edge_cols=1),
        CompositeFrameReadoutCorrection((
            ReferenceRowCommonModeCorrection(1),
            ReferenceColumnCommonModeCorrection(1),
        )),
    )
    corr_input = reshape(T.(1:96), 2, 6, 8)
    cpu_quant_det = Detector(noise=NoiseNone(), exposure_duration=T(1.0), qe=T(1.0),
        bits=8, full_well=T(100), sensor=CMOSSensor(T=T),
        response_model=NullFrameResponse(), T=T, backend=CPUBackend())
    gpu_quant_det = Detector(noise=NoiseNone(), exposure_duration=T(1.0), qe=T(1.0),
        bits=8, full_well=T(100), sensor=CMOSSensor(T=T),
        response_model=NullFrameResponse(), T=T, backend=backend)
    quant_input = reshape(T.(1:48), 6, 8) .* T(3)
    cpu_quant_frame = capture!(cpu_quant_det, copy(quant_input); rng=MersenneTwister(13))
    gpu_quant_frame = capture!(gpu_quant_det, array_backend(copy(quant_input)); rng=MersenneTwister(13))
    @test gpu_quant_frame isa array_backend
    @test isapprox(Array(gpu_quant_frame), cpu_quant_frame; rtol=1f-5, atol=1f-4)

    for correction_model in correction_models
        cpu_frame_det = Detector(noise=NoiseNone(), exposure_duration=T(1.0), qe=T(1.0),
            sensor=HgCdTeSensor(T=T),
            response_model=NullFrameResponse(),
            correction_model=correction_model,
            T=T,
            backend=CPUBackend())
        gpu_frame_det = Detector(noise=NoiseNone(), exposure_duration=T(1.0), qe=T(1.0),
            sensor=HgCdTeSensor(T=T),
            response_model=NullFrameResponse(),
            correction_model=correction_model,
            T=T,
            backend=backend)
        frame_input = reshape(T.(1:48), 6, 8)
        cpu_frame = capture!(cpu_frame_det, frame_input; rng=MersenneTwister(12))
        gpu_frame = capture!(gpu_frame_det, array_backend(copy(frame_input)); rng=MersenneTwister(12))
        @test gpu_frame isa array_backend
        @test isapprox(Array(gpu_frame), cpu_frame; rtol=1f-5, atol=1f-4)

        cpu_corr_det = Detector(noise=NoiseNone(), exposure_duration=T(1.0), qe=T(1.0),
            sensor=HgCdTeSensor(T=T),
            response_model=NullFrameResponse(),
            correction_model=correction_model,
            T=T,
            backend=CPUBackend())
        gpu_corr_det = Detector(noise=NoiseNone(), exposure_duration=T(1.0), qe=T(1.0),
            sensor=HgCdTeSensor(T=T),
            response_model=NullFrameResponse(),
            correction_model=correction_model,
            T=T,
            backend=backend)
        cpu_corr_cube = copy(corr_input)
        gpu_corr_cube = array_backend(copy(corr_input))
        cpu_corr_scratch = similar(cpu_corr_cube)
        gpu_corr_scratch = similar(gpu_corr_cube)
        AdaptiveOpticsSim.Detectors.capture_stack!(cpu_corr_det, cpu_corr_cube, cpu_corr_scratch; rng=MersenneTwister(11))
        AdaptiveOpticsSim.Detectors.capture_stack!(gpu_corr_det, gpu_corr_cube, gpu_corr_scratch; rng=MersenneTwister(11))
        @test gpu_corr_cube isa array_backend
        @test isapprox(Array(gpu_corr_cube), cpu_corr_cube; rtol=1f-5, atol=1f-4)
    end

    generalized_correction = CompositeFrameReadoutCorrection((
        ReferenceRowCommonModeCorrection(1),
        ReferenceColumnCommonModeCorrection(1),
    ))
    cpu_gen_det = Detector(noise=NoiseNone(), exposure_duration=T(1.0), qe=T(1.0),
        bits=8, full_well=T(100), readout_window=AdaptiveOpticsSim.Detectors.FrameWindow(2:5, 3:7), output_type=UInt16,
        sensor=HgCdTeSensor(T=T),
        response_model=NullFrameResponse(),
        correction_model=generalized_correction,
        T=T,
        backend=CPUBackend())
    gpu_gen_det = Detector(noise=NoiseNone(), exposure_duration=T(1.0), qe=T(1.0),
        bits=8, full_well=T(100), readout_window=AdaptiveOpticsSim.Detectors.FrameWindow(2:5, 3:7), output_type=UInt16,
        sensor=HgCdTeSensor(T=T),
        response_model=NullFrameResponse(),
        correction_model=generalized_correction,
        T=T,
        backend=backend)
    cpu_gen_input = copy(corr_input)
    gpu_gen_input = array_backend(copy(corr_input))
    cpu_gen_out = Array{UInt16}(undef, 2, 4, 5)
    gpu_gen_out = array_backend{UInt16}(undef, 2, 4, 5)
    AdaptiveOpticsSim.Detectors.capture_stack!(cpu_gen_det, cpu_gen_out, cpu_gen_input; rng=MersenneTwister(14))
    AdaptiveOpticsSim.Detectors.capture_stack!(gpu_gen_det, gpu_gen_out, gpu_gen_input; rng=MersenneTwister(14))
    @test gpu_gen_out isa array_backend
    @test Array(gpu_gen_out) == cpu_gen_out

    cpu_windowed_det = Detector(noise=NoiseNone(), exposure_duration=T(1.0), qe=T(1.0), binning=1,
        gain=T(1.0),
        sensor=HgCdTeSensor(T=T, sampling_mode=CorrelatedDoubleSampling()),
        response_model=NullFrameResponse(),
        readout_window=AdaptiveOpticsSim.Detectors.FrameWindow(2:3, 2:3),
        T=T,
        backend=CPUBackend())
    gpu_windowed_det = Detector(noise=NoiseNone(), exposure_duration=T(1.0), qe=T(1.0), binning=1,
        gain=T(1.0),
        sensor=HgCdTeSensor(T=T, sampling_mode=CorrelatedDoubleSampling()),
        response_model=NullFrameResponse(),
        readout_window=AdaptiveOpticsSim.Detectors.FrameWindow(2:3, 2:3),
        T=T,
        backend=backend)
    windowed_input = fill(T(10), 4, 4)
    cpu_windowed_frame = capture!(cpu_windowed_det, windowed_input; rng=MersenneTwister(15))
    gpu_windowed_frame = capture!(gpu_windowed_det, array_backend(copy(windowed_input)); rng=MersenneTwister(15))
    @test isapprox(Array(gpu_windowed_frame), cpu_windowed_frame; rtol=1f-5, atol=1f-4)
    @test isapprox(Array(AdaptiveOpticsSim.Detectors.detector_reference_frame(gpu_windowed_det)), AdaptiveOpticsSim.Detectors.detector_reference_frame(cpu_windowed_det); rtol=1f-5, atol=1f-4)
    @test isapprox(Array(AdaptiveOpticsSim.Detectors.detector_signal_frame(gpu_windowed_det)), AdaptiveOpticsSim.Detectors.detector_signal_frame(cpu_windowed_det); rtol=1f-5, atol=1f-4)
    @test isapprox(Array(AdaptiveOpticsSim.Detectors.detector_combined_frame(gpu_windowed_det)), AdaptiveOpticsSim.Detectors.detector_combined_frame(cpu_windowed_det); rtol=1f-5, atol=1f-4)
    @test isapprox(Array(AdaptiveOpticsSim.Detectors.detector_reference_cube(gpu_windowed_det)), AdaptiveOpticsSim.Detectors.detector_reference_cube(cpu_windowed_det); rtol=1f-5, atol=1f-4)
    @test isapprox(Array(AdaptiveOpticsSim.Detectors.detector_signal_cube(gpu_windowed_det)), AdaptiveOpticsSim.Detectors.detector_signal_cube(cpu_windowed_det); rtol=1f-5, atol=1f-4)
    @test isapprox(Array(AdaptiveOpticsSim.Detectors.detector_read_cube(gpu_windowed_det)), AdaptiveOpticsSim.Detectors.detector_read_cube(cpu_windowed_det); rtol=1f-5, atol=1f-4)
    @test AdaptiveOpticsSim.Detectors.detector_read_offsets_s(gpu_windowed_det) == AdaptiveOpticsSim.Detectors.detector_read_offsets_s(cpu_windowed_det)

    return nothing
end

function optional_direct_imaging_batch_allocation_bytes(prepared)
    form_direct_image!(prepared)
    validation_bytes = @allocated(
        AdaptiveOpticsSim.Optics.validate_direct_imaging_batch(prepared),
    )
    completed_render_bytes = @allocated form_direct_image!(prepared)
    return (; validation_bytes, completed_render_bytes)
end

function optional_storage_range_contains(parent, child)
    parent_start = UInt(pointer(parent))
    child_start = UInt(pointer(child))
    parent_stop =
        parent_start + UInt(sizeof(eltype(parent)) * length(parent))
    child_stop =
        child_start + UInt(sizeof(eltype(child)) * length(child))
    return parent_start <= child_start && child_stop <= parent_stop
end

function run_optional_direct_imaging_batch_checks(
    tel::Telescope,
    selector::AdaptiveOpticsSim.Backends.AbstractArrayBackend,
    BackendArray,
    ::Type{T},
) where {T<:AbstractFloat}
    pupil = PupilFunction(tel; T=T, backend=selector)
    host_opd = reshape(
        collect(range(T(-20e-9), T(20e-9); length=length(pupil.opd))),
        size(pupil.opd),
    )
    copyto!(pupil.opd, host_opd)

    wavelengths = T[650e-9, 800e-9, 950e-9]
    source = Source(
        band=:custom,
        wavelength=wavelengths[2],
        photon_irradiance=T(6),
        separation_arcsec=T(0.08), position_angle_deg=T(90),
        T=T,
    )
    sources = with_spectrum(
        source,
        SpectralBundle(wavelengths, T[1, 2, 3]; T=T),
    )
    prepared = prepare_direct_imaging_batch(
        pupil,
        sources;
        zero_padding=2,
    )
    products = form_direct_image!(prepared)
    serial = prepare_direct_imaging(
        pupil,
        sources;
        zero_padding=2,
    )
    serial_products = form_direct_image!(serial)
    device = compute_device(pupil.opd)

    @test products === direct_imaging_output(prepared)
    @test length(products) == length(wavelengths)
    @test prepared.workspace.field_stack isa BackendArray
    @test prepared.workspace.output_stack isa BackendArray
    @test prepared.workspace.shift_axis1 isa BackendArray
    @test prepared.workspace.shift_axis2 isa BackendArray
    @test prepared.workspace.fft_plan ===
        prepared.bindings.fft_plan
    @test prepared.fields !== prepared.bindings.fields
    @test all(index ->
            prepared.fields[index] === prepared.bindings.fields[index],
        eachindex(prepared.fields))
    @test products === prepared.bindings.output
    @test all(
        index -> optional_storage_range_contains(
            prepared.workspace.field_stack,
            prepared.fields[index].values,
        ),
        eachindex(wavelengths),
    )
    @test all(
        index -> optional_storage_range_contains(
            prepared.workspace.output_stack,
            products[index].values,
        ),
        eachindex(wavelengths),
    )
    @test all(
        array -> compute_device(array) == device,
        (
            prepared.workspace.field_stack,
            prepared.workspace.output_stack,
            prepared.workspace.shift_axis1,
            prepared.workspace.shift_axis2,
        ),
    )
    @test all(
        index -> compute_device(products[index].values) == device,
        eachindex(wavelengths),
    )
    @test [
        products[index].metadata.spectral.wavelength_m
        for index in eachindex(wavelengths)
    ] == wavelengths

    for index in eachindex(wavelengths)
        @test isapprox(
            Array(products[index].values),
            Array(serial_products[index].values);
            rtol=T(5e-5),
            atol=T(5e-6),
        )
        @test products[index].metadata == serial_products[index].metadata
    end

    selected = products[2]
    short_detector = Detector(
        exposure_duration=T(0.25),
        noise=NoiseNone(),
        qe=T(0.5),
        response_model=NullFrameResponse(),
        T=T,
        backend=selector,
    )
    long_detector = Detector(
        exposure_duration=one(T),
        noise=NoiseNone(),
        qe=T(0.5),
        response_model=NullFrameResponse(),
        T=T,
        backend=selector,
    )
    short_acquisition =
        prepare_detector_acquisition(short_detector, selected)
    long_acquisition =
        prepare_detector_acquisition(long_detector, selected)
    @test Detectors.detector_acquisition_input(short_acquisition).values ===
        selected.values
    @test Detectors.detector_acquisition_input(long_acquisition).values ===
        selected.values
    short_frame = capture!(short_acquisition; rng=MersenneTwister(611))
    long_frame = capture!(long_acquisition; rng=MersenneTwister(612))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(long_frame),
    )
    @test short_frame isa BackendArray
    @test long_frame isa BackendArray
    @test isapprox(
        Array(long_frame),
        T(4) .* Array(short_frame);
        rtol=T(5e-5),
        atol=T(5e-6),
    )

    allocation_bytes =
        optional_direct_imaging_batch_allocation_bytes(prepared)
    @test allocation_bytes.validation_bytes == 0
    # The numerical data plane remains device-resident. The owning GPU runtime
    # may still allocate bounded host-side launch descriptors for the field,
    # FFT, and intensity submissions.
    @test allocation_bytes.completed_render_bytes <= 128 * 1024
    return nothing
end

function optional_atmosphere_direction_batch_allocation_bytes(
    prepared,
    atm,
    epoch,
)
    render_atmosphere_directions!(prepared, atm, epoch)
    validation_bytes = @allocated(
        AdaptiveOpticsSim.Atmospheres.validate_atmosphere_direction_batch(
            prepared,
            atm,
            epoch,
        ),
    )
    completed_render_bytes =
        @allocated render_atmosphere_directions!(prepared, atm, epoch)
    return (; validation_bytes, completed_render_bytes)
end

function run_optional_atmosphere_direction_batch_checks(
    atm::AdaptiveOpticsSim.Atmospheres.AbstractTimedAtmosphere,
    tel::Telescope,
    sources::Asterism,
    epoch::AtmosphereEpoch,
    BackendArray,
)
    T = AdaptiveOpticsSim.Atmospheres.atmosphere_numeric_type(atm)
    n = tel.params.resolution
    output = BackendArray{T}(undef, n, n, length(sources))
    prepared = prepare_atmosphere_direction_batch(
        atm,
        tel,
        sources,
        output,
    )
    rendered = render_atmosphere_directions!(prepared, atm, epoch)
    @test rendered === output
    @test atmosphere_direction_output(prepared) === output
    @test prepared.workspace.shift_x isa BackendArray
    @test prepared.workspace.shift_y isa BackendArray
    @test prepared.workspace.footprint_scale isa BackendArray
    @test prepared.workspace.pupil isa BackendArray
    @test compute_device(output) == compute_device(prepared.workspace.shift_x)
    @test compute_device(output) == compute_device(prepared.workspace.shift_y)
    @test compute_device(output) ==
        compute_device(prepared.workspace.footprint_scale)
    @test compute_device(output) == compute_device(prepared.workspace.pupil)
    @test prepared.params.layer_count < prepared.params.layer_count *
        prepared.params.direction_count

    host_output = Array(output)
    @inbounds for direction in eachindex(prepared.params.sources)
        pupil = PupilFunction(tel; T=T, backend=backend(tel))
        renderer = prepare_atmosphere_renderer(
            atm,
            tel,
            prepared.params.sources[direction];
            T=T,
        )
        render_atmosphere!(pupil, renderer, atm, epoch)
        @test isapprox(
            @view(host_output[:, :, direction]),
            Array(pupil.opd);
            rtol=T(2e-5),
            atol=T(2e-6),
        )
    end

    allocation_bytes =
        optional_atmosphere_direction_batch_allocation_bytes(
            prepared,
            atm,
            epoch,
        )
    @test allocation_bytes.validation_bytes == 0
    # KernelAbstractions and the owning GPU runtime allocate small host-side
    # launch descriptors even after kernel compilation. Keep that separately
    # bounded from the zero-allocation prepared-contract validation and from
    # device-resident data-plane storage.
    @test allocation_bytes.completed_render_bytes <= 64 * 1024

    host_destination = fill(T(37), n, n, length(sources))
    @test_throws InvalidConfiguration prepare_atmosphere_direction_batch(
        atm,
        tel,
        sources,
        host_destination,
    )
    @test all(==(T(37)), host_destination)
    return nothing
end

function run_optional_backend_smoke(::Type{B}) where {B<:AdaptiveOpticsSim.Backends.GPUBackendTag}
    pkg = backend_package_name(B)
    pkg_path = Base.find_package(pkg)
    if pkg_path === nothing
        @info "Skipping $(backend_label(B)) smoke: $(pkg).jl is not available in this environment"
        @test true
        return nothing
    end

    if !backend_preloaded(B)
        @info "Skipping $(backend_label(B)) smoke: preload $(pkg).jl before AdaptiveOpticsSim with the dedicated hardware test entry point"
        @test true
        return nothing
    end
    if !backend_functional(B)
        @info "Skipping $(backend_label(B)) smoke: backend runtime/device is not functional on this host"
        @test true
        return nothing
    end

    AdaptiveOpticsSim.Backends.disable_scalar_backend!(B)
    backend = AdaptiveOpticsSim.Backends.gpu_backend_array_type(B)
    @test backend !== nothing
    run_optional_exact_compute_device_checks(B, backend)
    run_optional_backend_selector_smoke(B, backend)
    run_optional_lgs_convolution_normalization(B)
    run_optional_sodium_layer_profile_wfs(B, backend)
    run_optional_generic_wfs_acquisition_checks(B, backend)
    run_optional_wfs_stage_contracts(B, backend)
    run_optional_pyramid_fractional_shift_checks(B, backend)
    run_optional_spad_qualification_checks(B, backend)
    run_optional_cmos_family_checks(B, backend)
    run_optional_shared_detector_ipc_checks(B, backend)
    run_optional_cycle_averaged_modulation_checks(B, backend)
    if get(ENV, backend_full_smoke_env(B), "0") == "1"
        include(joinpath(dirname(@__DIR__), "scripts", "gpu_smoke_contract.jl"))
        run_smoke_matrix = Base.invokelatest(
            getfield, Main, :run_gpu_smoke_matrix)
        Base.invokelatest(run_smoke_matrix, B)
        @test true
        return nothing
    end

    T = Float32
    rng = MersenneTwister(7)
    BackendArray = backend
    selector = backend_selector(B)

    run_optional_counting_detector_parity(B, BackendArray)
    run_optional_avalanche_detector_parity(B, BackendArray)
    run_optional_ingaas_checks(B, BackendArray)
    run_optional_skipper_ccd_checks(B, BackendArray)

    tel = Telescope(resolution=16, diameter=8.0f0,
        central_obstruction=0.0f0, T=T, backend=selector)
    src = Source(band=:I, magnitude=0.0, T=T)
    run_optional_plane_product_checks(tel, src, selector, BackendArray, T)
    run_optional_direct_imaging_batch_checks(
        tel,
        selector,
        BackendArray,
        T,
    )

    atm = MultiLayerAtmosphere(tel;
        r0=T(0.2),
        reference_wavelength_m=T(500e-9),
        L0=T(25.0),
        fractional_cn2=T[0.7, 0.3],
        wind_speed=T[8.0, 4.0],
        wind_direction_deg=T[0.0, 90.0],
        altitude=T[0.0, 5000.0],
        T=T,
        backend=selector,
    )
    epoch = advance_by!(atm, T(1e-3); rng=rng)
    renderer = prepare_atmosphere_renderer(atm, tel, src)
    atmosphere_output = PupilFunction(tel; T=T)
    render_atmosphere!(atmosphere_output, renderer, atm, epoch)
    @test atm.layers[1].generator.state.phase_rad isa BackendArray
    @test atmosphere_output.opd isa BackendArray
    direction_sources = Asterism(AdaptiveOpticsSim.Optics.AbstractSource[
        src,
        Source(
            band=:I,
            magnitude=zero(T),
            separation_arcsec=T(6), position_angle_deg=T(35),
            T=T,
        ),
        LGSSource(
            magnitude=zero(T),
            separation_arcsec=T(-9), position_angle_deg=T(70),
            altitude=T(90_000),
            T=T,
        ),
        Source(
            band=:K,
            magnitude=one(T),
            separation_arcsec=T(5), position_angle_deg=T(120),
            T=T,
        ),
    ])
    run_optional_atmosphere_direction_batch_checks(
        atm,
        tel,
        direction_sources,
        epoch,
        BackendArray,
    )
    pupil = PupilFunction(tel; T=T, backend=selector)
    copyto!(pupil.opd, atmosphere_output.opd)

    inf_atm = InfiniteMultiLayerAtmosphere(tel;
        r0=T(0.2),
        reference_wavelength_m=T(500e-9),
        L0=T(25.0),
        fractional_cn2=T[0.7, 0.3],
        wind_speed=T[8.0, 4.0],
        wind_direction_deg=T[0.0, 90.0],
        altitude=T[0.0, 5000.0],
        screen_resolution=33,
        stencil_size=35,
        T=T,
        backend=selector,
    )
    infinite_epoch = advance_by!(inf_atm, T(1e-3); rng=rng)
    infinite_renderer = prepare_atmosphere_renderer(inf_atm, tel, src)
    render_atmosphere!(atmosphere_output, infinite_renderer, inf_atm,
        infinite_epoch)
    @test inf_atm.layers[1].screen.state.phase_rad isa BackendArray
    @test atmosphere_output.opd isa BackendArray
    run_optional_atmosphere_direction_batch_checks(
        inf_atm,
        tel,
        direction_sources,
        infinite_epoch,
        BackendArray,
    )

    prop = AtmosphericFieldPropagation(atm, pupil, src;
        model=GeometricAtmosphericPropagation(T=T),
        zero_padding=2,
        T=T)
    field = propagate_atmosphere_field!(prop, atm, epoch)
    @test field.values isa BackendArray
    intensity = atmospheric_intensity!(prop, atm, epoch)
    @test intensity isa BackendArray

    bundle = SpectralBundle(fill(wavelength(src), 2), T[0.4, 0.6]; T=T)
    poly = with_spectrum(src, bundle)
    sh = ShackHartmannWFS(tel; n_lenslets=4, T=T, backend=selector)
    spectral_rate = shack_hartmann_rate_map(sh, pupil, poly)
    spectral_plan = prepare_wfs_optics(shack_hartmann_optics(sh, poly),
        pupil, spectral_rate)
    form_wfs_optical_products!(spectral_rate, pupil, spectral_plan)
    spectral_products = Tuple(spectral_rate.products)
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(
            first(spectral_products).values))
    @test all(product -> product.values isa BackendArray,
        spectral_products)
    @test all(product -> all(isfinite, Array(product.values)),
        spectral_products)
    spectral_qe = AdaptiveOpticsSim.Detectors.SampledQuantumEfficiency(
        T[0.9 * wavelength(src), 1.1 * wavelength(src)], T[0.2, 0.8])
    spectral_exposure = T(2.5)
    spectral_detectors = map(spectral_products) do _
        Detector(noise=NoiseNone(), qe=spectral_qe,
            exposure_duration=spectral_exposure, binning=1,
            response_model=NullFrameResponse(), T=T, backend=selector)
    end
    spectral_observations = map(spectral_products) do product
        WFSObservation(similar(product.values);
            units=:electron_count, layout=:lenslet_mosaic)
    end
    spectral_acquisition = prepare_wfs_acquisition(spectral_detectors,
        spectral_products, spectral_observations)
    acquire_wfs_observation!(spectral_observations, spectral_products,
        spectral_acquisition, MersenneTwister(149))
    expected_spectral_scale = spectral_exposure *
        T(AdaptiveOpticsSim.Detectors.qe_at(spectral_qe, wavelength(src)))
    for (observation, product) in
            zip(spectral_observations, spectral_products)
        @test Array(observation.storage) ≈
            Array(product.values) .* expected_spectral_scale rtol=5e-5
    end

    distinct = with_spectrum(src, SpectralBundle(
        T[0.9 * wavelength(src), 1.1 * wavelength(src)], T[0.4, 0.6];
        T=T))
    distinct_rate = shack_hartmann_rate_map(sh, pupil, distinct)
    distinct_plan = prepare_wfs_optics(shack_hartmann_optics(sh, distinct),
        pupil, distinct_rate)
    form_wfs_optical_products!(distinct_rate, pupil, distinct_plan)
    @test all(product -> all(isfinite, Array(product.values)),
        distinct_rate.products)

    science_src = Source(band=:K, magnitude=1.0, separation_arcsec=4.0, position_angle_deg=90.0, T=T)
    split_dm = DeformableMirror(tel; n_act=4, influence_width=T(0.3), T=T,
        backend=selector)
    split_det = Detector(noise=NoiseNone(), exposure_duration=one(T), qe=one(T),
        binning=1, T=T, backend=selector)
    science_pupil = PupilFunction(tel; T=T, backend=selector)
    science_renderer = prepare_atmosphere_renderer(
        atm,
        tel,
        science_src,
    )
    render_atmosphere!(
        science_pupil,
        science_renderer,
        atm,
        epoch,
    )
    fill!(AdaptiveOpticsSim.Optics.command_storage(split_dm), T(1e-8))
    update_surface!(split_dm)
    apply_surface!(science_pupil, split_dm, DMAdditive())
    science_imaging = prepare_direct_imaging(
        science_pupil,
        science_src;
        zero_padding=1,
    )
    science_rate = form_direct_image!(science_imaging)
    split_acquisition = prepare_detector_acquisition(split_det, science_rate)
    split_frame = capture!(split_acquisition; rng=MersenneTwister(17))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(split_frame))
    @test split_frame isa BackendArray
    @test all(isfinite, Array(split_frame))

    shared_detector_a = Detector(noise=NoiseNone(), exposure_duration=one(T),
        qe=one(T), binning=1, T=T, backend=selector)
    shared_detector_b = Detector(noise=NoiseNone(), exposure_duration=one(T),
        qe=one(T), binning=1, T=T, backend=selector)
    shared_acquisition_a = prepare_detector_acquisition(
        shared_detector_a, science_rate)
    shared_acquisition_b = prepare_detector_acquisition(
        shared_detector_b, science_rate)
    shared_frame_a = capture!(shared_acquisition_a;
        rng=MersenneTwister(18))
    shared_frame_b = capture!(shared_acquisition_b;
        rng=MersenneTwister(18))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(shared_frame_a))
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(shared_frame_b))
    @test shared_frame_a isa BackendArray
    @test shared_frame_b isa BackendArray
    @test Array(shared_frame_a) ≈ Array(shared_frame_b) atol=0 rtol=0

    run_optional_lift_pipeline_checks(B, BackendArray, T)
    run_optional_backend_plan_checks(B, tel, selector)
    run_optional_independent_optics_parity(B, BackendArray)
    curv = CurvatureWFS(tel; pupil_samples=4, T=T, backend=selector)
    curv_front_end = CurvatureOpticalFrontEnd(curv, src)
    curv_rates = curvature_rate_maps(curv_front_end, pupil)
    curv_optics = prepare_wfs_optics(curv_front_end, pupil, curv_rates)
    form_wfs_optical_products!(curv_rates, pupil, curv_optics)
    AdaptiveOpticsSim.Backends.synchronize_backend!(
        AdaptiveOpticsSim.Backends.execution_style(curv_rates[1].values))
    @test all(rate -> rate.values isa BackendArray, curv_rates)
    @test all(rate -> all(isfinite, Array(rate.values)), curv_rates)

    return nothing
end
