include("geometric_slopes_numerics.jl")

const SCALAR_CPU_STYLE = AdaptiveOpticsSim.Backends.ScalarCPUStyle()
const KA_CPU_EXERCISED_KERNELS = Set{Symbol}()

function mark_ka_cpu_kernel!(names::Symbol...)
    union!(KA_CPU_EXERCISED_KERNELS, names)
    return nothing
end

function source_kernel_names()
    src_root = normpath(joinpath(@__DIR__, "..", "src"))
    rx = r"^@kernel function\s+([A-Za-z_]\w*!)"
    names = Set{Symbol}()
    for (root, _, files) in walkdir(src_root)
        for file in files
            endswith(file, ".jl") || continue
            for line in eachline(joinpath(root, file))
                m = match(rx, line)
                m === nothing || push!(names, Symbol(m.captures[1]))
            end
        end
    end
    return names
end

function ka_cpu_close(actual, expected; atol=1e-12, rtol=1e-12)
    return actual == expected || isapprox(actual, expected; atol=atol, rtol=rtol)
end

@testset "KA CPU Matrix" begin
    @testset "Core kernels" begin
        src = reshape(collect(1.0:16.0), 4, 4)

        scalar_fftshift = similar(src)
        ka_fftshift = similar(src)
        AdaptiveOpticsSim._fftshift2d!(SCALAR_CPU_STYLE, scalar_fftshift, src)
        AdaptiveOpticsSim._fftshift2d!(KA_CPU_STYLE, ka_fftshift, src)
        mark_ka_cpu_kernel!(:fftshift2d_kernel!)
        @test ka_fftshift == scalar_fftshift

        scalar_shift = similar(src)
        ka_shift = similar(src)
        AdaptiveOpticsSim._circshift2d!(SCALAR_CPU_STYLE, scalar_shift, src, (1, -1))
        AdaptiveOpticsSim._circshift2d!(KA_CPU_STYLE, ka_shift, src, (1, -1))
        mark_ka_cpu_kernel!(:circshift2d_kernel!)
        @test ka_shift == scalar_shift
        @test scalar_shift == circshift(src, (1, -1))
        @test @allocated(AdaptiveOpticsSim._circshift2d!(SCALAR_CPU_STYLE,
            scalar_shift, src, (1, -1))) == 0

        packed_source = reshape(collect(1.0:12.0), 3, 4)
        packed_destination = similar(packed_source)
        Backends._copyto_backend_async!(
            KA_CPU_STYLE,
            packed_destination,
            packed_source,
        )
        Backends.synchronize_backend!(KA_CPU_STYLE)
        mark_ka_cpu_kernel!(:_copy_packed_array_kernel!)
        @test packed_destination == packed_source

        scalar_bin = Matrix{Float64}(undef, 2, 2)
        ka_bin = similar(scalar_bin)
        AdaptiveOpticsSim._bin2d!(SCALAR_CPU_STYLE, scalar_bin, src, 2)
        AdaptiveOpticsSim._bin2d!(KA_CPU_STYLE, ka_bin, src, 2)
        mark_ka_cpu_kernel!(:bin2d_kernel!)
        @test ka_bin == scalar_bin

        complex_src = complex.(src, reverse(src; dims=1))
        scalar_abs2_bin = similar(scalar_bin)
        ka_abs2_bin = similar(scalar_bin)
        AdaptiveOpticsSim._bin2d_abs2!(SCALAR_CPU_STYLE,
            scalar_abs2_bin, complex_src, 2)
        AdaptiveOpticsSim._bin2d_abs2!(KA_CPU_STYLE, ka_abs2_bin,
            complex_src, 2)
        mark_ka_cpu_kernel!(:bin2d_abs2_kernel!)
        @test ka_abs2_bin == scalar_abs2_bin

        scalar_freqs = Vector{Float64}(undef, 8)
        ka_freqs = similar(scalar_freqs)
        AdaptiveOpticsSim._fftfreq!(SCALAR_CPU_STYLE, scalar_freqs, 8, 0.25, 0.0)
        AdaptiveOpticsSim._fftfreq!(KA_CPU_STYLE, ka_freqs, 8, 0.25, 0.0)
        mark_ka_cpu_kernel!(:fftfreq_kernel!)
        @test ka_freqs == scalar_freqs

        counter_state = Backends._CounterRandomState(UInt64[0])
        counter_rng = Backends._PreparedCounterRNG(
            Backends._CounterRandomPlan(UInt64(0x1234)),
            counter_state,
        )
        normal_draw = zeros(Float32, 32)
        Backends.randn_backend_async!(
            KA_CPU_STYLE,
            counter_rng,
            normal_draw,
        )
        Backends.synchronize_backend!(KA_CPU_STYLE)
        first_normal_draw = copy(normal_draw)
        @test counter_state.draw_sequence == UInt64[1]
        @test all(isfinite, first_normal_draw)

        Backends.randn_backend_async!(
            KA_CPU_STYLE,
            counter_rng,
            normal_draw,
        )
        Backends.synchronize_backend!(KA_CPU_STYLE)
        @test counter_state.draw_sequence == UInt64[2]
        @test normal_draw != first_normal_draw

        Backends._reset_graph_rng!(counter_rng, UInt64(0x1234))
        Backends.randn_backend_async!(
            KA_CPU_STYLE,
            counter_rng,
            normal_draw,
        )
        Backends.synchronize_backend!(KA_CPU_STYLE)
        @test normal_draw == first_normal_draw

        uniform_draw = zeros(Float32, 32)
        Backends._rand_uniform_backend!(
            KA_CPU_STYLE,
            counter_rng,
            uniform_draw,
        )
        @test all(x -> 0 < x < 1, uniform_draw)

        poisson_draw = fill(8.0f0, 32)
        Backends.poisson_noise_async!(
            KA_CPU_STYLE,
            counter_rng,
            poisson_draw,
        )
        Backends.synchronize_backend!(KA_CPU_STYLE)
        @test all(x -> x >= 0 && isinteger(x), poisson_draw)

        Backends.launch_kernel!(
            KA_CPU_STYLE,
            Backends._reset_random_draw_kernel!,
            counter_state.draw_sequence;
            ndrange=1,
        )
        @test counter_state.draw_sequence == UInt64[0]
        mark_ka_cpu_kernel!(
            :_advance_random_draw_kernel!,
            :_reset_random_draw_kernel!,
            :_counter_randn_fill_kernel!,
            :_counter_uniform_fill_kernel!,
            :_counter_poisson_noise_kernel!,
        )

        scalar_clamped = [-1.0, 0.5, 2.0]
        ka_clamped = copy(scalar_clamped)
        AdaptiveOpticsSim.Backends._clamp_array!(SCALAR_CPU_STYLE, scalar_clamped, 0.0, 1.0)
        AdaptiveOpticsSim.Backends._clamp_array!(KA_CPU_STYLE, ka_clamped, 0.0, 1.0)
        mark_ka_cpu_kernel!(:clamp_array_kernel!)
        @test ka_clamped == scalar_clamped == [0.0, 0.5, 1.0]

        integer_input = [-1.0 1.4; 2.6 300.0]
        scalar_integer_output = Matrix{UInt8}(undef, 2, 2)
        ka_integer_output = similar(scalar_integer_output)
        AdaptiveOpticsSim.Backends._write_integer_output!(SCALAR_CPU_STYLE,
            scalar_integer_output, integer_input)
        AdaptiveOpticsSim.Backends._write_integer_output!(KA_CPU_STYLE, ka_integer_output,
            integer_input)
        mark_ka_cpu_kernel!(:integer_output_kernel!)
        @test ka_integer_output == scalar_integer_output == UInt8[0 1; 3 255]

        diagonal_input = reshape(collect(1.0:16.0), 4, 4)
        diagonal_output = zeros(4)
        AdaptiveOpticsSim.Backends.launch_kernel!(KA_CPU_STYLE,
            AdaptiveOpticsSim.Tomography.extract_diagonal_kernel!,
            diagonal_output,
            diagonal_input, 4; ndrange=4)
        mark_ka_cpu_kernel!(:extract_diagonal_kernel!)
        @test diagonal_output == diag(diagonal_input)

        lift_basis = reshape(collect(1.0:12.0), 2, 2, 3)
        lift_base = reshape(collect(0.25:0.25:1.0), 2, 2)
        scalar_lift_scaled = similar(lift_base)
        ka_lift_scaled = similar(lift_base)
        AdaptiveOpticsSim.WavefrontSensors.lift_scaled_basis_mode!(
            SCALAR_CPU_STYLE,
            scalar_lift_scaled, lift_base, lift_basis, 3, 2.0)
        AdaptiveOpticsSim.WavefrontSensors.lift_scaled_basis_mode!(
            KA_CPU_STYLE,
            ka_lift_scaled, lift_base, lift_basis, 3, 2.0)
        mark_ka_cpu_kernel!(:lift_scaled_basis_mode_kernel!)
        @test ka_lift_scaled == scalar_lift_scaled

        scalar_lift_jacobian = zeros(4, 2)
        ka_lift_jacobian = zeros(4, 2)
        AdaptiveOpticsSim.WavefrontSensors.lift_copy_column!(
            SCALAR_CPU_STYLE,
            scalar_lift_jacobian, 2, scalar_lift_scaled)
        AdaptiveOpticsSim.WavefrontSensors.lift_copy_column!(
            KA_CPU_STYLE,
            ka_lift_jacobian, 2, ka_lift_scaled)
        mark_ka_cpu_kernel!(:lift_copy_column_kernel!)
        @test ka_lift_jacobian == scalar_lift_jacobian

        lift_convolution_source = reshape(collect(1.0:25.0), 5, 5)
        lift_dense_kernel = [0.0 1.0 0.0; 1.0 4.0 1.0; 0.0 1.0 0.0]
        dense_inv_norm = inv(sum(lift_dense_kernel))
        scalar_dense_convolution = similar(lift_convolution_source)
        ka_dense_convolution = similar(lift_convolution_source)
        AdaptiveOpticsSim.WavefrontSensors.conv2d_same!(
            SCALAR_CPU_STYLE,
            scalar_dense_convolution, lift_convolution_source,
            lift_dense_kernel, dense_inv_norm)
        AdaptiveOpticsSim.WavefrontSensors.conv2d_same!(
            KA_CPU_STYLE,
            ka_dense_convolution, lift_convolution_source,
            lift_dense_kernel, dense_inv_norm)
        mark_ka_cpu_kernel!(:lift_dense_convolution_kernel!)
        @test ka_dense_convolution == scalar_dense_convolution

        lift_row_kernel = [1.0, 2.0, 1.0]
        lift_column_kernel = [1.0, 0.5, 1.0]
        separable_inv_norm = inv(sum(lift_row_kernel) *
            sum(lift_column_kernel))
        scalar_separable_convolution = similar(lift_convolution_source)
        scalar_separable_scratch = similar(lift_convolution_source)
        ka_separable_convolution = similar(lift_convolution_source)
        ka_separable_scratch = similar(lift_convolution_source)
        AdaptiveOpticsSim.WavefrontSensors.conv2d_same_separable!(
            SCALAR_CPU_STYLE,
            scalar_separable_convolution, scalar_separable_scratch,
            lift_convolution_source, lift_row_kernel, lift_column_kernel,
            separable_inv_norm)
        AdaptiveOpticsSim.WavefrontSensors.conv2d_same_separable!(
            KA_CPU_STYLE,
            ka_separable_convolution, ka_separable_scratch,
            lift_convolution_source, lift_row_kernel, lift_column_kernel,
            separable_inv_norm)
        mark_ka_cpu_kernel!(:lift_row_convolution_kernel!,
            :lift_column_convolution_kernel!)
        @test ka_separable_convolution == scalar_separable_convolution

        modal_modes = reshape(collect(1.0:8.0), 4, 2)
        modal_coefs = [0.25, -0.5]
        modal_one = zeros(4)
        modal_two = zeros(4)
        AdaptiveOpticsSim.Backends.launch_kernel!(KA_CPU_STYLE,
            AdaptiveOpticsSim.Optics.modal_opd_one_kernel!, modal_one,
            modal_modes,
            modal_coefs, 4; ndrange=4)
        AdaptiveOpticsSim.Backends.launch_kernel!(KA_CPU_STYLE,
            AdaptiveOpticsSim.Optics.modal_opd_two_kernel!, modal_two,
            modal_modes,
            modal_coefs, 4; ndrange=4)
        mark_ka_cpu_kernel!(:modal_opd_one_kernel!, :modal_opd_two_kernel!)
        @test modal_one == modal_modes[:, 1] .* modal_coefs[1]
        @test modal_two == modal_modes * modal_coefs

        pupil_amplitude = reshape(collect(1.0:4.0), 2, 2)
        pupil_opd = zeros(2, 2)
        branch_fields = zeros(ComplexF64, 4, 4, 2)
        defocus_stack = ones(ComplexF64, 4, 4, 2)
        curvature_phasor = ones(ComplexF64, 4, 4)
        AdaptiveOpticsSim.Backends.launch_kernel!(KA_CPU_STYLE,
            AdaptiveOpticsSim.WavefrontSensors.curvature_branch_field_from_pupil_kernel!,
            branch_fields, pupil_amplitude, pupil_opd, defocus_stack,
            curvature_phasor, 2.0, 1.0, 1, 1, 2, 4;
            ndrange=size(branch_fields))
        mark_ka_cpu_kernel!(:curvature_branch_field_from_pupil_kernel!)
        @test branch_fields[2:3, 2:3, 1] == 2 .* pupil_amplitude
        @test branch_fields[:, :, 1] == branch_fields[:, :, 2]

        rng1 = MersenneTwister(11)
        rng2 = MersenneTwister(11)
        ka_randn_a = zeros(Float64, 8)
        ka_randn_b = zeros(Float64, 8)
        AdaptiveOpticsSim.Backends.randn_backend_async!(KA_CPU_STYLE, rng1, ka_randn_a)
        KernelAbstractions.synchronize(KA_CPU_STYLE.backend)
        AdaptiveOpticsSim.Backends.randn_backend_async!(KA_CPU_STYLE, rng2, ka_randn_b)
        KernelAbstractions.synchronize(KA_CPU_STYLE.backend)
        mark_ka_cpu_kernel!(:randn_fill_kernel!)
        @test ka_randn_a == ka_randn_b
        @test all(isfinite, ka_randn_a)

        sync_rng1 = MersenneTwister(17)
        sync_rng2 = MersenneTwister(17)
        ka_sync_randn_a = zeros(Float64, 8)
        ka_sync_randn_b = zeros(Float64, 8)
        AdaptiveOpticsSim.Backends._randn_backend!(
            KA_CPU_STYLE, sync_rng1, ka_sync_randn_a)
        AdaptiveOpticsSim.Backends._randn_backend!(
            KA_CPU_STYLE, sync_rng2, ka_sync_randn_b)
        @test ka_sync_randn_a == ka_sync_randn_b
        @test all(isfinite, ka_sync_randn_a)

        uniform_rng1 = MersenneTwister(13)
        uniform_rng2 = MersenneTwister(13)
        ka_uniform_a = zeros(Float64, 8)
        ka_uniform_b = zeros(Float64, 8)
        AdaptiveOpticsSim.Backends._rand_uniform_backend!(KA_CPU_STYLE, uniform_rng1,
            ka_uniform_a)
        AdaptiveOpticsSim.Backends._rand_uniform_backend!(KA_CPU_STYLE, uniform_rng2,
            ka_uniform_b)
        mark_ka_cpu_kernel!(:uniform_fill_kernel!)
        @test ka_uniform_a == ka_uniform_b
        @test all(x -> 0 < x < 1, ka_uniform_a)

        rng3 = MersenneTwister(12)
        rng4 = MersenneTwister(12)
        ka_poisson_a = [0.0, 4.0, 40.0, 0.0, 4.0, 40.0, 4.0, 40.0]
        ka_poisson_b = copy(ka_poisson_a)
        AdaptiveOpticsSim.Backends.poisson_noise_async!(KA_CPU_STYLE, rng3, ka_poisson_a)
        KernelAbstractions.synchronize(KA_CPU_STYLE.backend)
        AdaptiveOpticsSim.Backends.poisson_noise_async!(KA_CPU_STYLE, rng4, ka_poisson_b)
        KernelAbstractions.synchronize(KA_CPU_STYLE.backend)
        mark_ka_cpu_kernel!(:poisson_noise_kernel!)
        @test ka_poisson_a == ka_poisson_b
        @test iszero(ka_poisson_a[1])
        @test iszero(ka_poisson_a[4])
        @test all(x -> x >= 0, ka_poisson_a)
        @test all(x -> x == floor(x), ka_poisson_a)

        sync_poisson_rng1 = MersenneTwister(19)
        sync_poisson_rng2 = MersenneTwister(19)
        ka_sync_poisson_a = fill(4.0, 8)
        ka_sync_poisson_b = copy(ka_sync_poisson_a)
        AdaptiveOpticsSim.Backends._poisson_noise!(
            KA_CPU_STYLE, sync_poisson_rng1, ka_sync_poisson_a)
        AdaptiveOpticsSim.Backends._poisson_noise!(
            KA_CPU_STYLE, sync_poisson_rng2, ka_sync_poisson_b)
        @test ka_sync_poisson_a == ka_sync_poisson_b
        @test all(x -> x >= 0, ka_sync_poisson_a)
    end

    @testset "Telescope and pupil kernels" begin
        params = TelescopeParams{Float64}(16, 8.0, 0.15, 0.0)
        scalar_pupil = Matrix{Bool}(undef, 16, 16)
        ka_pupil = similar(scalar_pupil)
        AdaptiveOpticsSim.Optics._generate_pupil!(SCALAR_CPU_STYLE, scalar_pupil, params)
        AdaptiveOpticsSim.Optics._generate_pupil!(KA_CPU_STYLE, ka_pupil, params)
        mark_ka_cpu_kernel!(:radial_mask_kernel!)
        @test ka_pupil == scalar_pupil

        scalar_spiders = copy(scalar_pupil)
        ka_spiders = copy(ka_pupil)
        angles_deg = [0.0, 45.0, 90.0]
        AdaptiveOpticsSim.Optics._apply_spiders!(SCALAR_CPU_STYLE, scalar_spiders, angles_deg, 0.1, 0.0, 0.0, 8.5, 8.5, 8.0, 16)
        AdaptiveOpticsSim.Optics._apply_spiders!(KA_CPU_STYLE, ka_spiders, angles_deg, 0.1, 0.0, 0.0, 8.5, 8.5, 8.0, 16)
        mark_ka_cpu_kernel!(:spider_mask_kernel!)
        @test ka_spiders == scalar_spiders

        scalar_roi = falses(8, 8)
        ka_roi = similar(scalar_roi)
        roi = AdaptiveOpticsSim.Optics.RectangularROI(2:6, 3:7)
        AdaptiveOpticsSim.Optics._build_rectangular_roi!(SCALAR_CPU_STYLE, scalar_roi, roi, true, false)
        AdaptiveOpticsSim.Optics._build_rectangular_roi!(KA_CPU_STYLE, ka_roi, roi, true, false)
        mark_ka_cpu_kernel!(:rectangular_roi_kernel!)
        @test ka_roi == scalar_roi
    end

    @testset "Wavefront support kernels" begin
        pupil = trues(8, 8)
        pupil[1:2, :] .= false
        threshold = 0.4
        scalar_valid = Matrix{Bool}(undef, 2, 2)
        ka_valid = similar(scalar_valid)
        AdaptiveOpticsSim.WavefrontSensors._set_valid_subapertures!(
            SCALAR_CPU_STYLE, scalar_valid, pupil, threshold, 4, 2)
        AdaptiveOpticsSim.WavefrontSensors._set_valid_subapertures!(
            KA_CPU_STYLE, ka_valid, pupil, threshold, 4, 2)
        mark_ka_cpu_kernel!(:subaperture_grid_mask_kernel!)
        @test ka_valid == scalar_valid

        opd = reshape(collect(1.0:64.0), 8, 8)
        scalar_slopes = Vector{Float64}(undef, 8)
        ka_slopes = similar(scalar_slopes)
        AdaptiveOpticsSim.WavefrontSensors._geometric_slopes!(
            SCALAR_CPU_STYLE, scalar_slopes, opd, scalar_valid, 4, 2, 4)
        AdaptiveOpticsSim.WavefrontSensors._geometric_slopes!(
            KA_CPU_STYLE, ka_slopes, opd, ka_valid, 4, 2, 4)
        mark_ka_cpu_kernel!(:cooperative_geometric_slopes_kernel!)
        test_geometric_slopes_numerics(identity, KA_CPU_STYLE)
        mark_ka_cpu_kernel!(:geometric_slopes_kernel!)
        @test ka_slopes == scalar_slopes

        edge_mask = falses(8, 8)
        edge_mask[:, 1] .= true
        edge_mask[:, end] .= true
        edge_mask[1, :] .= true
        edge_mask[end, :] .= true
        scalar_edge_slopes = Vector{Float64}(undef, 8)
        ka_edge_slopes = similar(scalar_edge_slopes)
        AdaptiveOpticsSim.WavefrontSensors._edge_geometric_slopes!(
            SCALAR_CPU_STYLE, scalar_edge_slopes, opd, scalar_valid,
            edge_mask, 4, 2, 4)
        AdaptiveOpticsSim.WavefrontSensors._edge_geometric_slopes!(
            KA_CPU_STYLE, ka_edge_slopes, opd, ka_valid, edge_mask, 4, 2, 4)
        mark_ka_cpu_kernel!(:edge_geometric_slopes_kernel!)
        @test ka_edge_slopes == scalar_edge_slopes

        spot_cube = reshape(collect(1.0:36.0), 4, 3, 3)
        scalar_rate_map = Matrix{Float64}(undef, 7, 7)
        ka_rate_map = similar(scalar_rate_map)
        WavefrontSensors._tile_shack_hartmann_spot_cube!(
            SCALAR_CPU_STYLE, SCALAR_CPU_STYLE, scalar_rate_map, spot_cube, 2, 3, 3, 1, -1.0)
        WavefrontSensors._tile_shack_hartmann_spot_cube!(
            KA_CPU_STYLE, KA_CPU_STYLE, ka_rate_map, spot_cube, 2, 3, 3, 1, -1.0)
        mark_ka_cpu_kernel!(:_shack_hartmann_rate_map_copy_kernel!)
        @test ka_rate_map == scalar_rate_map

        scalar_converted_rate_map = Matrix{Float32}(undef, 7, 7)
        ka_converted_rate_map = similar(scalar_converted_rate_map)
        WavefrontSensors._tile_shack_hartmann_spot_cube!(
            SCALAR_CPU_STYLE, SCALAR_CPU_STYLE, scalar_converted_rate_map, spot_cube,
            2, 3, 3, 1, -1.0)
        WavefrontSensors._tile_shack_hartmann_spot_cube!(
            KA_CPU_STYLE, KA_CPU_STYLE, ka_converted_rate_map, spot_cube,
            2, 3, 3, 1, -1.0)
        mark_ka_cpu_kernel!(:_shack_hartmann_rate_map_kernel!)
        @test ka_converted_rate_map == scalar_converted_rate_map
    end

    @testset "Grouped and Shack-Hartmann stack kernels" begin
        stack = reshape(collect(1.0:48.0), 4, 4, 3)
        scalar_group = Matrix{Float64}(undef, 4, 4)
        ka_group = similar(scalar_group)
        AdaptiveOpticsSim.WavefrontSensors.reduce_grouped_stack!(
            SCALAR_CPU_STYLE, scalar_group, stack, 3)
        AdaptiveOpticsSim.WavefrontSensors.reduce_grouped_stack!(
            KA_CPU_STYLE, ka_group, stack, 3)
        mark_ka_cpu_kernel!(:reduce_grouped_stack_kernel!)
        @test ka_group == scalar_group

        block_stack = reshape(collect(1.0:128.0), 4, 4, 8)
        block_out = zeros(Float64, 4, 4, 4)
        AdaptiveOpticsSim.WavefrontSensors.reduce_grouped_blocks!(
            KA_CPU_STYLE, block_out, block_stack, 4, 2)
        mark_ka_cpu_kernel!(:reduce_grouped_blocks_kernel!)
        @test block_out == block_stack[:, :, 1:4] .+ block_stack[:, :, 5:8]

        @test size(AdaptiveOpticsSim.WavefrontSensors.grouped_stack_view(stack, 2), 3) == 2
        grouped_tel = Telescope(resolution=8, diameter=8.0, central_obstruction=0.0)
        grouped_wfs = ShackHartmannWFS(grouped_tel; n_lenslets=2, n_pix_subap=2)
        grouped_sources = [1.0, 2.0, 3.0]
        function fill_grouped_stage!(dest, scale, value)
            fill!(dest, scale * value)
            return dest
        end
        scalar_accum = zeros(Float64, 2, 2)
        scalar_stack = zeros(Float64, 2, 2, length(grouped_sources))
        AdaptiveOpticsSim.WavefrontSensors.accumulate_grouped_sources!(
            AdaptiveOpticsSim.WavefrontSensors.GroupedStackReduceStrategy(),
            SCALAR_CPU_STYLE, grouped_wfs,
            scalar_accum, scalar_stack, grouped_sources, fill_grouped_stage!, 2.0)
        @test scalar_accum == fill(12.0, 2, 2)
        ka_accum = zeros(Float64, 2, 2)
        ka_stack = zeros(Float64, 2, 2, length(grouped_sources))
        AdaptiveOpticsSim.WavefrontSensors.accumulate_grouped_sources!(
            AdaptiveOpticsSim.WavefrontSensors.GroupedStackReduceStrategy(),
            KA_CPU_STYLE, grouped_wfs,
            ka_accum, ka_stack, grouped_sources, fill_grouped_stage!, 2.0)
        @test ka_accum == scalar_accum
        staged_scalar = zeros(Float64, 2, 2)
        staged_scalar_stack = zeros(Float64, 2, 2, length(grouped_sources))
        AdaptiveOpticsSim.WavefrontSensors.accumulate_grouped_sources!(
            AdaptiveOpticsSim.WavefrontSensors.GroupedStaged2DStrategy(),
            SCALAR_CPU_STYLE, grouped_wfs,
            staged_scalar, staged_scalar_stack, grouped_sources, fill_grouped_stage!, 3.0)
        @test staged_scalar == fill(18.0, 2, 2)
        staged_ka = zeros(Float64, 2, 2)
        staged_ka_stack = zeros(Float64, 2, 2, length(grouped_sources))
        AdaptiveOpticsSim.WavefrontSensors.accumulate_grouped_sources!(
            AdaptiveOpticsSim.WavefrontSensors.GroupedStaged2DStrategy(),
            KA_CPU_STYLE, grouped_wfs,
            staged_ka, staged_ka_stack, grouped_sources, fill_grouped_stage!, 3.0)
        @test staged_ka == staged_scalar
        dispatch_accum = zeros(Float64, 2, 2)
        dispatch_stack = zeros(Float64, 2, 2, length(grouped_sources))
        @test AdaptiveOpticsSim.WavefrontSensors.grouped_accumulation_strategy(KA_CPU_STYLE, grouped_wfs) isa
            AdaptiveOpticsSim.WavefrontSensors.GroupedStackReduceStrategy
        AdaptiveOpticsSim.WavefrontSensors.accumulate_grouped_sources!(
            KA_CPU_STYLE, grouped_wfs, dispatch_accum, dispatch_stack,
            grouped_sources, fill_grouped_stage!, 1.0)
        @test dispatch_accum == fill(6.0, 2, 2)

        mask = Bool[1 0; 1 1]
        values = [1.0 2.0; 3.0 4.0]
        values_view = @view values[1:2, 1:2]
        @test AdaptiveOpticsSim.Backends.masked_sum2d(values, mask) == 8.0
        scalar_buffer = zeros(Float64, 1)
        scalar_host = zeros(Float64, 1)
        host_parent = zeros(Float64, size(values)...)
        @test first(AdaptiveOpticsSim.Backends.masked_sum2d(KA_CPU_STYLE, values_view, mask, mask,
            scalar_buffer, scalar_host, host_parent)) == 8.0
        @test AdaptiveOpticsSim.Backends.backend_maximum_value(KA_CPU_STYLE, values) == 4.0
        signal = collect(1.0:8.0)
        @test AdaptiveOpticsSim.Backends.packed_valid_pair_mean(KA_CPU_STYLE, signal, mask) ==
              AdaptiveOpticsSim.Backends.packed_valid_pair_mean(AdaptiveOpticsSim.Backends.DirectReductionStrategy(), signal, mask)
        @test AdaptiveOpticsSim.Backends.packed_valid_pair_mean(AdaptiveOpticsSim.Backends.HostMirrorReductionStrategy(), signal, mask) ==
              AdaptiveOpticsSim.Backends.packed_valid_pair_mean(SCALAR_CPU_STYLE, signal, mask)

        n_sub = 2
        sub = 2
        n = 4
        pad = 4
        ox = 1
        oy = 1
        n_spots = n_sub * n_sub
        valid_mask = Bool[1 0; 1 1]
        pupil = trues(n, n)
        opd = zeros(Float64, n, n)
        phasor = ones(ComplexF64, pad, pad)
        # The retained intensity and sampling stages consume a lenslet FFT
        # stack.  The retired field-stack kernels are superseded by the
        # explicit pupil/field kernels exercised below.
        fft_stack = zeros(ComplexF64, pad, pad, n_spots)
        fft_stack[2, 2, 1] = 2.0 + 0.0im
        fft_stack[3, 3, 4] = 2.0 + 0.0im
        @test fft_stack[2, 2, 1] == 2.0 + 0.0im
        @test fft_stack[2, 2, 3] == 0.0 + 0.0im
        @test fft_stack[3, 3, 4] == 2.0 + 0.0im
        @test fft_stack[1, 1, 1] == 0.0 + 0.0im

        intensity_stack = zeros(Float64, pad, pad, n_spots)
        intensity_scale = WavefrontSensors.sh_fft_intensity_scale(Float64, pad)
        AdaptiveOpticsSim.Backends.launch_kernel!(KA_CPU_STYLE, WavefrontSensors.complex_abs2_stack_kernel!,
            intensity_stack, fft_stack, intensity_scale, pad, n_spots;
            ndrange=size(intensity_stack))
        mark_ka_cpu_kernel!(:complex_abs2_stack_kernel!)
        @test intensity_stack[2, 2, 1] == 4.0 * intensity_scale
        @test intensity_stack[2, 2, 3] == 0.0

        amp_scales = [2.0, 3.0]
        opd_to_cycles = [0.0, 0.0]
        explicit_amplitude = fill(0.5, n, n)
        explicit_fft_ast = fill(99.0 + 0.0im, pad, pad,
            2 * n_spots)
        AdaptiveOpticsSim.Backends.launch_kernel!(KA_CPU_STYLE,
            WavefrontSensors.sh_explicit_pupil_asterism_stack_kernel!,
            explicit_fft_ast, valid_mask, explicit_amplitude, opd, phasor,
            amp_scales, opd_to_cycles, n_sub, sub, ox, oy, n, pad,
            n_spots, length(amp_scales);
            ndrange=(pad, pad, length(amp_scales), n_sub, n_sub))
        mark_ka_cpu_kernel!(:sh_explicit_pupil_asterism_stack_kernel!)
        @test explicit_fft_ast[2, 2, 1] == 1.0 + 0.0im
        @test explicit_fft_ast[2, 2, n_spots + 1] == 1.5 + 0.0im
        @test explicit_fft_ast[2, 2, 3] == 0.0 + 0.0im

        explicit_pupil_fft = fill(99.0 + 0.0im, pad, pad, n_spots)
        AdaptiveOpticsSim.Backends.launch_kernel!(KA_CPU_STYLE,
            WavefrontSensors.sh_explicit_pupil_stack_kernel!,
            explicit_pupil_fft, valid_mask, explicit_amplitude, opd, phasor,
            2.0, 0.0, n_sub, sub, ox, oy, n, pad;
            ndrange=(pad, pad, n_sub, n_sub))
        mark_ka_cpu_kernel!(:sh_explicit_pupil_stack_kernel!)
        @test explicit_pupil_fft[2, 2, 1] == 1.0 + 0.0im
        @test explicit_pupil_fft[2, 2, 3] == 0.0 + 0.0im
        @test explicit_pupil_fft[3, 3, 4] == 1.0 + 0.0im
        @test explicit_pupil_fft[1, 1, 1] == 0.0 + 0.0im

        pupil_field = fill(0.25 + 0.5im, n, n)
        explicit_field_fft = fill(99.0 + 0.0im, pad, pad, n_spots)
        AdaptiveOpticsSim.Backends.launch_kernel!(KA_CPU_STYLE,
            WavefrontSensors.sh_explicit_field_stack_kernel!,
            explicit_field_fft, valid_mask, pupil_field, phasor, n_sub, sub,
            ox, oy, n, pad; ndrange=(pad, pad, n_sub, n_sub))
        mark_ka_cpu_kernel!(:sh_explicit_field_stack_kernel!)
        @test explicit_field_fft[2, 2, 1] == 0.25 + 0.5im
        @test explicit_field_fft[2, 2, 3] == 0.0 + 0.0im
        @test explicit_field_fft[3, 3, 4] == 0.25 + 0.5im
        @test explicit_field_fft[1, 1, 1] == 0.0 + 0.0im

        sample_input = reshape(collect(1.0:64.0), 4, 4, n_spots)
        sampled = fill(-1.0, n_spots, 2, 2)
        AdaptiveOpticsSim.Backends.launch_kernel!(KA_CPU_STYLE, WavefrontSensors.sh_sample_spot_stack_kernel!,
            sampled, sample_input, valid_mask, 2.0, n_sub, 4, 2;
            ndrange=(n_sub, n_sub, 2, 2))
        mark_ka_cpu_kernel!(:sh_sample_spot_stack_kernel!)
        @test sampled[1, 1, 1] == sum(sample_input[1:2, 1:2, 1])
        @test sampled[3, 1, 1] == 0.0
        @test sampled[4, 2, 2] == sum(sample_input[3:4, 3:4, 4])

    end

    @testset "Atmosphere kernels" begin
        freqs = collect(range(0.0, 1.0; length=8))
        scalar_psd = Matrix{Float64}(undef, 8, 8)
        ka_psd = similar(scalar_psd)
        AdaptiveOpticsSim.Atmospheres.update_psd!(SCALAR_CPU_STYLE, scalar_psd, freqs, 0.02, 0.01, -11 / 6, 8)
        AdaptiveOpticsSim.Atmospheres.update_psd!(KA_CPU_STYLE, ka_psd, freqs, 0.02, 0.01, -11 / 6, 8)
        mark_ka_cpu_kernel!(:kolmogorov_psd_kernel!)
        @test ka_cpu_close(ka_psd, scalar_psd)

        scalar_phase_psd = similar(scalar_psd)
        ka_phase_psd = similar(scalar_psd)
        AdaptiveOpticsSim.Atmospheres._fill_phase_psd!(SCALAR_CPU_STYLE, scalar_phase_psd, freqs, 0.02, 0.01, -11 / 6, 0.0, 8)
        AdaptiveOpticsSim.Atmospheres._fill_phase_psd!(KA_CPU_STYLE, ka_phase_psd, freqs, 0.02, 0.01, -11 / 6, 0.0, 8)
        mark_ka_cpu_kernel!(:phase_screen_psd_kernel!)
        @test ka_cpu_close(ka_phase_psd, scalar_phase_psd)

        scalar_spectrum = AdaptiveOpticsSim.Atmospheres.phase_spectrum(freqs, 0.15, 25.0)
        ka_spectrum_out = similar(freqs)
        T = eltype(freqs)
        coeff = T(0.023) * T(0.15)^(-T(5) / T(3))
        AdaptiveOpticsSim.Atmospheres._phase_spectrum!(KA_CPU_STYLE, ka_spectrum_out, freqs, coeff, inv(T(25.0))^2, -T(11) / T(6))
        mark_ka_cpu_kernel!(:phase_spectrum_kernel!)
        @test ka_cpu_close(ka_spectrum_out, scalar_spectrum)

        rho = reshape(collect(range(0.0, 1.0; length=16)), 4, 4)
        scalar_cov = AdaptiveOpticsSim.Atmospheres.phase_covariance(rho, 0.15, 25.0)
        ka_cov = AdaptiveOpticsSim.Atmospheres._phase_covariance(KA_CPU_STYLE, rho, 0.15, 25.0)
        mark_ka_cpu_kernel!(:phase_covariance_kernel!)
        @test ka_cpu_close(ka_cov, scalar_cov; rtol=1e-8, atol=1e-8)

        screen = reshape(collect(1.0:100.0), 10, 10)
        scalar_extract = Matrix{Float64}(undef, 4, 4)
        ka_extract = similar(scalar_extract)
        AdaptiveOpticsSim.Atmospheres.extract_shifted_screen!(scalar_extract, screen, 0.25, -0.5, 0.75, 1.0)
        AdaptiveOpticsSim.Atmospheres._extract_shifted_screen!(KA_CPU_STYLE, ka_extract, screen, 3.75, 4.5, 1.0, 0.75, 4, 10)
        mark_ka_cpu_kernel!(:moving_layer_extract_kernel!)
        @test ka_cpu_close(ka_extract, scalar_extract)

        scalar_accum = fill(2.0, 4, 4)
        ka_accum = fill(2.0, 4, 4)
        AdaptiveOpticsSim.Atmospheres.accumulate_shifted_screen!(scalar_accum, screen, 0.25, -0.5, 0.75, 1.0)
        AdaptiveOpticsSim.Atmospheres._accumulate_shifted_screen!(KA_CPU_STYLE, ka_accum, screen, 3.75, 4.5, 1.0, 0.75, 4, 10)
        mark_ka_cpu_kernel!(:moving_layer_accumulate_kernel!)
        @test ka_cpu_close(ka_accum, scalar_accum)

        batch_shift_x = [0.25 -0.5; 0.125 0.75]
        batch_shift_y = [-0.5 0.375; 0.25 -0.125]
        batch_scale = [1.0 0.8; 0.9 1.0]
        batch_pupil = trues(4, 4)
        batch_pupil[1, 1] = false
        batch_pupil[4, 3] = false
        batch_output = fill(-99.0, 4, 4, 2)
        batch_expected = similar(batch_output)

        first_offset_x = 0.2
        first_offset_y = -0.3
        first_amplitude = 0.75
        AdaptiveOpticsSim.Backends.launch_kernel!(
            KA_CPU_STYLE,
            AdaptiveOpticsSim.Atmospheres.atmosphere_direction_layer_batch_kernel!,
            batch_output,
            screen,
            batch_shift_x,
            batch_shift_y,
            batch_scale,
            batch_pupil,
            first_offset_x,
            first_offset_y,
            first_amplitude,
            1,
            4,
            10,
            2,
            true;
            ndrange=size(batch_output),
        )
        @inbounds for direction in axes(batch_expected, 3)
            expected_slice = @view batch_expected[:, :, direction]
            AdaptiveOpticsSim.Atmospheres.extract_shifted_screen!(
                expected_slice,
                screen,
                first_offset_x - batch_shift_x[1, direction],
                first_offset_y - batch_shift_y[1, direction],
                first_amplitude,
                batch_scale[1, direction],
            )
            expected_slice .*= batch_pupil
        end
        @test ka_cpu_close(batch_output, batch_expected)

        second_offset_x = -0.4
        second_offset_y = 0.15
        second_amplitude = 0.25
        AdaptiveOpticsSim.Backends.launch_kernel!(
            KA_CPU_STYLE,
            AdaptiveOpticsSim.Atmospheres.atmosphere_direction_layer_batch_kernel!,
            batch_output,
            screen,
            batch_shift_x,
            batch_shift_y,
            batch_scale,
            batch_pupil,
            second_offset_x,
            second_offset_y,
            second_amplitude,
            2,
            4,
            10,
            2,
            false;
            ndrange=size(batch_output),
        )
        @inbounds for direction in axes(batch_expected, 3)
            expected_slice = @view batch_expected[:, :, direction]
            AdaptiveOpticsSim.Atmospheres.accumulate_shifted_screen!(
                expected_slice,
                screen,
                second_offset_x - batch_shift_x[2, direction],
                second_offset_y - batch_shift_y[2, direction],
                second_amplitude,
                batch_scale[2, direction],
            )
            expected_slice .*= batch_pupil
        end
        mark_ka_cpu_kernel!(:atmosphere_direction_layer_batch_kernel!)
        @test ka_cpu_close(batch_output, batch_expected)
        @test all(iszero, @view batch_output[1, 1, :])
        @test all(iszero, @view batch_output[4, 3, :])

        scalar_sub = zeros(Float64, 8, 8)
        ka_sub = zeros(Float64, 8, 8)
        AdaptiveOpticsSim.Atmospheres._add_subharmonics!(SCALAR_CPU_STYLE, scalar_sub, 0.15, 25.0, 0.2, 1e-10;
            rng=MersenneTwister(2), n_levels=1, radius=1)
        AdaptiveOpticsSim.Atmospheres._add_subharmonics!(KA_CPU_STYLE, ka_sub, 0.15, 25.0, 0.2, 1e-10;
            rng=MersenneTwister(2), n_levels=1, radius=1)
        mark_ka_cpu_kernel!(:add_subharmonics_kernel!)
        @test ka_cpu_close(ka_sub, scalar_sub; rtol=1e-10, atol=1e-10)
    end

    @testset "Optics kernels" begin
        tel = Telescope(resolution=8, diameter=8.0, central_obstruction=0.0)
        src = Source(band=:I, magnitude=0.0)
        wavefront = PupilFunction(tel)
        scalar_ef = ElectricField(wavefront, src; zero_padding=2)
        ka_ef = ElectricField(wavefront, src; zero_padding=2)
        formation = prepare_pupil_field(wavefront, src, scalar_ef)
        AdaptiveOpticsSim.Optics._fill_electric_field!(SCALAR_CPU_STYLE,
            scalar_ef, wavefront, formation)
        AdaptiveOpticsSim.Optics._fill_electric_field!(KA_CPU_STYLE, ka_ef,
            wavefront, formation)
        mark_ka_cpu_kernel!(:fill_pupil_field_kernel!)
        @test ka_cpu_close(ka_ef.values, scalar_ef.values)
        scalar_field = copy(scalar_ef.values)
        opd = reshape(collect(range(0.0, 1e-8; length=64)), 8, 8)
        phase = reshape(collect(range(0.0, 0.1; length=64)), 8, 8)
        amp = reshape(collect(range(0.9, 1.1; length=64)), 8, 8)
        AdaptiveOpticsSim.Optics._apply_phase!(SCALAR_CPU_STYLE, scalar_ef, opd,
            :opd, formation)
        AdaptiveOpticsSim.Optics._apply_phase!(KA_CPU_STYLE, ka_ef, opd, :opd,
            formation)
        mark_ka_cpu_kernel!(:apply_phase_opd_kernel!)
        @test ka_cpu_close(ka_ef.values, scalar_ef.values)
        AdaptiveOpticsSim.Optics._apply_phase!(SCALAR_CPU_STYLE, scalar_ef, phase,
            :phase, formation)
        AdaptiveOpticsSim.Optics._apply_phase!(KA_CPU_STYLE, ka_ef, phase, :phase,
            formation)
        mark_ka_cpu_kernel!(:apply_phase_rad_kernel!)
        @test ka_cpu_close(ka_ef.values, scalar_ef.values)
        AdaptiveOpticsSim.Optics._apply_amplitude!(SCALAR_CPU_STYLE, scalar_ef,
            amp, formation)
        AdaptiveOpticsSim.Optics._apply_amplitude!(KA_CPU_STYLE, ka_ef, amp,
            formation)
        mark_ka_cpu_kernel!(:apply_amplitude_kernel!)
        @test ka_cpu_close(ka_ef.values, scalar_ef.values)

        scalar_intensity = similar(scalar_ef.values, Float64)
        ka_intensity = similar(ka_ef.values, Float64)
        AdaptiveOpticsSim.Optics._intensity!(SCALAR_CPU_STYLE, scalar_intensity,
            scalar_ef.values)
        AdaptiveOpticsSim.Optics._intensity!(KA_CPU_STYLE, ka_intensity,
            ka_ef.values)
        mark_ka_cpu_kernel!(:intensity_kernel!)
        @test ka_cpu_close(ka_intensity, scalar_intensity)

        batch_field = reshape(
            ComplexF64.(collect(1:48), collect(49:96)),
            4,
            4,
            3,
        )
        batch_shifts_axis1 = [0, 9, -10]
        batch_shifts_axis2 = [0, -9, 10]
        scalar_batch_intensity = zeros(Float64, 4, 4, 3)
        ka_batch_intensity = similar(scalar_batch_intensity)
        batch_scale = inv(16.0)
        @inbounds for sample in axes(batch_field, 3),
            j in axes(batch_field, 2), i in axes(batch_field, 1)
            source_i = mod(
                i - batch_shifts_axis1[sample] - 1,
                size(batch_field, 1),
            ) + 1
            source_j = mod(
                j - batch_shifts_axis2[sample] - 1,
                size(batch_field, 2),
            ) + 1
            scalar_batch_intensity[i, j, sample] =
                abs2(batch_field[source_i, source_j, sample]) *
                batch_scale
        end
        batch_kernel = AdaptiveOpticsSim.Optics.direct_imaging_batch_intensity_kernel!(
            KA_CPU_STYLE.backend,
        )
        batch_kernel(
            ka_batch_intensity,
            batch_field,
            batch_shifts_axis1,
            batch_shifts_axis2,
            batch_scale,
            4,
            4,
            3;
            ndrange=size(batch_field),
        )
        KernelAbstractions.synchronize(KA_CPU_STYLE.backend)
        mark_ka_cpu_kernel!(:direct_imaging_batch_intensity_kernel!)
        @test ka_batch_intensity == scalar_batch_intensity

        AdaptiveOpticsSim.Optics._accumulate_intensity!(SCALAR_CPU_STYLE,
            scalar_intensity, scalar_ef.values)
        AdaptiveOpticsSim.Optics._accumulate_intensity!(KA_CPU_STYLE,
            ka_intensity, ka_ef.values)
        mark_ka_cpu_kernel!(:accumulate_abs2_kernel!)
        @test ka_cpu_close(ka_intensity, scalar_intensity)

        scalar_centered = copy(scalar_field)
        ka_centered = copy(scalar_field)
        AdaptiveOpticsSim.Optics.apply_centering_phase!(SCALAR_CPU_STYLE, scalar_centered, 0.2)
        AdaptiveOpticsSim.Optics.apply_centering_phase!(KA_CPU_STYLE, ka_centered, 0.2)
        mark_ka_cpu_kernel!(:apply_centering_phase_kernel!)
        @test ka_cpu_close(ka_centered, scalar_centered)

        input = reshape(ComplexF64.(collect(1:16), collect(17:32)), 4, 4)
        scalar_copy = similar(input)
        ka_copy = similar(input)
        AdaptiveOpticsSim.Optics._complex_scale_copy!(SCALAR_CPU_STYLE, scalar_copy, input, 0.25)
        AdaptiveOpticsSim.Optics._complex_scale_copy!(KA_CPU_STYLE, ka_copy, input, 0.25)
        mark_ka_cpu_kernel!(:complex_scale_copy_kernel!)
        @test ka_copy == scalar_copy
        weights = fill(2.0 + 0.5im, 4, 4)
        AdaptiveOpticsSim.Optics._complex_hadamard!(SCALAR_CPU_STYLE, scalar_copy, weights)
        AdaptiveOpticsSim.Optics._complex_hadamard!(KA_CPU_STYLE, ka_copy, weights)
        mark_ka_cpu_kernel!(:complex_hadamard_kernel!)
        @test ka_copy == scalar_copy

        freqs = collect(range(0.0, 1.0; length=4))
        scalar_transfer = similar(input)
        ka_transfer = similar(input)
        AdaptiveOpticsSim.Optics.build_fresnel_transfer!(SCALAR_CPU_STYLE, scalar_transfer, freqs, -0.1)
        AdaptiveOpticsSim.Optics.build_fresnel_transfer!(KA_CPU_STYLE, ka_transfer, freqs, -0.1)
        mark_ka_cpu_kernel!(:fresnel_transfer_kernel!)
        @test ka_cpu_close(ka_transfer, scalar_transfer)

        pupil = trues(4, 4)
        pupil[1, 2] = false
        basis = reshape(collect(range(0.0, 1.0; length=32)), 4, 4, 2)
        coeffs = [0.25, -0.5]
        scalar_opd = Matrix{Float64}(undef, 4, 4)
        ka_opd = similar(scalar_opd)
        AdaptiveOpticsSim.Calibration._combine_basis!(
            SCALAR_CPU_STYLE, scalar_opd, basis, coeffs, pupil)
        AdaptiveOpticsSim.Calibration._combine_basis!(
            KA_CPU_STYLE, ka_opd, basis, coeffs, pupil)
        mark_ka_cpu_kernel!(:combine_basis_kernel!)
        @test ka_cpu_close(ka_opd, scalar_opd)

        AdaptiveOpticsSim.Calibration._combine_basis_async!(
            KA_CPU_STYLE, ka_opd, basis, coeffs, pupil)
        Backends.synchronize_backend!(KA_CPU_STYLE)
        @test ka_cpu_close(ka_opd, scalar_opd)
        @test AlgorithmGraphs._modal_opd_expansion_capture_capability(KA_CPU_STYLE) isa
            AlgorithmGraphs.GraphNodeCaptureUnsupported
        cancelling_basis = ones(Float64, 4, 4, 2)
        for coefficients in ([1.0, -1.0], [NaN, 0.0], [Inf, 0.0])
            AdaptiveOpticsSim.Calibration._combine_basis_async!(
                KA_CPU_STYLE, ka_opd, cancelling_basis, coefficients, pupil)
            Backends.synchronize_backend!(KA_CPU_STYLE)
            @test all(iszero, ka_opd[.!pupil])
            if all(isfinite, coefficients)
                @test all(iszero, ka_opd)
            else
                @test all(!isfinite, ka_opd[pupil])
            end
        end

        fill!(ka_opd, 1.0)
        empty_basis = Array{Float64}(undef, 4, 4, 0)
        AdaptiveOpticsSim.Calibration._combine_basis!(
            KA_CPU_STYLE, ka_opd, empty_basis, Float64[], pupil)
        @test all(iszero, ka_opd)
        fill!(ka_opd, 1.0)
        AdaptiveOpticsSim.Calibration._combine_basis_async!(
            KA_CPU_STYLE, ka_opd, empty_basis, Float64[], pupil)
        Backends.synchronize_backend!(KA_CPU_STYLE)
        @test all(iszero, ka_opd)

        WavefrontSensors.lift_basis_expansion!(
            SCALAR_CPU_STYLE, scalar_opd, basis, coeffs, pupil)
        WavefrontSensors.lift_basis_expansion!(
            KA_CPU_STYLE, ka_opd, basis, coeffs, pupil)
        mark_ka_cpu_kernel!(:lift_basis_expansion_kernel!)
        @test ka_cpu_close(ka_opd, scalar_opd)

        dm_scalar = DeformableMirror(tel; n_act=3, influence_width=0.3)
        dm_ka = DeformableMirror(tel; n_act=3, influence_width=0.3)
        scalar_modes = Matrix{Float64}(undef, size(dm_scalar.state.modes))
        ka_modes = similar(scalar_modes)
        AdaptiveOpticsSim.Optics._materialize_gaussian_influence!(
            SCALAR_CPU_STYLE, scalar_modes, dm_scalar.state.modes)
        AdaptiveOpticsSim.Optics._materialize_gaussian_influence!(
            KA_CPU_STYLE, ka_modes, dm_ka.state.modes)
        mark_ka_cpu_kernel!(:dm_materialize_gaussian_kernel!)
        @test ka_cpu_close(ka_modes, scalar_modes)

        dm_scalar.state.coefs .= collect(range(-0.1, 0.1; length=length(dm_scalar.state.coefs)))
        dm_ka.state.coefs .= dm_scalar.state.coefs
        AdaptiveOpticsSim.Optics.prepare_actuator_commands!(dm_scalar)
        AdaptiveOpticsSim.Optics.prepare_actuator_commands!(dm_ka)
        AdaptiveOpticsSim.Optics._apply_opd_separable!(
            SCALAR_CPU_STYLE, dm_scalar)
        AdaptiveOpticsSim.Optics._apply_opd_separable!(KA_CPU_STYLE, dm_ka)
        mark_ka_cpu_kernel!(:dm_apply_pupil_kernel!)
        @test ka_cpu_close(dm_ka.state.opd, dm_scalar.state.opd)

        fill!(dm_ka.state.opd, NaN)
        AdaptiveOpticsSim.Optics._apply_opd_separable_async!(
            KA_CPU_STYLE,
            dm_ka,
        )
        Backends.synchronize_backend!(KA_CPU_STYLE)
        mark_ka_cpu_kernel!(
            :dm_separable_left_kernel!,
            :dm_separable_right_pupil_kernel!,
        )
        @test ka_cpu_close(dm_ka.state.opd, dm_scalar.state.opd)

    end

    @testset "Detector kernels" begin
        frame = reshape(collect(1.0:25.0), 5, 5)
        scratch = similar(frame)
        scalar_frame = copy(frame)
        ka_frame = copy(frame)
        scalar_scratch = similar(frame)
        ka_scratch = similar(frame)
        gaussian = GaussianPixelResponse(response_width_px=0.5)
        AdaptiveOpticsSim.Detectors.apply_response!(SCALAR_CPU_STYLE, gaussian, scalar_frame, scalar_scratch)
        AdaptiveOpticsSim.Detectors.apply_response!(KA_CPU_STYLE, gaussian, ka_frame, ka_scratch)
        mark_ka_cpu_kernel!(:separable_response_rows_kernel!, :separable_response_cols_kernel!)
        @test ka_cpu_close(ka_frame, scalar_frame)

        sampled = SampledFrameResponse([0.0 0.1 0.0; 0.1 0.6 0.1; 0.0 0.1 0.0])
        scalar_frame .= frame
        ka_frame .= frame
        AdaptiveOpticsSim.Detectors.apply_response!(SCALAR_CPU_STYLE, sampled, scalar_frame, scalar_scratch)
        AdaptiveOpticsSim.Detectors.apply_response!(KA_CPU_STYLE, sampled, ka_frame, ka_scratch)
        mark_ka_cpu_kernel!(:sampled_response_kernel!)
        @test ka_cpu_close(ka_frame, scalar_frame)

        asymmetric = SampledFrameResponse(
            [0.0 0.0 0.0; 0.1 0.2 0.7; 0.0 0.0 0.0])
        fill!(scalar_frame, 0.0)
        fill!(ka_frame, 0.0)
        scalar_frame[3, end] = 1.0
        ka_frame[3, end] = 1.0
        AdaptiveOpticsSim.Detectors.apply_response!(SCALAR_CPU_STYLE, asymmetric,
            scalar_frame, scalar_scratch)
        AdaptiveOpticsSim.Detectors.apply_response!(KA_CPU_STYLE, asymmetric, ka_frame,
            ka_scratch)
        @test ka_cpu_close(ka_frame, scalar_frame)
        @test sum(ka_frame) ≈ 0.3

        ramp_cube = Array{Float64}(undef, 5, 5, 5)
        for read_idx in axes(ramp_cube, 3)
            @views ramp_cube[:, :, read_idx] .=
                ((read_idx - 1) / (size(ramp_cube, 3) - 1)) .* frame
        end
        scalar_ramp_integrated = similar(frame)
        scalar_ramp_slope = similar(frame)
        scalar_ramp_intercept = similar(frame)
        ka_ramp_integrated = similar(frame)
        ka_ramp_slope = similar(frame)
        ka_ramp_intercept = similar(frame)
        AdaptiveOpticsSim.Detectors._fit_up_the_ramp!(SCALAR_CPU_STYLE,
            scalar_ramp_integrated, scalar_ramp_slope,
            scalar_ramp_intercept, ramp_cube, 2.0)
        AdaptiveOpticsSim.Detectors._fit_up_the_ramp!(KA_CPU_STYLE,
            ka_ramp_integrated, ka_ramp_slope, ka_ramp_intercept,
            ramp_cube, 2.0)
        mark_ka_cpu_kernel!(:fit_up_the_ramp_kernel!)
        @test ka_cpu_close(ka_ramp_integrated, scalar_ramp_integrated)
        @test ka_cpu_close(ka_ramp_slope, scalar_ramp_slope)
        @test ka_cpu_close(ka_ramp_intercept, scalar_ramp_intercept)
        @test ka_cpu_close(ka_ramp_integrated, frame)
        @test ka_cpu_close(ka_ramp_slope, frame ./ 2)
        @test ka_cpu_close(ka_ramp_intercept, zeros(5, 5))

        full_frame = reshape(collect(1.0:30.0), 5, 6)
        window = AdaptiveOpticsSim.Detectors.FrameWindow(2:4, 3:5)
        scalar_windowed_frame = zeros(3, 3)
        ka_windowed_frame = similar(scalar_windowed_frame)
        AdaptiveOpticsSim.Detectors._copy_windowed_frame!(
            SCALAR_CPU_STYLE, scalar_windowed_frame, full_frame, window)
        AdaptiveOpticsSim.Detectors._copy_windowed_frame!(
            KA_CPU_STYLE, ka_windowed_frame, full_frame, window)
        mark_ka_cpu_kernel!(:copy_windowed_frame_kernel!)
        @test ka_windowed_frame == scalar_windowed_frame == full_frame[2:4, 3:5]

        full_cube = reshape(collect(1.0:90.0), 5, 6, 3)
        scalar_windowed_cube = zeros(3, 3, 3)
        ka_windowed_cube = similar(scalar_windowed_cube)
        AdaptiveOpticsSim.Detectors._copy_windowed_cube!(
            SCALAR_CPU_STYLE, scalar_windowed_cube, full_cube, window)
        AdaptiveOpticsSim.Detectors._copy_windowed_cube!(
            KA_CPU_STYLE, ka_windowed_cube, full_cube, window)
        mark_ka_cpu_kernel!(:copy_windowed_cube_kernel!)
        @test ka_windowed_cube == scalar_windowed_cube == full_cube[2:4, 3:5, :]

        scalar_sampling_cube = zeros(5, 6, 2)
        ka_sampling_cube = zeros(5, 6, 2)
        AdaptiveOpticsSim.Detectors._copy_sampling_plane!(
            SCALAR_CPU_STYLE, scalar_sampling_cube, 2, full_cube, 3)
        AdaptiveOpticsSim.Detectors._copy_sampling_plane!(
            KA_CPU_STYLE, ka_sampling_cube, 2, full_cube, 3)
        mark_ka_cpu_kernel!(:copy_sampling_plane_kernel!)
        @test ka_sampling_cube == scalar_sampling_cube
        @test ka_sampling_cube[:, :, 2] == full_cube[:, :, 3]

        scalar_windowed_sampling_cube = zeros(3, 3, 2)
        ka_windowed_sampling_cube = zeros(3, 3, 2)
        AdaptiveOpticsSim.Detectors._copy_windowed_sampling_plane!(
            SCALAR_CPU_STYLE, scalar_windowed_sampling_cube, 2,
            full_cube, 3, window)
        AdaptiveOpticsSim.Detectors._copy_windowed_sampling_plane!(
            KA_CPU_STYLE, ka_windowed_sampling_cube, 2,
            full_cube, 3, window)
        @test ka_windowed_sampling_cube == scalar_windowed_sampling_cube
        @test ka_windowed_sampling_cube[:, :, 2] ==
            full_cube[window.rows, window.cols, 3]

        cube = reshape(collect(1.0:50.0), 2, 5, 5)
        scalar_cube = copy(cube)
        ka_cube = copy(cube)
        scalar_cube_scratch = similar(cube)
        ka_cube_scratch = similar(cube)
        AdaptiveOpticsSim.Detectors._batched_apply_response!(SCALAR_CPU_STYLE, gaussian, scalar_cube, scalar_cube_scratch)
        AdaptiveOpticsSim.Detectors._batched_apply_response!(KA_CPU_STYLE, gaussian, ka_cube, ka_cube_scratch)
        mark_ka_cpu_kernel!(:separable_response_stack_rows_kernel!, :separable_response_stack_cols_kernel!)
        @test ka_cpu_close(ka_cube, scalar_cube)

        scalar_cube .= cube
        ka_cube .= cube
        AdaptiveOpticsSim.Detectors._batched_apply_response!(SCALAR_CPU_STYLE, sampled, scalar_cube, scalar_cube_scratch)
        AdaptiveOpticsSim.Detectors._batched_apply_response!(KA_CPU_STYLE, sampled, ka_cube, ka_cube_scratch)
        mark_ka_cpu_kernel!(:sampled_response_stack_kernel!)
        @test ka_cpu_close(ka_cube, scalar_cube)

        fill!(scalar_cube, 0.0)
        fill!(ka_cube, 0.0)
        scalar_cube[1, 3, end] = 1.0
        scalar_cube[2, 3, 1] = 1.0
        ka_cube .= scalar_cube
        AdaptiveOpticsSim.Detectors._batched_apply_response!(SCALAR_CPU_STYLE,
            asymmetric, scalar_cube, scalar_cube_scratch)
        AdaptiveOpticsSim.Detectors._batched_apply_response!(KA_CPU_STYLE, asymmetric,
            ka_cube, ka_cube_scratch)
        @test ka_cpu_close(ka_cube, scalar_cube)
        @test sum(@view(ka_cube[1, :, :])) ≈ 0.3
        @test sum(@view(ka_cube[2, :, :])) ≈ 0.9

        noise = reshape(collect(range(-0.2, 0.2; length=25)), 5, 5)
        scalar_frame .= frame
        ka_frame .= frame
        AdaptiveOpticsSim.Detectors.apply_column_noise!(SCALAR_CPU_STYLE, scalar_frame, noise, 0.5)
        AdaptiveOpticsSim.Detectors.apply_column_noise!(KA_CPU_STYLE, ka_frame, noise, 0.5)
        mark_ka_cpu_kernel!(:add_column_noise_kernel!)
        @test ka_cpu_close(ka_frame, scalar_frame)

        scalar_frame .= frame
        ka_frame .= frame
        AdaptiveOpticsSim.Detectors.apply_row_noise!(SCALAR_CPU_STYLE, scalar_frame,
            noise, 0.5)
        AdaptiveOpticsSim.Detectors.apply_row_noise!(KA_CPU_STYLE, ka_frame, noise, 0.5)
        mark_ka_cpu_kernel!(:add_row_noise_kernel!)
        @test ka_cpu_close(ka_frame, scalar_frame)

        output_model = StaticCMOSOutputPattern(2, [1.0, 1.1, 1.2], [0.0, 0.5, 1.0])
        scalar_frame .= frame
        ka_frame .= frame
        AdaptiveOpticsSim.Detectors.apply_output_model!(SCALAR_CPU_STYLE, output_model, scalar_frame)
        AdaptiveOpticsSim.Detectors.apply_output_model!(KA_CPU_STYLE, output_model, ka_frame)
        mark_ka_cpu_kernel!(:apply_cmos_output_pattern_kernel!)
        @test ka_cpu_close(ka_frame, scalar_frame)

        counting_input = zeros(5, 5)
        counting_input[3, 3] = 10.0
        scalar_counting = similar(counting_input)
        ka_counting = similar(counting_input)
        AdaptiveOpticsSim.Detectors._apply_nearest_neighbor_count_redistribution!(
            SCALAR_CPU_STYLE, scalar_counting, counting_input, 0.4)
        AdaptiveOpticsSim.Detectors._apply_nearest_neighbor_count_redistribution!(
            KA_CPU_STYLE, ka_counting, counting_input, 0.4)
        mark_ka_cpu_kernel!(:nearest_neighbor_count_redistribution_kernel!)
        @test ka_cpu_close(ka_counting, scalar_counting)
        @test sum(ka_counting) ≈ sum(counting_input)

        for model in (
            ReferencePixelCommonModeCorrection(1, 1),
            ReferenceRowCommonModeCorrection(1),
            ReferenceColumnCommonModeCorrection(1),
            ReferenceOutputCommonModeCorrection(3; edge_rows=1, edge_cols=1),
        )
            scalar_cube .= cube
            ka_cube .= cube
            fill!(scalar_cube_scratch, 0.0)
            fill!(ka_cube_scratch, 0.0)
            AdaptiveOpticsSim.Detectors._batched_apply_readout_correction!(SCALAR_CPU_STYLE, model, scalar_cube, scalar_cube_scratch)
            AdaptiveOpticsSim.Detectors._batched_apply_readout_correction!(KA_CPU_STYLE, model, ka_cube, ka_cube_scratch)
            @test ka_cpu_close(ka_cube, scalar_cube)
        end
        mark_ka_cpu_kernel!(
            :reference_pixel_bias_kernel!,
            :reference_row_bias_kernel!,
            :subtract_row_bias_kernel!,
            :reference_column_bias_kernel!,
            :subtract_column_bias_kernel!,
            :reference_output_bias_kernel!,
            :subtract_output_bias_kernel!,
        )
    end

    @testset "Pyramid kernels" begin
        tel = Telescope(resolution=16, diameter=8.0, central_obstruction=0.0)
        wfs = PyramidWFS(tel; pupil_samples=4, modulation=2.0, modulation_points=3)
        propagation = WavefrontSensors.pyramid_propagation_workspace(wfs)
        @test propagation.modulation_batch isa
            WavefrontSensors.NoPyramidModulationBatchWorkspace

        scalar_phasor = similar(propagation.phasor)
        ka_phasor = similar(propagation.phasor)
        WavefrontSensors._build_pyramid_phasor!(SCALAR_CPU_STYLE, scalar_phasor)
        WavefrontSensors._build_pyramid_phasor!(KA_CPU_STYLE, ka_phasor)
        mark_ka_cpu_kernel!(:pyramid_phasor_kernel!)
        @test ka_cpu_close(ka_phasor, scalar_phasor)

        pupil = PupilFunction(tel)
        build_pyramid_mask!(wfs, pupil)
        @test @allocated(build_pyramid_mask!(wfs, pupil)) == 0

        for policy in (NoModulation(),
                CircularModulation(0.7; samples=4, phase_offset_rad=0.31),
                SampledModulation(((1.3, 0.7, 0), (-0.4, 1.1, 2),
                    (-0.9, -0.5, 1))))
            scalar = Optics.prepare_focal_plane_modulation(
                policy, 8, zeros(8, 8), Float64)
            generated = similar(scalar.phases)
            Optics._prepare_modulation_phases!(KA_CPU_STYLE, generated,
                policy, Float64)
            @test ka_cpu_close(generated, scalar.phases)
            separable = Optics.prepare_separable_focal_plane_modulation(
                policy, 8, zeros(8, 8), Float64)
            Optics._prepare_separable_modulation_factors!(KA_CPU_STYLE,
                separable.axis_1_factors, separable.axis_2_factors,
                policy, Float64)
            points = length(separable.amplitude_weights)
            reconstructed = reshape(separable.axis_1_factors, 8, 1, points) .*
                reshape(separable.axis_2_factors, 1, 8, points)
            @test ka_cpu_close(reconstructed, scalar.phases)
        end
        mark_ka_cpu_kernel!(:sampled_modulation_phases_kernel!,
            :sampled_separable_modulation_factors_kernel!)

        modulation_policy = CircularModulation(2.0;
            samples=5, phase_offset_rad=0.3)
        scalar_modulation =
            AdaptiveOpticsSim.Optics.prepare_focal_plane_modulation(
                modulation_policy, 8, zeros(8, 8), Float64)
        ka_modulation =
            AdaptiveOpticsSim.Optics.prepare_focal_plane_modulation(
                modulation_policy, 8, zeros(8, 8), Float64)
        AdaptiveOpticsSim.Optics._update_cycle_averaged_circular_modulation!(
            SCALAR_CPU_STYLE, scalar_modulation, 1.5, 0.3)
        AdaptiveOpticsSim.Optics._update_cycle_averaged_circular_modulation!(
            KA_CPU_STYLE, ka_modulation, 1.5, 0.3)
        mark_ka_cpu_kernel!(:circular_modulation_phases_kernel!)
        @test ka_cpu_close(
            ka_modulation.phases, scalar_modulation.phases)
        separable_modulation = Optics.prepare_separable_focal_plane_modulation(
            modulation_policy, 8, zeros(8, 8), Float64)
        Optics._update_cycle_averaged_circular_modulation!(KA_CPU_STYLE,
            separable_modulation, 1.5, 0.3)
        mark_ka_cpu_kernel!(:circular_separable_modulation_factors_kernel!)
        reconstructed = reshape(separable_modulation.axis_1_factors, 8, 1, 5) .*
            reshape(separable_modulation.axis_2_factors, 1, 8, 5)
        @test ka_cpu_close(reconstructed, scalar_modulation.phases)

        @testset "Cached pupil phase and reused mask $T" for T in (Float32, Float64)
            resolution = 5
            opd = [T(35e-9) * (T(i - 3) + T(0.4) * T(j - 3))
                for i in 1:resolution, j in 1:resolution]
            phase = fill(Complex{T}(T(NaN), T(NaN)), resolution, resolution)
            phase_address = pointer(phase)
            opd_to_cycles = T(2) / T(0.75e-6)
            rtol = T === Float32 ? T(3e-5) : T(2e-12)
            atol = T === Float32 ? T(1e-6) : T(1e-13)
            for scale in (one(T), T(-0.6))
                current_opd = scale .* opd
                Backends.launch_kernel!(KA_CPU_STYLE,
                    WavefrontSensors.pyramid_pupil_phase_kernel!,
                    phase, current_opd, opd_to_cycles, resolution;
                    ndrange=(resolution + 2, resolution + 2))
                expected = [cispi(opd_to_cycles * current_opd[i, j])
                    for i in 1:resolution, j in 1:resolution]
                @test phase ≈ expected rtol=rtol atol=atol
                @test pointer(phase) == phase_address
            end
            mask = [cis(T(0.3) * T(i - 1) - T(0.2) * T(j - 1))
                for i in 1:resolution, j in 1:resolution]
            for batch_size in (1, 2, 4)
                # Keep an inactive slice to ensure the two-dimensional launch
                # visits exactly the requested number of modulation points.
                stack = [Complex{T}(T(i + 2j + b) / T(7), T(i - j - b) / T(5))
                    for i in 1:resolution, j in 1:resolution, b in 1:(batch_size + 1)]
                expected = copy(stack)
                for b in 1:batch_size, j in 1:resolution, i in 1:resolution
                    expected[i, j, b] *= mask[i, j]
                end
                Backends.launch_kernel!(KA_CPU_STYLE,
                    WavefrontSensors.pyramid_modulation_batch_mask_kernel!,
                    stack, mask, resolution, batch_size;
                    ndrange=(resolution + 2, resolution + 2))
                @test stack ≈ expected rtol=rtol atol=atol
                @test stack[:, :, end] == expected[:, :, end]
            end
        end
        mark_ka_cpu_kernel!(:pyramid_pupil_phase_kernel!,
            :pyramid_modulation_batch_mask_kernel!)

    end

    @testset "Bi-O-edge kernels" begin
        tel = Telescope(resolution=16, diameter=8.0, central_obstruction=0.0)
        wfs = BiOEdgeWFS(tel; pupil_samples=4)
        propagation = WavefrontSensors.bi_o_edge_propagation_workspace(wfs)

        scalar_phasor = similar(propagation.phasor)
        ka_phasor = similar(propagation.phasor)
        WavefrontSensors._build_bi_o_edge_phasor!(SCALAR_CPU_STYLE, scalar_phasor)
        WavefrontSensors._build_bi_o_edge_phasor!(KA_CPU_STYLE, ka_phasor)
        mark_ka_cpu_kernel!(:bi_o_edge_phasor_kernel!)
        @test ka_cpu_close(ka_phasor, scalar_phasor)

        scalar_masks = similar(propagation.bi_o_edge_masks)
        ka_masks = similar(propagation.bi_o_edge_masks)
        WavefrontSensors._build_bi_o_edge_masks!(SCALAR_CPU_STYLE, scalar_masks, Float64)
        WavefrontSensors._build_bi_o_edge_masks!(KA_CPU_STYLE, ka_masks, Float64)
        mark_ka_cpu_kernel!(:bi_o_edge_masks_kernel!)
        @test ka_cpu_close(ka_masks, scalar_masks)

    end

    @testset "Elongation kernel" begin
        intensity = reshape(collect(range(0.0, 1.0; length=64)), 8, 8)
        scalar_intensity = copy(intensity)
        ka_intensity = copy(intensity)
        scalar_tmp = similar(intensity)
        ka_tmp = similar(intensity)
        scalar_kernel = Vector{Float64}(undef, 1)
        ka_kernel = similar(scalar_kernel)
        WavefrontSensors._apply_elongation!(SCALAR_CPU_STYLE, scalar_intensity, scalar_tmp,
            WavefrontSensors.apply_elongation!(scalar_intensity, 1.6, scalar_tmp, scalar_kernel), 1, 8, 8)
        ka_kernel = WavefrontSensors.apply_elongation!(ka_intensity, 1.6, ka_tmp, ka_kernel)
        scalar_baseline = copy(scalar_intensity)
        ka_probe = copy(intensity)
        ka_tmp2 = similar(ka_probe)
        WavefrontSensors._apply_elongation!(KA_CPU_STYLE, ka_probe, ka_tmp2, ka_kernel, 1, 8, 8)
        copyto!(ka_probe, ka_tmp2)
        mark_ka_cpu_kernel!(:elongation_apply_kernel!)
        @test ka_cpu_close(ka_probe, scalar_baseline)

        intensity_stack = reshape(collect(range(0.0, 1.0; length=128)), 2, 8, 8)
        scalar_stack = copy(intensity_stack)
        ka_stack = copy(intensity_stack)
        scalar_stack_tmp = similar(intensity_stack)
        ka_stack_tmp = similar(intensity_stack)
        WavefrontSensors._apply_elongation_stack!(SCALAR_CPU_STYLE, scalar_stack, scalar_stack_tmp, ka_kernel, 1, 2, 8, 8)
        WavefrontSensors._apply_elongation_stack!(KA_CPU_STYLE, ka_stack, ka_stack_tmp, ka_kernel, 1, 2, 8, 8)
        copyto!(scalar_stack, scalar_stack_tmp)
        copyto!(ka_stack, ka_stack_tmp)
        mark_ka_cpu_kernel!(:elongation_apply_stack_kernel!)
        @test ka_cpu_close(ka_stack, scalar_stack)

        n = 8
        expected = reshape(collect(range(0.25, 2.0; length=n * n)), n, n)
        expected_lgs_stack = cat(expected, reverse(expected; dims=2); dims=3)
        identity_kernel_fft = ones(ComplexF64, n, n, 2)
        scalar_lgs_stack = copy(expected_lgs_stack)
        scalar_lgs_buffer = zeros(ComplexF64, n, n, 2)
        scalar_fft_plan = AdaptiveOpticsSim.Backends.plan_fft_backend!(scalar_lgs_buffer, (1, 2))
        scalar_ifft_plan = AdaptiveOpticsSim.Backends.plan_ifft_backend!(scalar_lgs_buffer, (1, 2))
        WavefrontSensors._apply_lgs_convolution_stack!(SCALAR_CPU_STYLE,
            scalar_lgs_stack, identity_kernel_fft, scalar_lgs_buffer,
            scalar_fft_plan, scalar_ifft_plan)

        ka_lgs_stack = copy(expected_lgs_stack)
        ka_lgs_buffer = zeros(ComplexF64, n, n, 2)
        ka_fft_plan = AdaptiveOpticsSim.Backends.plan_fft_backend!(ka_lgs_buffer, (1, 2))
        ka_ifft_plan = AdaptiveOpticsSim.Backends.plan_ifft_backend!(ka_lgs_buffer, (1, 2))
        WavefrontSensors._apply_lgs_convolution_stack!(KA_CPU_STYLE,
            ka_lgs_stack, identity_kernel_fft, ka_lgs_buffer,
            ka_fft_plan, ka_ifft_plan)
        mark_ka_cpu_kernel!(
            :real_to_complex_stack_kernel!,
            :multiply_kernel_fft_stack_kernel!,
            :complex_to_real_stack_kernel!,
        )
        @test ka_cpu_close(ka_lgs_stack, scalar_lgs_stack)
        @test ka_cpu_close(ka_lgs_stack, expected_lgs_stack)
        @test ka_cpu_close(vec(sum(ka_lgs_stack; dims=(1, 2))),
            vec(sum(expected_lgs_stack; dims=(1, 2))))
    end

    @testset "KA CPU kernel inventory" begin
        # Deferred kernels are still accounted for: most require larger
        # end-to-end wfs/tomography fixtures. Accelerator-only publication,
        # scatter, and modulation-batch paths are covered by the optional
        # backend suites; atomic kernels are not portable to the KA CPU Array
        # backend on Julia 1.12.
        deferred = Set([
            # Scalar/KA-CPU parity is exercised by detector-pixel-mtf.
            :_pixel_mtf_pad_kernel!,
            :_pixel_mtf_multiply_kernel!,
            :_pixel_mtf_crop_kernel!,
            :_add_enqueued_detector_scratch_kernel!,
            :_clamp_enqueued_detector_frame_kernel!,
            :_count_nonfinite_graph_values_kernel!,
            :_fill_enqueued_detector_scratch_kernel!,
            :_multiply_enqueued_emccd_frame_kernel!,
            :_prepare_enqueued_detector_frame_kernel!,
            :_quantize_enqueued_detector_frame_kernel!,
            :_scatter_grid_dm_command_kernel!,
            :_scale_enqueued_detector_frame_kernel!,
            :_write_enqueued_detector_integer_output_kernel!,
            :advance_moving_screen_replay_kernel!,
            :apply_atmosphere_pupil_kernel!,
            :curvature_abs2_stack_kernel!,
            :curvature_branch_field_from_input_kernel!,
            :curvature_branch_field_stack_kernel!,
            :curvature_channel_pack_kernel!,
            :curvature_frame_pack_kernel!,
            :curvature_phasor_kernel!,
            :curvature_sample_branch_kernel!,
            :diagonal_matrix_kernel!,
            :dm_apply_gaussian_operator_kernel!,
            :fit_source_average_kernel!,
            :gather_stencil_data_kernel!,
            :inject_column_negative_kernel!,
            :inject_column_positive_kernel!,
            :inject_row_negative_kernel!,
            :inject_row_positive_kernel!,
            :masked_sum2d_kernel!,
            :moving_layer_replay_kernel!,
            :pyramid_electric_field_modulation_batch_kernel!,
            :pyramid_modulation_batch_intensity_kernel!,
            :pyramid_pupil_modulation_batch_kernel!,
            :zernike_phasor_kernel!,
        ])
        all_kernels = source_kernel_names()
        classified = union(KA_CPU_EXERCISED_KERNELS, deferred)
        @test isempty(setdiff(KA_CPU_EXERCISED_KERNELS, all_kernels))
        @test isempty(setdiff(deferred, all_kernels))
        @test isempty(intersect(KA_CPU_EXERCISED_KERNELS, deferred))
        @test isempty(setdiff(all_kernels, classified))
        @test length(KA_CPU_EXERCISED_KERNELS) >= 40
    end

    @testset "Locally generated physical-frame fixture agreement" begin
        # Retired OOPAO slopes and the SPECULA index-grid characterization are
        # not detector-plane frame references.  Generate a local physical-frame
        # fixture instead, then compare the scalar and KA-CPU physical stages.
        root = mktempdir()
        create_reference_fixture(root)
        bundle = load_reference_bundle(root)
        cases = filter(case -> case.id == "shack_hartmann_frame",
            bundle.cases)
        @test length(cases) == 1
        case = only(cases)
        expected = load_reference_array(case)
        scalar_actual = adapt_reference_actual(case,
            compute_reference_actual(case))
        ka_actual = adapt_reference_actual(case,
            compute_reference_actual_ka_cpu(case))
        @test isapprox(scalar_actual, expected; atol=case.atol, rtol=case.rtol)
        @test isapprox(ka_actual, expected; atol=case.atol, rtol=case.rtol)
        @test ka_cpu_close(ka_actual, scalar_actual; atol=case.atol,
            rtol=case.rtol)
    end
end
