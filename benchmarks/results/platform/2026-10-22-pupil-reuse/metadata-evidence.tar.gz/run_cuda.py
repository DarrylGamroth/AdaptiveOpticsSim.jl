from pathlib import Path
import subprocess,os,json,sys
r=Path(__file__).parent;repo=r.parent/'AdaptiveOpticsSim-pupil-profile'
env=os.environ|{'OPENBLAS_NUM_THREADS':'1','JULIA_NUM_THREADS':'1'}
start=sys.argv[1] if len(sys.argv)>1 else None
active=start is None
base=['taskset','-c','2','julia','--startup-file=no','--threads=1']
def run(label,project,script,args=[],extra={}):
 global active
 if not active:
  if label!=start:return
  active=True
 cmd=base+['--project='+str(project),str(script)]+list(map(str,args))
 with (r/'commands.jsonl').open('a') as f:f.write(json.dumps({'label':label,'command':cmd,'extra':extra})+'\n')
 print('START',label,flush=True)
 with (r/(label+'.log')).open('w') as f:subprocess.run(cmd,env=env|extra,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',label,flush=True)
for name in ('modulation_batches','modulation_storage','modulation_batch_policy'):
 run(name,r/'env',repo/('test/cuda/'+name+'.jl'))
for case in ('copper_fast','gpi_default','copper_default','gpi_fine','copper_fine'):
 run('after-'+case,r/'env',repo/'benchmarks/profile_physical_pyramid_cuda.jl',[r/('after-'+case+'.toml'),case])
for case in ('copper_fast','gpi_fine','copper_fine'):
 for storage in ('dense','computed'):
  label=storage+'-'+case
  run(label,r/'env',repo/'benchmarks/compare_pupil_storage_cuda.jl',[r/(label+'.toml'),case],{'AOS_PUPIL_STORAGE':storage})
run('copper-after',r/'copper-env',repo/'benchmarks/validate_modulation_batches_copper_cuda.jl',[r.parent/'REVOLTCopperSim-pupil-tilt',r/'copper-after',r.parent/'aos-pupil-tilt-evidence/copper-before'])
run('external-after',r/'env',repo/'benchmarks/oopao_modulation_batches/aos.jl',[r.parent/'aos-batch-oracle'],{'AOS_ORACLE_BACKEND':'cuda','AOS_ORACLE_PRECISION':'Float32','AOS_ORACLE_CASES':'n120_p30_m3','AOS_ORACLE_PREFIX':'cuda_f32_pupil_reuse'})
run('gpi-package',r/'env',r.parent/'GPI2Sim-pupil-tilt/test/cuda/runtests.jl')
run('gpi-complete',r/'env',r.parent/'GPI2Sim-pupil-tilt/benchmarks/test_gpi_closed_loop_cuda.jl')
run('gpi-after',r/'env',r.parent/'GPI2Sim-pupil-tilt/benchmarks/gpi_closed_loop_cuda.jl',[r/'gpi-after'],{'GPI_LOOP_CASES':'default,fine,transfer'})
