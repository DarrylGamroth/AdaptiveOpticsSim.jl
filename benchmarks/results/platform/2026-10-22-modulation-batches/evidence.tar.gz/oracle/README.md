# External pyramid reference, 2026-10-22

Observed comparison of freshly executed local OOPAO at commit 085d5e50ace0d20fe13cc2da20129d5400166973 against AOS CPU physical pupil tilt. See comparison.json for AOS commit and all numerical metrics. The AOS worktree had three untracked batch investigation files (benchmarks/modulation_batch_override.jl, benchmarks/sweep_modulation_batches_cuda.jl, test/cuda/modulation_batches.jl). This experiment changed no AOS source.

Commands, from the AOS workspace:

```sh
/home/dgamroth/workspaces/codex/aos-batch-oracle/venv/bin/python /home/dgamroth/workspaces/codex/aos-batch-oracle/oracle.py > /home/dgamroth/workspaces/codex/aos-batch-oracle/run.log 2>&1
JULIA_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 julia --project=/home/dgamroth/workspaces/codex/aos-batch-evidence/env /home/dgamroth/workspaces/codex/aos-batch-oracle/aos.jl > /home/dgamroth/workspaces/codex/aos-batch-oracle/aos-batches.log 2>&1
/home/dgamroth/workspaces/codex/aos-batch-oracle/venv/bin/python /home/dgamroth/workspaces/codex/aos-batch-oracle/summarize.py
```

Julia 1.13.2. Python packages in python-packages.txt. CPU only, one Julia/FFT/BLAS thread. OOPAO uses its NumPy CPU implementation; GPU was unavailable to the isolated environment.

Both cases use D=8m, unobstructed pupil, I band magnitude 0 (790nm), 1ms exposure, psfCentering=true, n_pix_edge=0. Small case: N=24, pupil_samples=4, modulation=1 λ/D, 8 modulation points, separation=4, binning=2. General case: N=32, pupil_samples=8, modulation=3 λ/D, 20 points, separation=8, binning=1. AOS diffraction_padding=2 default. Detector frames are respectively 6×6 and 24×24; raw optical images 72×72 and 96×96.

Ramps are OPD(i,j)=5nm i−2nm j, with zero-based indices. Tip mode is first-index coordinate linspace(−1,1,N,endpoint=false) times pupil. Central differences use ±1nm OPD and divide frame difference by 2nm; units photons/metre. AOS optical rate is multiplied by .001 seconds to match OOPAO per-frame photons. Text files preserve row/column orientation; no axis transpose, fit, tolerance adjustment, flux correction or image registration was used. Normalized metrics divide each engine's result by that engine's flat frame photon count.

Observed image and finite-difference agreement is within 4.5×10⁻⁸ relative L2 for both cases. The ~1.8×10⁻⁸ OOPAO flat flux deficit is consistent with its explicit float32 phase-buffer path and mixed precision FFT calculations; AOS conserves supplied source photon count within Float64 rounding. This mixed precision explanation is a source-based attribution, not an isolated precision experiment.

This validates the physical pupil-tilt oracle and photon/calibration image conventions only. It does not establish equivalence or acceptability of the shifted-mask approximation; compare that strategy explicitly against these saved physical-reference arrays. No GPU claim is made. OOPAO slope arrays are also saved for possible subsequent signal-processing comparisons, but this experiment's calibrated quantity is the detector image finite-difference response.

The portable scripts accept an optional reference/output directory as first argument or via AOS_ORACLE_OUTPUT. oracle.py takes OOPAO_PATH. aos.jl takes AOS_ORACLE_BACKEND=cpu|cuda, optional AOS_ORACLE_BATCH, optional AOS_ORACLE_BATCH_OVERRIDE, and optional AOS_ORACLE_PREFIX; its prepared optical rate is Float64 on either backend. CPU baseline uses prefix aos; CUDA uses aos_cuda_bN with N the requested batch (0 means default policy). AOS_ORACLE_CASES selects comma-separated n24_p4_m1,n32_p8_m3, useful when the requested batch does not divide both cases' modulation point counts. summarize.py takes the same cases selector plus AOS_ORACLE_PREFIX and optional AOS_CHECKOUT for commit provenance. CUDA execution is left to the coordinating agent; this extension was rerun only on CPU (aos-batches-direct.log).

Third reference added: N=120, pupil_samples=30, modulation=3 λ/D, 32 points, separation=2, edge=1, binning=1. OOPAO independently produced raw256×256 and detector64×64. Both engines executed on CPU affinity4; commands as above with `taskset -c 4` and AOS_ORACLE_CASES=n120_p30_m3. Float64 relative L2 flat/ramp/tip-response errors: 8.963×10⁻⁹, 9.778×10⁻⁹, 4.131×10⁻⁸; flux conservation agrees to Float64 rounding. See run-256.log and aos-256-f64.log.

AOS_ORACLE_PRECISION=Float32 selects Float32 preparation and OPD input, default remains Float64. The automatic prefix gains _f32; explicit AOS_ORACLE_PREFIX is used verbatim. CPU Float32 was also executed for all three cases (aos-all-f32.log; comparison_aos_f32.json). Flat/ramp relative L2 errors are 1.7×10⁻⁶–8.1×10⁻⁶; ±1nm tip-response errors are 5.6×10⁻⁵–8.6×10⁻⁵. These quantify finite precision sensitivity and cannot be treated as Float64 equivalence. No tolerances were modified. No CUDA execution was performed by this worker.

## External slope observable check

CPU-only `taskset -c 4 venv/bin/python slope_comparison.py` constructs the same external OOPAO sensor and processes saved AOS CUDA frames through OOPAO's exact slopesMaps conventions. `signalProcessing(cameraFrame=...)` ignores its argument for quadrant extraction, so the script assigns wfs.cam.frame explicitly. The tip response uses the analytic quotient Jacobian d(S/N)=dS/N−S dN/N² with the external sensor's quadrant extraction, valid masks, normalization and slopesUnits. This Jacobian applied to saved OOPAO image differences matches its saved finite-difference slope response to 9.96×10⁻⁹ relative L2; applying OOPAO directly to the saved ramp reproduces its saved slopes exactly.

For the selected CUDA Float32 physical pupil-tilt result, ramp slope error is 1.812×10⁻⁶ and tip slope response error is 5.263×10⁻⁵. For selected shifted masks, ramp slope error is 18.9623% and tip slope response error is 17.4349%. Projected tip gain is 0.8462307 (15.377% lower than the physical reference), alignment cosine is 0.9953182, and the component orthogonal to the reference has relative norm 8.21749%. Baseline shifted masks give essentially the same errors. This establishes a discrepancy in a slope observable, beyond the 27.8458% detector-image tip response error. It does not establish residual wavefront error or closed-loop behavior; only one tip direction and one specified ramp are covered. Exact metrics and provenance are in slope-comparison.json; source in slope_comparison.py.

OOPAO checkout provenance is not pristine HEAD: status records modified precision_oopao.npy plus untracked AGENTS.md, Containerfile, docs/ and environment.yml. OOPAO/__init__.py unconditionally saves precision=64 on import, so reference execution rewrites that file. Its value and SHA256, plus hashes of relevant external source files, are recorded in slope-comparison.json. Whether the precision file was modified before the worker's first import was not recorded. Existing files were not restored.
