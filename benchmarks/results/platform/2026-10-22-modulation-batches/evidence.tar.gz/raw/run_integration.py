import subprocess, os, json, time
from pathlib import Path
root=Path('/home/dgamroth/workspaces/codex'); evidence=root/'aos-batch-evidence'; aos=root/'AdaptiveOpticsSim-batches'
env=os.environ.copy();env.update(JULIA_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
def run(label,project,script,args=(),extra=None):
 e=env.copy();e.update(extra or {})
 cmd=['taskset','-c','2','julia','--startup-file=no','--project='+str(evidence/project),str(script),*map(str,args)]
 with (evidence/'commands.jsonl').open('a') as f:f.write(json.dumps(dict(label=label,command=cmd,extra=extra,time=time.time()))+'\n')
 print('START',label,flush=True)
 with (evidence/(label+'.log')).open('w') as f:subprocess.run(cmd,env=e,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',label,flush=True)
run('copper-before','copper-base-env',aos/'benchmarks/validate_modulation_batches_copper_cuda.jl',[root/'REVOLTCopperSim.jl',evidence/'copper-before'])
run('gpi-before','gpi-base-env',root/'GPI2Sim.jl/benchmarks/gpi_closed_loop_cuda.jl',[evidence/'gpi-before'],dict(GPI_LOOP_CASES='default'))
for batch in (0,1,2,4):
 extra=dict(AOS_ORACLE_BACKEND='cuda')
 if batch: extra['AOS_ORACLE_BATCH']=str(batch)
 run('oracle-cuda-'+str(batch),'env',root/'aos-batch-oracle/aos.jl',[root/'aos-batch-oracle'],extra)
run('copper-after','copper-env',aos/'benchmarks/validate_modulation_batches_copper_cuda.jl',[root/'REVOLTCopperSim.jl',evidence/'copper-after',evidence/'copper-before'])
run('gpi-after','env',root/'GPI2Sim.jl/benchmarks/gpi_closed_loop_cuda.jl',[evidence/'gpi-after'],dict(GPI_LOOP_CASES='default'))
