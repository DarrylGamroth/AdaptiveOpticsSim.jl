from pathlib import Path
import json
import numpy as np

# Reconstruct source conventions for the existing n120 / pupil30 / pad256 fixture.
n, p, sep, pad = 120, 30, 2, 256
coord = np.linspace(-np.pi, np.pi, n)
theta = -np.pi*(1-1/pad) + np.arange(pad)*2*np.pi/pad
rnorm = (p+sep)*n/(2*p)
x = np.arange(n)-(n-1)/2
a = ((x[:,None]**2+x[None,:]**2) <= (n/2)**2).astype(float)
opd = 40e-9*(np.sin(2*np.pi*np.arange(n)[:,None]/n)+.4*np.cos(2*np.pi*np.arange(n)[None,:]/n))
u = a*np.exp(2j*np.pi*opd/.75e-6)
o = (pad-n)//2
phasor = np.exp(-1j*np.pi*(pad+1)/pad*(np.arange(pad)[:,None]+np.arange(pad)[None,:]))
base = np.zeros((pad,pad),complex);base[o:o+n,o:o+n]=u;base*=phasor
mask = np.exp(-1j*rnorm*(abs(theta[:,None])+abs(theta[None,:])))
focal=np.fft.fft2(base)
records=[]
for delta in [0, .25, .5, 1, 1.5, 2, 3, 6]:
    modulation = delta*(n-1)/pad
    tilted=base.copy();tilted[o:o+n,o:o+n]*=np.exp(1j*modulation*coord)[None,:]
    exact=abs(np.fft.ifft2(mask*np.fft.fft2(tilted)))**2
    analytic_mask=np.exp(-1j*rnorm*(abs(theta[:,None])+abs(theta[None,:]+2*np.pi*delta/pad)))
    approximate=abs(np.fft.ifft2(analytic_mask*focal))**2
    rec={'delta_bins':delta,'modulation_lambda_over_D':modulation,'analytic_shift_relative_l2':float(np.linalg.norm(approximate-exact)/np.linalg.norm(exact))}
    if float(delta).is_integer():
        periodic=abs(np.fft.ifft2(np.roll(mask,-int(delta),axis=1)*focal))**2
        rec['periodic_shift_relative_l2']=float(np.linalg.norm(periodic-exact)/np.linalg.norm(exact))
        assert rec['periodic_shift_relative_l2']<1e-12
    records.append(rec)

# Exact finite-DFT conjugated mask is non-diagonal for a fractional bin shift.
N=32
F=np.fft.fft(np.eye(N),axis=0)/np.sqrt(N)
M=np.diag(np.exp(-3j*abs(-np.pi*(1-1/N)+np.arange(N)*2*np.pi/N)))
operator=[]
for delta in [0, .25, .5, 1, 1.5, 2]:
    D=np.diag(np.exp(2j*np.pi*delta*np.arange(N)/N))
    S=F@D@F.conj().T
    effective=S.conj().T@M@S
    off=effective-np.diag(np.diag(effective))
    operator.append({'delta_bins':delta,'off_diagonal_relative_frobenius':float(np.linalg.norm(off)/np.linalg.norm(effective))})
report={'scope':'Independent CPU reconstruction of current FFT/tilt/analytic-mask equations; not full package detector sampling','fixture':{'pupil_resolution':n,'pupil_samples':p,'separation':sep,'padded_side':pad},'intensity':records,'effective_operator':operator}
path=Path(__file__).with_suffix('.json');path.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
