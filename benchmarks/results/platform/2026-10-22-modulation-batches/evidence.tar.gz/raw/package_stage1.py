from pathlib import Path
import hashlib, json, os, shutil, tarfile
root=Path('/home/dgamroth/workspaces/codex/aos-batch-evidence')
stage=root.parent/'aos-batch-package'
assert not stage.exists()
stage.mkdir()
raw=stage/'raw';raw.mkdir()
for p in root.iterdir():
 if p.is_file() and p.suffix in {'.json','.jsonl','.toml','.txt','.log','.py','.md'}:
  shutil.copy2(p,raw/p.name)
for name in ['env','copper-env','copper-base-env','gpi-base-env','copper-before','copper-after','gpi-before','gpi-after','sweep-source','source-before-removal']:
 shutil.copytree(root/name,raw/name)
oracle=Path('/home/dgamroth/workspaces/codex/aos-batch-oracle')
dst=stage/'oracle';dst.mkdir()
for p in oracle.iterdir():
 if p.is_file() and p.suffix in {'.json','.txt','.log','.py','.jl','.md'}:
  shutil.copy2(p,dst/p.name)
 if p.is_dir() and p.name.startswith('n'):
  shutil.copytree(p,dst/p.name)
seen={};index=[]
for p in sorted(stage.rglob('*')):
 if not p.is_file():continue
 h=hashlib.sha256(p.read_bytes()).hexdigest();key=(p.stat().st_size,h)
 index.append(h+'  '+str(p.relative_to(stage)))
 if key in seen:
  p.unlink();os.link(seen[key],p)
 else: seen[key]=p
(stage/'SHA256SUMS').write_text('\n'.join(index)+'\n')
output=Path('/home/dgamroth/workspaces/codex/AdaptiveOpticsSim-batches/benchmarks/results/platform/2026-10-22-modulation-batches/evidence.tar.gz')
with tarfile.open(output,'w:gz',compresslevel=6) as tf:
 for p in sorted(stage.iterdir()):tf.add(p,arcname=p.name)
print('archive bytes',output.stat().st_size,'files',len(index))
