import subprocess, os, json, time
from pathlib import Path
root=Path('/home/dgamroth/workspaces/codex'); evidence=root/'aos-batch-evidence'; aos=root/'AdaptiveOpticsSim-batches'
env=os.environ.copy();env.update(JULIA_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
def run(label,project,script,args=(),extra=None):
 e=env.copy();e.update(extra or {})
 cmd=['taskset','-c','2','julia','--startup-file=no','--project='+str(evidence/project),str(script),*map(str,args)]
 with (evidence/'commands.jsonl').open('a') as f:f.write(json.dumps(dict(label=label,command=cmd,extra=extra,time=time.time()))+'\n')
 print('START',label,flush=True)
 with (evidence/(label+'.log')).open('w') as f:subprocess.run(cmd,env=e,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',label,flush=True)
run('policy-tests','env',aos/'test/cuda/modulation_batch_policy.jl')
run('storage-regression','env',aos/'test/cuda/modulation_storage.jl')
for trial in (1,2):
 run('policy-timing-'+str(trial),'env',aos/'benchmarks/sweep_modulation_batches_cuda.jl',[evidence/('policy-timing-'+str(trial)+'.toml'),'small,medium,wide,gpi,copper,many,large,pow256,pow512,pow512short,pow768,nonpow,odd24,odd30,prime31,edge560,edge576'],dict(AOS_BATCH_ROUNDS='3',AOS_BATCH_SAMPLES='64',AOS_BATCH_POLICY_ONLY='1',AOS_BATCH_COMPARE_POLICY='1'))
for strategy in ('pupil_tilt','shifted_mask'):
 for policy in ('baseline','selected'):
  prefix='cuda_f32_'+strategy+'_'+policy
  extra=dict(AOS_ORACLE_BACKEND='cuda',AOS_ORACLE_PRECISION='Float32',AOS_ORACLE_CASES='n120_p30_m3',AOS_ORACLE_PREFIX=prefix,AOS_ORACLE_STRATEGY=strategy)
  if policy=='baseline': extra['AOS_ORACLE_BATCH']='32'
  run('oracle-'+prefix,'env',aos/'benchmarks/oopao_modulation_batches/aos.jl',[root/'aos-batch-oracle'],extra)
