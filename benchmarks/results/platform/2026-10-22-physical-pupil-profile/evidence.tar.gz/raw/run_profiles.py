from pathlib import Path
import subprocess,os,json,time
r=Path('/home/dgamroth/workspaces/codex/aos-physical-profile-evidence');repo=r.parent/'AdaptiveOpticsSim-pupil-profile'
cases=['copper_fast','gpi_default','copper_default','gpi_fine','copper_fine']
env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',JULIA_NUM_THREADS='1')
base=['taskset','-c','2','julia','--startup-file=no','--threads=1','--project='+str(r/'env'),str(repo/'benchmarks/profile_physical_pyramid_cuda.jl')]
def run(label,cmd,extra={}):
 e=env|extra
 with (r/'commands.jsonl').open('a') as f:f.write(json.dumps({'label':label,'command':cmd,'extra':extra})+'\n')
 print('START',label,flush=True)
 with (r/(label+'.log')).open('w') as f:subprocess.run(cmd,env=e,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',label,flush=True)
for c in cases:run('baseline-'+c,base+[str(r/('baseline-'+c+'.toml')),c])
for c in cases:
 cmd=['nsys','profile','--trace=cuda','--sample=none','--cpuctxsw=none','--cuda-graph-trace=node','--capture-range=cudaProfilerApi','--capture-range-end=stop','--force-overwrite=true','--output='+str(r/c)]+base+[str(r/('traced-'+c+'.toml')),c]
 run('trace-'+c,cmd,{'AOS_PROFILE_EXTERNAL':'1'})
 run('stats-'+c,['nsys','stats','--report=cuda_gpu_kern_sum,cuda_gpu_mem_time_sum,cuda_api_sum','--format=csv',str(r/(c+'.nsys-rep'))])
