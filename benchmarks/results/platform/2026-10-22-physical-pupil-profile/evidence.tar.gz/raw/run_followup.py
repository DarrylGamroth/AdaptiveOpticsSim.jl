from pathlib import Path
import subprocess,os,time,json
r=Path(__file__).parent
while Path('/proc/1336771').exists():time.sleep(1)
print('Initial campaign ended; starting serialized follow-up',flush=True)
env=os.environ|{'OPENBLAS_NUM_THREADS':'1','JULIA_NUM_THREADS':'1'}
repo=r.parent/'AdaptiveOpticsSim-pupil-profile'
base=['taskset','-c','2','julia','--startup-file=no','--threads=1','--project='+str(r/'env')]
cmd=base+[str(repo/'benchmarks/sweep_fine_pyramid_batches_cuda.jl'),str(r/'fine-batches.toml')]
with (r/'commands.jsonl').open('a') as f:f.write(json.dumps({'label':'fine-batches','command':cmd,'extra':{}})+'\n')
with (r/'fine-batches.log').open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
print('Fine batch sweep completed',flush=True)
cmd=['/usr/local/cuda-13.4/bin/ncu','--set','basic','--clock-control','none','--cache-control','none','--profile-from-start','off','--kernel-name','regex:gpu_pyramid_pupil_modulation_batch_kernel_.*','--launch-count','1','--force-overwrite','--export',str(r/'pupil-fill-counters')]+base+[str(repo/'benchmarks/profile_physical_pyramid_cuda.jl'),str(r/'counter-copper_fast.toml'),'copper_fast']
extra={'AOS_PROFILE_EXTERNAL':'1','AOS_PROFILE_WARMUPS':'1','AOS_PROFILE_SAMPLES':'1','AOS_PROFILE_REPLAYS':'1'}
with (r/'commands.jsonl').open('a') as f:f.write(json.dumps({'label':'ncu-pupil-fill','command':cmd,'extra':extra})+'\n')
with (r/'ncu-pupil-fill.log').open('w') as f:res=subprocess.run(cmd,env=env|extra,stdout=f,stderr=subprocess.STDOUT)
print('Counter attempt exited',res.returncode,flush=True)
