from pathlib import Path
import sqlite3,json,tomllib
r=Path(__file__).parent
result={}
for p in r.glob('*.sqlite'):
 c=sqlite3.connect(p);c.row_factory=sqlite3.Row
 names={row['id']:row['value'] for row in c.execute('select id,value from StringIds')}
 kernels=[dict(row) for row in c.execute('select * from CUPTI_ACTIVITY_KIND_KERNEL')]
 if not kernels:continue
 groups={}; resources={}
 def category(name):
  if 'pupil_modulation_batch' in name:return 'pupil_fill'
  if 'modulation_batch_mask' in name:return 'mask'
  if 'modulation_batch_intensity' in name:return 'intensity'
  if 'bin2d' in name:return 'binning'
  if not name.startswith('gpu_'):return 'fft'
  return 'other'
 for k in kernels:
  name=names[k['shortName']];g=category(name)
  groups[g]=groups.get(g,0)+(k['end']-k['start'])
  resources[name]={key:k[key] for key in ['blockX','blockY','blockZ','registersPerThread','staticSharedMemory','dynamicSharedMemory','localMemoryPerThread','gridX','gridY','gridZ']}
 intervals=[(k['start'],k['end']) for k in kernels]
 tables={row['name'] for row in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
 memops={}
 for table in ('CUPTI_ACTIVITY_KIND_MEMSET','CUPTI_ACTIVITY_KIND_MEMCPY'):
  if table in tables:
   rows=list(c.execute('select start,end from '+table));intervals.extend((row['start'],row['end']) for row in rows)
   memops[table]={'count':len(rows),'total_ns':sum(row['end']-row['start'] for row in rows)}
 intervals.sort();merged=[]
 for start,end in intervals:
  if merged and start<=merged[-1][1]:merged[-1][1]=max(merged[-1][1],end)
  else:merged.append([start,end])
 span=intervals[-1][1]-intervals[0][0];busy=sum(end-start for start,end in merged)
 total=sum(groups.values())
 case={'kernel_count':len(kernels),'kernel_time_ns':total,'categories_ns':groups,'categories_percent':{k:v*100/total for k,v in groups.items()},'profile_span_ns':span,'device_active_fraction_in_span':busy/span,'memops':memops,'launch_resources':resources}
 base=r/('baseline-'+p.stem+'.toml')
 if base.exists():
  d=tomllib.loads(base.read_text());case['baseline']={k:d[k] for k in ['case','median_ms','p95_ms','minimum_ms','maximum_ms','batch','padded_side','phase_bytes','field_stack_bytes','host_allocated_bytes','samples_ms']}
 result[p.stem]=case
(r/'profile-summary.json').write_text(json.dumps(result,indent=2)+'\n')
for name,c in result.items():print(name,round(c['baseline']['median_ms'],3),c['baseline']['batch'],{k:round(v,1) for k,v in c['categories_percent'].items()},'active',round(c['device_active_fraction_in_span']*100,2))
