from pathlib import Path
import subprocess,os,time,json,tomllib,shutil
r=Path(__file__).resolve().parent;repo=r.parent/'AdaptiveOpticsSim-fft-layout'
env=os.environ|{'JULIA_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'}
pid=subprocess.check_output(['pgrep','-f','^/home/dgamroth/.julia/.*/julia .*validate_fine_fft_gpi_cuda.jl'],text=True).strip()
while Path('/proc/'+pid).exists():time.sleep(2)
assert tomllib.loads((r/'gpi-after/validation.toml').read_text())['complete']
def run(label,cmd,extra={}):
 print('START',label,flush=True)
 with (r/'commands.jsonl').open('a') as f:f.write(json.dumps({'label':label,'command':cmd,'extra':extra})+'\n')
 with (r/(label+'.log')).open('w') as f:subprocess.run(cmd,cwd=repo,env=env|extra,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',label,flush=True)
run('cuda-policy-final',['taskset','-c','2','julia','--startup-file=no','--threads=1','--project='+str(r/'env'),str(repo/'test/cuda/modulation_batch_policy.jl')])
run('integration-comparison',['taskset','-c','4','python3',str(repo/'benchmarks/compare_fft_validation.py'),str(r.parent/'aos-pupil-reuse-evidence'),str(r),str(r/'integration-comparison.json')])
run('scientific-replay',['taskset','-c','4','python3',str(r.parent/'GPI2Sim-pupil-tilt/benchmarks/results/2026-10-21-gpi-complete-capture/verify_scientific_metrics.py')],{'GPI_VERIFY_DIR':str(r/'gpi-after'),'GPI_VERIFY_REPO':str(r.parent/'GPI2Sim-pupil-tilt'),'GPI_VERIFY_BASIS':'/tmp/gpi-basis-oracle.f32'})
shutil.copy2('/tmp/gpi-independent-review-gpi-after.json',r/'scientific-replay.json')
