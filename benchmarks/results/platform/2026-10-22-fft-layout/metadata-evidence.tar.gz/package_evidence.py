from pathlib import Path
import subprocess,shutil,hashlib,json,tarfile,os
r=Path(__file__).resolve().parent
repo=r.parent/'AdaptiveOpticsSim-fft-layout'
out=repo/'benchmarks/results/platform/2026-10-22-fft-layout'
os.sched_setaffinity(0,{4})
patch=subprocess.check_output(['git','diff','--','src','ext'],cwd=repo)
assert hashlib.sha256(patch).hexdigest()=='8ef1c3abaf072b243926a2328728c8b8462438987d5206a136a22c8c4be1fed2'
assert (r/'review.md').exists() and (r/'integration-comparison.json').exists()
assert json.loads((r/'integration-comparison.json').read_text())['passed']
assert json.loads((r/'scientific-replay.json').read_text())['complete']
assert (r/'normal-sampling-check.json').exists()
(r/'production.patch').write_bytes(patch)
paths=subprocess.check_output(['git','ls-files','--modified','--others','--exclude-standard'],cwd=repo,text=True).splitlines()
for name in paths:
 if name.startswith('benchmarks/results/') or '__pycache__' in name:continue
 p=repo/name
 if p.is_file():
  q=r/'source-final'/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
for owner,worktree in (('gpi','GPI2Sim-pupil-tilt'),('copper','REVOLTCopperSim-pupil-tilt')):
 for p in (r.parent/worktree/'benchmarks').glob('*.jl'):
  q=r/'source-final'/owner/'benchmarks'/p.name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
for name in ('validate_modulation_batches_copper_cuda.jl',):
 q=r/'source-final'/'benchmarks'/name;shutil.copy2(repo/'benchmarks'/name,q)
for p,name in ((r.parent/'GPI2Sim-pupil-tilt/benchmarks/results/2026-10-21-gpi-complete-capture/verify_scientific_metrics.py','verify_scientific_metrics.py'),(Path('/tmp/gpi-reconstruct-basis.jl'),'gpi-reconstruct-basis.jl')):
 shutil.copy2(p,r/'source-final'/name)
for name in ('layout-summary.json','production-summary.json','integration-comparison.json','scientific-replay.json','normal-sampling-check.json','review.md'):
 shutil.copy2(r/name,out/name)
files=sorted(p for p in r.rglob('*') if p.is_file() and p.suffix!='.sqlite' and '__pycache__' not in p.parts and p.name!='package.log')
groups={'gpi':[],'copper':[],'profiling':[],'metadata':[]}
for p in files:
 rel=p.relative_to(r)
 key='gpi' if rel.parts[0]=='gpi-after' else 'copper' if rel.parts[0] in ('copper-before','copper-after') else 'profiling' if p.suffix=='.nsys-rep' else 'metadata'
 groups[key].append(p)
index={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(out/'raw-sha256.json').write_text(json.dumps(index,indent=2,sort_keys=True)+'\n')
for key,items in groups.items():
 dest=out/(key+'-evidence.tar.gz')
 with tarfile.open(dest,'w:gz',compresslevel=6) as t:
  for p in items:t.add(p,arcname=str(p.relative_to(r)),recursive=False)
 assert dest.stat().st_size<100*1024*1024,(key,dest.stat().st_size)
 with tarfile.open(dest,'r:gz') as t:
  for m in t.getmembers():assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==index[m.name],m.name
 print(key,len(items),dest.stat().st_size,flush=True)
print('Verified',len(index),'archived file hashes')
