# julia --project=ISOLATED_ENV --startup-file=no HARNESS EMPTY_OUTPUT_DIRECTORY
# Full camera photon-rate responses; no RTC slopes, reconstruction, or calibration.
include("gpi_actuation_cuda.jl")
using Dates

const CONVERGENCE_CASES = ((240, 24), (240, 96), (480, 96), (720, 96), (720, 192))
const RESPONSE_FAMILIES = ("woofer", "tweeter_illuminated", "tweeter_obscured", "tip", "tilt")

function convergence_source(mod)
    record = source_record(mod)
    root = record["path"]
    paths = sort([joinpath(directory, file) for folder in ("src", "ext")
        if isdir(joinpath(root, folder)) for (directory, _, files) in walkdir(joinpath(root, folder))
        for file in files if endswith(file, ".jl")])
    record["version"] = string(pkgversion(mod))
    record["src_ext_sha256"] = bytes2hex(sha256(join((relpath(path, root) * "\0" *
        bytes2hex(sha256(read(path))) for path in paths), "\n")))
    return record
end

function convergence_pool()
    record = Dict{String,Any}()
    for name in (:used_memory, :cached_memory)
        if isdefined(CUDA, name)
            try
                record[string(name) * "_bytes"] = Int(getproperty(CUDA, name)())
            catch exception
                record[string(name) * "_unavailable"] = sprint(showerror, exception)
            end
        end
    end
    return record
end

function rate_checks(rate, baseline_flux)
    @assert size(rate) == (240, 240) && eltype(rate) === Float32
    @assert all(isfinite, rate) && all(>=(0), rate)
    total = sum(Float64, rate)
    relative = abs(total - baseline_flux) / baseline_flux
    @assert relative <= 3e-5
    return Dict("total_photons_per_s" => total, "relative_flux_change_from_flat" => relative,
        "flux_invariance_rtol" => 3e-5, "minimum" => minimum(rate), "maximum" => maximum(rate),
        "l2_photons_per_s" => norm(Float64.(rate)), "finite_nonnegative" => true)
end

function response_comparison(actual, expected)
    raw = Dict(name => merge(errors(actual[name], Float64.(expected[name])),
        Dict("actual_l2" => norm(Float64.(actual[name])),
            "reference_l2" => norm(Float64.(expected[name])),
            "actual_total_photons_per_s" => sum(Float64, actual[name]),
            "reference_total_photons_per_s" => sum(Float64, expected[name]))) for (name, _) in probes())
    central = Dict{String,Any}()
    commands = Dict(probes())
    for family in RESPONSE_FAMILIES
        positive, negative = family * "_positive", family * "_negative"
        amplitude = Float64(maximum(abs, commands[positive]))
        measured = (Float64.(actual[positive]) - Float64.(actual[negative])) ./ (2 * amplitude)
        reference = (Float64.(expected[positive]) - Float64.(expected[negative])) ./ (2 * amplitude)
        central[family] = merge(errors(measured, reference),
            Dict("actual_l2" => norm(measured), "reference_l2" => norm(reference),
                "actual_max_abs" => maximum(abs, measured),
                "reference_max_abs" => maximum(abs, reference), "command_amplitude_m" => amplitude,
                "units" => "photons per second per metre OPD coefficient"))
    end
    return Dict("raw_rate_images" => raw, "paired_central_differences" => central,
        "central_difference_formula" => "(rate(+a) - rate(-a)) / (2a)",
        "comparison_gated" => false,
        "interpretation" => "Numerical differences only. Small or zero reference response does not establish a physical observability bound.")
end

function convergence_case!(directory, record, target, resolution, points)
    label = "N$(resolution)_M$(points)"
    destination = joinpath(directory, label)
    mkpath(destination)
    result = Dict{String,Any}("status" => "preparing", "pupil_resolution" => resolution,
        "modulation_points" => points, "camera_shape" => [240, 240],
        "propagation_strategy" => "PyramidPupilTiltStrategy",
        "artifact_directory" => relpath(destination, directory),
        "pool_before_preparation" => convergence_pool())
    record["cases"][label] = result
    save_record(directory, record)
    p = GPI2Parameters(pupil_resolution=resolution, modulation_points=points, noise=false)
    result["parameters"] = Dict(string(name) => (isnothing(getfield(p, name)) ? "nothing" :
        getfield(p, name) isa Tuple ? collect(getfield(p, name)) : getfield(p, name))
        for name in fieldnames(typeof(p)))
    preparation_start = time_ns()
    system = prepare_calibration_system(; parameters=p, target, execution=CapturedGraphExecution())
    CUDA.synchronize()
    result["preparation_ns"] = Int(time_ns() - preparation_start)
    result["pool_after_preparation"] = convergence_pool()
    result["captured_node_count"] = captured_graph_node_count(system.graph)
    @assert result["captured_node_count"] == 10
    prepared = AG.prepared_graph_node(system.graph, :pyramid).prepared
    @assert prepared.plan.propagation.modulation_propagation_strategy isa
        AdaptiveOpticsSim.WavefrontSensors.PyramidPupilTiltStrategy
    graph = system.graph
    command = graph_input(graph, :command)
    fill!(command, 0f0)
    CUDA.synchronize()
    for _ in 1:8
        step_graph!(graph)
    end
    samples = Vector{Int}(undef, 32)
    for index in eachindex(samples)
        start = time_ns()
        step_graph!(graph)
        samples[index] = Int(time_ns() - start)
    end
    result["graph_service_ns"] = Dict("samples" => samples, "median" => median(samples),
        "p95" => quantile(samples, 0.95), "maximum" => maximum(samples),
        "warmup_steps" => 8, "completed_measured_steps" => 32)
    result["status"] = "probes"
    result["probes"] = Dict{String,Any}()
    save_record(directory, record)
    rates = Dict{String,Matrix{Float32}}()
    flat_flux = 0.0
    for (name, values_) in probes()
        copyto!(command, values_)
        CUDA.synchronize() # Host-to-device command staging is outside graph timing.
        step_graph!(graph)
        rate = Array(graph_output(graph, :photon_rate))
        name == "flat" && (flat_flux = sum(Float64, rate))
        @assert flat_flux > 0
        entry = Dict{String,Any}("command" => save_array(destination, name * "-command", values_),
            "photon_rate" => save_array(destination, name * "-rate", rate),
            "checks" => rate_checks(rate, flat_flux))
        rates[name] = rate
        result["probes"][name] = entry
        save_record(directory, record)
        println(label, " saved optical probe ", name)
        flush(stdout)
    end
    result["pool_after_replay"] = convergence_pool()
    result["status"] = "complete"
    save_record(directory, record)
    return rates
end

function convergence_main(args)
    length(args) == 1 || error("usage: gpi_sensor_convergence_cuda.jl EMPTY_OUTPUT_DIRECTORY")
    directory = abspath(only(args))
    mkpath(directory)
    isempty(readdir(directory)) || error("output directory must be empty")
    CUDA.functional() || error("functional CUDA required")
    CUDA.allowscalar(false)
    BLAS.set_num_threads(1)
    B.set_fft_provider_threads!(1)
    project = Base.active_project()
    manifests = filter(path -> occursin(r"^(Julia)?Manifest.*\.toml$", basename(path)),
        readdir(dirname(project); join=true))
    record = Dict{String,Any}("complete" => false, "started_utc" => string(now(UTC)),
        "aos" => convergence_source(AdaptiveOpticsSim), "gpi" => convergence_source(GPI2Sim),
        "runtime" => Dict("julia" => string(VERSION), "cuda" => string(pkgversion(CUDA)),
            "device" => CUDA.name(CUDA.device()), "cuda_versioninfo" => sprint(io -> CUDA.versioninfo(io)),
            "kernel" => string(Sys.KERNEL), "architecture" => string(Sys.ARCH), "cpu" => Sys.CPU_NAME,
            "threads_default" => Threads.nthreads(:default), "blas_threads" => BLAS.get_num_threads(),
            "project" => project, "project_sha256" => bytes2hex(sha256(read(project))),
            "manifests" => Dict(basename(path) => bytes2hex(sha256(read(path))) for path in manifests)),
        "harness_sha256" => bytes2hex(sha256(read(@__FILE__))),
        "probe_harness_sha256" => bytes2hex(sha256(read(joinpath(@__DIR__, "gpi_actuation_cuda.jl")))),
        "oracle_sha256" => bytes2hex(sha256(read(joinpath(@__DIR__, "gpi_actuation_oracle.jl")))),
        "cases" => Dict{String,Any}(), "fine_sampling_reference_case" => "N720_M192",
        "propagation_strategy" => "PyramidPupilTiltStrategy",
        "reference_sampling" => Dict("pupil_resolution" => 720,
            "modulation_points" => 192,
            "propagation_strategy" => "PyramidPupilTiltStrategy"),
        "comparison_basis" => "Pupil and modulation sampling refinement with the same physical pupil-tilt propagation strategy in every case; no alternate formulation comparison.",
        "scope" => "Noiseless full-camera photon-rate response to fixed physical commands; no RTC slopes or calibration.",
        "command_schema" => command_schema(),
        "command_order" => "woofer 1:97; tweeter 98:2401; normalized pupil x/y OPD coefficients 2402:2403",
        "command_units" => "metres OPD; additive; no mirror-surface reflection factor",
        "camera_rate_units" => "cell-integrated photons per second",
        "timing_boundary" => "Completed step_graph! only; command staging, HIL exchange, artifact I/O and wall pacing excluded.",
        "timing_commands" => "zero metre-OPD coefficients", "virtual_model_rate_hz" => 2000,
        "wall_clock_rate_claim" => false, "convergence_acceptance_gate" => false,
        "pool_interpretation" => "Observations only; graph capture reservations do not establish memory stability.")
    save_record(directory, record)
    target = B.compute_device(CUDA.zeros(Float32, 1))
    host_rates = Dict{String,Dict{String,Matrix{Float32}}}()
    try
        for (resolution, points) in CONVERGENCE_CASES
            label = "N$(resolution)_M$(points)"
            try
                host_rates[label] = convergence_case!(directory, record, target, resolution, points)
            finally
                GC.gc(true)
                CUDA.reclaim()
            end
            record["cases"][label]["pool_after_owner_release"] = convergence_pool()
            save_record(directory, record)
        end
        reference = host_rates["N720_M192"]
        for (label, rates) in host_rates
            record["cases"][label]["sampling_refinement_vs_N720_M192"] =
                response_comparison(rates, reference)
            save_record(directory, record)
        end
        record["complete"] = true
    catch exception
        record["error"] = sprint(showerror, exception, catch_backtrace())
        rethrow()
    finally
        record["finished_utc"] = string(now(UTC))
        save_record(directory, record)
    end
    println(joinpath(directory, "validation.toml"))
end

if abspath(PROGRAM_FILE) == (@__FILE__)
    convergence_main(ARGS)
end
