# Benchmark-only illustrative external RTC; never starts or changes deployed services.
# julia --project=ISOLATED_ENV benchmarks/gpi_closed_loop_cuda.jl EMPTY_OUTPUT_DIRECTORY
# Optional GPI_LOOP_CASES=default,fine,transfer and GPI_LOOP_FRAMES=320 (>=128).
include("gpi_actuation_cuda.jl")
include("gpi_closed_loop_inputs.jl")
using .GPIClosedLoopInputs
using Dates

const LOOP_GAIN = 0.35f0
const MODAL_LIMIT_M = 1f-6
const CALIBRATION_AMPLITUDE_M = 20f-9
const SVD_RELATIVE_CUTOFF = 1e-4

struct ModalRTC{M,V,C,K}
    reconstructor::M
    command_basis::M
    reference::V
    measurement::V
    estimate::V
    coefficients::V
    command::C
    frame::V
    multiplication::K
    inverse_flux::Float32
end
function ModalRTC(system, commands, reconstructor, flat, flux)
    estimate=CUDA.zeros(Float32,size(commands,2))
    multiplication=B._prepare_mul_coefficients(estimate)
    return ModalRTC(CUDA.CuArray(Float32.(reconstructor)), CUDA.CuArray(commands),
        CUDA.CuArray(Float32.(flat ./ flux)), CUDA.zeros(Float32, length(flat)),
        estimate, CUDA.zeros(Float32,size(commands,2)),
        graph_input(system.graph, :command), vec(graph_output(system.graph,:frame)), multiplication, Float32(inv(flux)))
end
capture_phase!(::Nothing,::Symbol)=nothing
function control!(rtc::ModalRTC, gain=LOOP_GAIN,diagnostics=nothing)
    capture_phase!(diagnostics,:camera_normalization)
    rtc.measurement .= rtc.frame .* rtc.inverse_flux .- rtc.reference
    capture_phase!(diagnostics,:reconstruction)
    B._enqueue_mul!(rtc.estimate, rtc.reconstructor, rtc.measurement,rtc.multiplication)
    capture_phase!(diagnostics,:integrator)
    rtc.coefficients .= clamp.(rtc.coefficients .- gain .* rtc.estimate,
        -MODAL_LIMIT_M, MODAL_LIMIT_M)
    capture_phase!(diagnostics,:command_synthesis)
    B._enqueue_mul!(rtc.command, rtc.command_basis, rtc.coefficients,rtc.multiplication)
    return nothing
end
function cycle!(system, rtc, bank, index;gain=LOOP_GAIN)
    copyto!(system.uncompensated_opd, view(bank,:,:,index))
    CUDA.synchronize() # Bank staging/controller use the task stream, plant owns its stream.
    step_graph!(system.graph)
    control!(rtc,gain)
    CUDA.synchronize()
    return nothing
end
cycle_allocations(system,rtc,bank,index) = @allocated cycle!(system,rtc,bank,index)
function reset_loop!(system,rtc)
    reset_graph!(system.graph)
    fill!(rtc.coefficients,0f0);fill!(rtc.command,0f0)
    CUDA.synchronize()
end

include("gpi_closed_loop_execution.jl")

function calibrate!(directory, system, basis)
    graph=system.graph;command=graph_input(graph,:command)
    fill!(system.uncompensated_opd,0f0);fill!(command,0f0);CUDA.synchronize()
    step_graph!(graph)
    flat=vec(Array(graph_output(graph,:frame)))
    flux=sum(Float64,flat)
    @assert flux>0 && all(iszero,reshape(flat,242,240)[241:242,:])
    modes=size(basis,2);D=Matrix{Float64}(undef,length(flat),modes)
    halves=similar(D)
    for (amp,output) in ((CALIBRATION_AMPLITUDE_M,D),(CALIBRATION_AMPLITUDE_M/2,halves))
        for j in 1:modes
            copyto!(command,basis[:,j].*amp);CUDA.synchronize();step_graph!(graph)
            positive=vec(Array(graph_output(graph,:frame)))
            copyto!(command,basis[:,j].*(-amp));CUDA.synchronize();step_graph!(graph)
            negative=vec(Array(graph_output(graph,:frame)))
            output[:,j].=(Float64.(positive).-negative)./(2*Float64(amp)*flux)
        end
    end
    decomposition=svd(D;full=false)
    retained=decomposition.S .>= first(decomposition.S)*SVD_RELATIVE_CUTOFF
    @assert all(retained) "Illustrative modal basis must have full camera rank"
    R=decomposition.V[:,retained]*Diagonal(inv.(decomposition.S[retained]))*
        decomposition.U[:,retained]'
    identity_error=norm(R*D-I)/sqrt(modes)
    @assert identity_error<1e-8
    info=Dict("flat"=>save_array(directory,"flat",reshape(flat,242,240)),
        "interaction_per_m"=>save_array(directory,"interaction",D),
        "half_amplitude_interaction_per_m"=>save_array(directory,"interaction-half",halves),
        "reconstructor_m"=>save_array(directory,"reconstructor",R),
        "singular_values_per_m"=>collect(decomposition.S),"retained_rank"=>count(retained),
        "relative_cutoff"=>SVD_RELATIVE_CUTOFF,"amplitude_m"=>Float64(CALIBRATION_AMPLITUDE_M),
        "RD_identity_relative_frobenius"=>identity_error,"flat_flux_e_per_frame"=>flux,
        "half_amplitude_relative_l2"=>norm(halves-D)/norm(halves),
        "linear_own_calibration_spectral_radius"=>maximum(abs,eigvals(I-LOOP_GAIN*R*D)))
    fill!(command,0f0);CUDA.synchronize()
    return (;D,R,flat,flux,info)
end

function disturbance_bank(basis,frames)
    N=size(basis.mask,1);mask=basis.mask
    # A common physical command is represented on the fine grid once.
    q=Float64[sin(0.71*j)+0.4*cos(0.33*j) for j in axes(basis.commands,2)]
    static=reshape(basis.opd*q,N,N)
    q .*=120e-9/pupil_rms(static,mask)
    static=Float32.(reshape(basis.opd*q,N,N))
    moving=frozen_flow_inputs(resolution=N,frames=frames-64)
    dynamic=Array{Float32}(undef,N,N,frames)
    for k in 1:frames
        t=max(k-65,0)*0.0005
        dynamic[:,:,k].=view(moving.screens,:,:,max(k-64,1))
        dynamic[:,:,k].+=reshape(view(basis.opd,:,1),N,N).*(20e-9*sin(2pi*60t))
        dynamic[:,:,k].+=reshape(view(basis.opd,:,2),N,N).*(15e-9*sin(2pi*90t))
    end
    return (;static,dynamic,q,moving)
end

# Piston-removed Gram diagnostics use the common fine grid, independent of camera.
function wavefront_diagnostics(basis,screenbank)
    H=Float64.(basis.opd); mask=vec(basis.mask);countp=count(mask)
    means=vec(sum(H;dims=1))./countp # OPD columns are zero outside support.
    G=H'*H/countp-means*means'
    factor=cholesky(Symmetric(G)); inverse=inv(factor)
    modes=size(H,2);frames=size(screenbank,3)
    projected=zeros(Float64,modes,frames);power=zeros(Float64,frames)
    for k in 1:frames
        a=Float64.(vec(view(screenbank,:,:,k)));a[.!mask].=0
        mean_a=sum(a)/countp
        power[k]=dot(a,a)/countp-mean_a^2
        mul!(view(projected,:,k),H',a)
        projected[:,k].=projected[:,k]./countp.-means.*mean_a
    end
    ideal=-inverse*projected
    floor_squared=power.+vec(sum(projected.*ideal;dims=1))
    @assert minimum(floor_squared)>-1e-24
    return (;G,ideal,power,floor=sqrt.(max.(floor_squared,0.0)),projected)
end
function service_summary(samples)
    return Dict("samples_ns"=>samples,"median_ns"=>median(samples),
        "p90_ns"=>quantile(samples,0.9),"maximum_ns"=>maximum(samples),
        "model_period_exceedances"=>count(>(500_000),samples),
        "statistical_scope"=>"Single outstanding, unpaced completed GPU plant+modal RTC cycle; not fixed-arrival latency or WCET")
end
function run_trace!(directory,system,rtc,bank,diagnostics,basis; mode=Val(:captured),gain=LOOP_GAIN)
    gain=Float32(gain)
    frames=size(bank,3);modes=length(rtc.coefficients)
    used=zeros(Float32,modes,frames);following=similar(used)
    own_rms=zeros(Float64,frames);camera_error=zeros(Float64,frames);samples=Vector{Int}(undef,frames)
    measured_frame=zeros(Float32,242,240);padding_pass=true
    host_coefficients=zeros(Float32,modes)
    mask=ORACLE.ActuationOracle(system.parameters).pupil
    own_opd=zeros(Float32,size(mask))
    reference=Float64.(Array(rtc.reference));inverse_flux=Float64(rtc.inverse_flux)
    cpu_reconstructor=Float64.(Array(rtc.reconstructor))
    cpu_max_coefficient_difference=0.0
    loop=prepare_loop(system,rtc,bank,mode;gain)
    for k in 1:8;cycle!(loop);end
    reset_loop!(loop)
    for k in 1:frames
        copyto!(host_coefficients,rtc.coefficients);used[:,k].=host_coefficients
        start=time_ns()
        cycle!(loop)
        samples[k]=Int(time_ns()-start)
        copyto!(host_coefficients,rtc.coefficients);following[:,k].=host_coefficients
        copyto!(own_opd,graph_output(system.graph,:pupil_opd))
        own_rms[k]=pupil_rms(own_opd,mask)
        copyto!(measured_frame,graph_output(system.graph,:frame))
        measurement=Float64.(vec(measured_frame)).*inverse_flux.-reference
        camera_error[k]=norm(measurement)
        cpu_next=clamp.(Float64.(used[:,k]).-Float64(gain).*(cpu_reconstructor*measurement),
            -Float64(MODAL_LIMIT_M),Float64(MODAL_LIMIT_M))
        cpu_max_coefficient_difference=max(cpu_max_coefficient_difference,
            maximum(abs,cpu_next.-following[:,k]))
        padding_pass &= all(iszero,view(measured_frame,241:242,:))
        @assert all(isfinite,measured_frame) && all(isfinite,view(following,:,k))
    end
    @assert used[:,2:end]==following[:,1:end-1]
    residual=zeros(Float64,frames);controlled=similar(residual)
    for k in 1:frames
        q=Float64.(used[:,k]);err=q-diagnostics.ideal[:,k]
        controlled[k]=sqrt(max(dot(err,diagnostics.G*err),0))
        residual[k]=sqrt(max(diagnostics.power[k]+2dot(q,diagnostics.projected[:,k])+
            dot(q,diagnostics.G*q),0))
    end
    @assert maximum(abs.(residual.^2-controlled.^2-diagnostics.floor.^2))<1e-24
    saturation=count(x->abs(x)>=MODAL_LIMIT_M,following)
    @assert padding_pass
    @assert cpu_max_coefficient_difference<5e-12 "Device RTC update disagrees with Float64 arithmetic"
    tail=max(1,frames-63):frames
    info=Dict("execution"=>loop_execution_record(loop),"cpu_gpu_update_max_abs_m"=>cpu_max_coefficient_difference,
        "physical_command_max_abs_m"=>maximum(abs,basis.commands*used),
        "frames"=>frames,"gain"=>Float64(gain),"all_finite"=>true,
        "padding_zero"=>padding_pass,"one_frame_causality_exact"=>true,
        "modal_limit_m"=>Float64(MODAL_LIMIT_M),"saturation_samples"=>saturation,
        "maximum_absolute_coefficient_m"=>maximum(abs,following),
        "normalized_camera_error_l2"=>camera_error,
        "common_fine_residual_rms_m"=>residual,"own_grid_residual_rms_m"=>own_rms,
        "common_fine_open_rms_m"=>sqrt.(diagnostics.power),
        "all_mode_fitting_floor_rms_m"=>diagnostics.floor,
        "controlled_error_rms_m"=>controlled,
        "tail_residual_rms_m"=>sqrt(mean(abs2,residual[tail])),
        "tail_open_rms_m"=>sqrt(mean(diagnostics.power[tail])),
        "tail_floor_rms_m"=>sqrt(mean(abs2,diagnostics.floor[tail])),
        "tail_controlled_rms_m"=>sqrt(mean(abs2,controlled[tail])),
        "tail_improves_open_loop"=>mean(abs2,residual[tail])<mean(diagnostics.power[tail]),
        "bounded_unsaturated_observed"=>saturation==0,
        "peak_residual_rms_m"=>maximum(residual),
        "controller_coefficients_used"=>save_array(directory,"coefficients-used",used),
        "controller_coefficients_next"=>save_array(directory,"coefficients-next",following),
        "last_frame"=>save_array(directory,"last-frame",measured_frame),
        "service"=>service_summary(samples))
    for family in (:tiptilt,:woofer,:tweeter)
        indices=findall(==(family),basis.families)
        info[string(family)*"_maximum_modal_m"]=maximum(abs,used[indices,:])
    end
    return info
end

function run_case!(directory,name,N,M,noise,basis,disturbance,diagnostics,calibrations,mode)
    mkpath(directory)
    p=GPI2Parameters(pupil_resolution=N,modulation_points=M,noise=false)
    target=B.compute_device(CUDA.zeros(Float32,1))
    calibration_system=prepare_calibration_system(parameters=p,target=target,
        execution=CapturedGraphExecution())
    calibration=name=="transfer" && haskey(calibrations,"fine") ? calibrations["fine"] :
        calibrate!(directory,calibration_system,basis.commands)
    calibration_info=deepcopy(calibration.info)
    if name=="transfer" && haskey(calibrations,"fine")
        for value in values(calibration_info)
            value isa Dict && haskey(value,"file") && (value["file"]="../fine/"*value["file"])
        end
        calibration_info["reused_from"]="fine"
    end
    actual=name=="transfer" ? calibrations["default"] : calibration
    info=Dict{String,Any}("pupil_resolution"=>N,"modulation_points"=>M,
        "calibration"=>calibration_info,"noise"=>noise,"calibration_parameters"=>Dict(string(n)=>(getfield(p,n)===nothing ? "nothing" : getfield(p,n) isa Tuple ? collect(getfield(p,n)) : getfield(p,n)) for n in fieldnames(typeof(p))),"runs"=>Dict{String,Any}(),
        "calibration_source"=>name=="transfer" ? "default" : name,
        "flat_subtraction"=>"Own plant noiseless flat and flux, including transfer case",
        "linear_spectral_radius"=>maximum(abs,eigvals(I-LOOP_GAIN*actual.R*calibration.D)))
    save_record(directory,info)
    calibrations[name]=calibration
    system=calibration_system
    rtc=ModalRTC(system,basis.commands,actual.R,calibration.flat,calibration.flux)
    staticbank=repeat(reshape(disturbance.static,size(disturbance.static)...,1),1,1,128)
    devicebank=CUDA.CuArray(sample_grid(staticbank,N))
    staticdir=joinpath(directory,"static");mkpath(staticdir)
    info["runs"]["static"]=run_trace!(staticdir,system,rtc,devicebank,
        diagnostics.static,basis;mode)
    save_record(directory,info)
    @assert info["runs"]["static"]["tail_residual_rms_m"]<5e-9
    @assert info["runs"]["static"]["saturation_samples"]==0
    devicebank=nothing;GC.gc(true);CUDA.reclaim()
    for noisy in (false,true)
        noisy && !noise && continue
        if noisy
            # Calibration stays noiseless; detector bias/noise are deliberately not hidden.
            system=nothing;rtc=nothing;calibration_system=nothing;GC.gc(true);CUDA.reclaim()
            system=prepare_calibration_system(parameters=GPI2Parameters(pupil_resolution=N,
                modulation_points=M,noise=true),target=target,execution=CapturedGraphExecution())
            rtc=ModalRTC(system,basis.commands,actual.R,calibration.flat,calibration.flux)
        end
        label=noisy ? "moving_noisy" : "moving_noiseless"
        staged=sample_grid(disturbance.dynamic,N);devicebank=CUDA.CuArray(staged)
        rundir=joinpath(directory,label);mkpath(rundir)
        info["runs"][label]=run_trace!(rundir,system,rtc,devicebank,diagnostics.dynamic,basis;mode)
        # Additional allocation observations include device bank staging in the completed cycle.
        loop=prepare_loop(system,rtc,devicebank,mode)
        cycle!(loop);loop_allocations(loop)
        observations=[loop_allocations(loop) for _ in 1:16]
        mode==Val(:captured) && @assert all(iszero,observations) "Complete captured loop must allocate zero host bytes"
        info["runs"][label]["host_allocation_bytes"]=observations
        trials=Vector{Int}[]
        for trial in 1:3
            reset_loop!(loop)
            for k in 1:8;cycle!(loop);end
            timings=Vector{Int}(undef,64)
            for k in eachindex(timings)
                start=time_ns();cycle!(loop)
                timings[k]=Int(time_ns()-start)
            end
            push!(trials,timings)
        end
        info["runs"][label]["uninterrupted_service_trials"]=[service_summary(t) for t in trials]
        info["runs"][label]["uninterrupted_service_scope"]="Three warmed trials in one process; includes device input staging; no diagnostics between cycles; excludes setup, transport and pacing"
        info["runs"][label]["allocation_scope"]="Completed cycle including device-to-device input staging, plant, modal reconstruction/update and command synthesis"
        save_record(directory,info)
        devicebank=nothing;GC.gc(true);CUDA.reclaim()
    end
    return info
end

function loop_main(args)
    length(args)==1 || error("usage: HARNESS EMPTY_OUTPUT_DIRECTORY")
    directory=abspath(only(args));mkpath(directory)
    isempty(readdir(directory)) || error("output directory must be empty")
    CUDA.functional() || error("functional CUDA required")
    CUDA.allowscalar(false);BLAS.set_num_threads(1);B.set_fft_provider_threads!(1)
    frames=parse(Int,get(ENV,"GPI_LOOP_FRAMES","320"));frames>=128 || error("frames >=128 required")
    execution=get(ENV,"GPI_LOOP_EXECUTION","captured")
    execution in ("captured","stream") || error("GPI_LOOP_EXECUTION must be captured or stream")
    mode=Val(Symbol(execution))
    cases=split(get(ENV,"GPI_LOOP_CASES","default,fine,transfer"),',')
    "transfer" in cases && !("default" in cases) && error("transfer requires default calibration")
    basis=build_basis(GPI2Parameters())
    disturbance=disturbance_bank(basis,frames)
    staticbank=repeat(reshape(disturbance.static,720,720,1),1,1,128)
    diagnostics=(static=wavefront_diagnostics(basis,staticbank),
        dynamic=wavefront_diagnostics(basis,disturbance.dynamic))
    record=Dict{String,Any}("complete"=>false,"started_utc"=>string(now(UTC)),
        "aos"=>source_record(AdaptiveOpticsSim),"gpi"=>source_record(GPI2Sim),
        "julia"=>string(VERSION),"cuda"=>string(pkgversion(CUDA)),
        "device"=>CUDA.name(CUDA.device()),
        "runtime"=>Dict("versioninfo"=>sprint(io->CUDA.versioninfo(io)),
            "cpu"=>Sys.CPU_NAME,"julia_threads"=>Threads.nthreads(),
            "blas_threads"=>BLAS.get_num_threads(),
            "affinity"=>readchomp(`taskset -pc $(getpid())`),
            "uname"=>readchomp(`uname -a`),
            "project_sha256"=>bytes2hex(sha256(read(Base.active_project()))),
            "manifest_sha256"=>bytes2hex(sha256(read(joinpath(dirname(Base.active_project()),"Manifest.toml"))))),
        "frames"=>frames,"mode_count"=>35,
        "disturbance_schedule"=>Dict("initial_frozen_frames"=>64,
            "tip_vibration_rms_coefficient_amplitude_m"=>20e-9,"tip_vibration_hz"=>60.,
            "tilt_vibration_rms_coefficient_amplitude_m"=>15e-9,"tilt_vibration_hz"=>90.,
            "spatial_cutoff_per_axis_cycles_per_aperture"=>20,
            "spectral_support"=>"Square |kx|,|ky|<=20, radial maximum sqrt(2)*20; periodic D-sized domain"),
        "mode_labels"=>basis.labels,"mode_families"=>string.(basis.families),
        "controller_scope"=>"Illustrative external 35-mode RTC; not HEART or deployed controller; no full-order allocation/stability qualification",
        "performance_scope"=>"Completed unpaced device-input staging + plant + RTC + next-command synthesis; diagnostics excluded; no transport/HIL host copies",
        "execution"=>execution,
        "execution_harness_sha256"=>bytes2hex(sha256(read(joinpath(@__DIR__,"gpi_closed_loop_execution.jl")))),
        "disturbance"=>Dict(string(k)=>(v isa Symbol ? string(v) : v isa Tuple ? collect(v) : v) for (k,v) in pairs(disturbance.moving.metadata)),"cases"=>Dict{String,Any}(),
        "basis_commands"=>save_array(directory,"basis-commands",basis.commands),
        "basis_opd_fine"=>Dict("shape"=>collect(size(basis.opd)),
            "sha256"=>bytes2hex(sha256(reinterpret(UInt8,vec(basis.opd)))),
            "generation"=>"Reconstruct from basis commands with committed Float64 actuation oracle; rounded Float32, zero outside fine annulus"),
        "basis_gram"=>save_array(directory,"basis-gram",diagnostics.dynamic.G),
        "static_coefficients_m"=>disturbance.q,
        "spectral_real"=>save_array(directory,"spectral-real",real.(disturbance.moving.spectral_coefficients)),
        "spectral_imag"=>save_array(directory,"spectral-imag",imag.(disturbance.moving.spectral_coefficients)),
        "harness_sha256"=>bytes2hex(sha256(read(@__FILE__))),
        "inputs_sha256"=>bytes2hex(sha256(read(joinpath(@__DIR__,"gpi_closed_loop_inputs.jl")))))
    save_record(directory,record)
    calibrations=Dict{String,NamedTuple}()
    for name in cases
        N,M=name=="default" ? (240,24) : (720,192)
        println("Starting closed-loop case ",name);flush(stdout)
        record["cases"][name]=run_case!(joinpath(directory,name),name,N,M,name!="transfer",
            basis,disturbance,diagnostics,calibrations,mode)
        save_record(directory,record);GC.gc(true);CUDA.reclaim()
    end
    record["finished_utc"]=string(now(UTC));record["complete"]=true
    save_record(directory,record);println("Closed-loop exercise complete")
end
if abspath(PROGRAM_FILE)==@__FILE__
    loop_main(ARGS)
end
