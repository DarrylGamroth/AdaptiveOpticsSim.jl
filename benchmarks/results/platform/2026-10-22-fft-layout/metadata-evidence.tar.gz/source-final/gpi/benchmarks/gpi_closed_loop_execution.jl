# Fixed-address complete-loop execution, owned only by this benchmark.
# The retained child plant is exclusive to this owner while armed: its public
# step/HIL sequence is not used; the outer AOS graph owns completion and sequence.
const DRIVER = CUDA.CUDACore

mutable struct LoopCaptureDiagnostics
    phase::Symbol
    cause::String
end
capture_phase!(diagnostics::LoopCaptureDiagnostics,phase::Symbol)=(diagnostics.phase=phase;nothing)
struct LoopCaptureError{E} <: Exception
    phase::Symbol
    initiating_cause::String
    cause::E
end
function Base.showerror(io::IO,error::LoopCaptureError)
    print(io,"Complete CUDA loop capture failed at ",error.phase,
        "; requested capture remains mandatory. CUDA.jl ",pkgversion(CUDA),
        ". Check node capture qualification, fixed buffer bindings, retained cuBLAS workspace, ",
        "and capture stream dependencies. Initiating error: ",error.initiating_cause,
        ". Capture/preparation error: ")
    showerror(io,error.cause)
end

# During stream capture a native executable cannot be launched on this driver.
# Insert the retained native graph at the current capture frontier instead.
function enqueue_plant!(plant)
    stream=CUDA.stream()
    if !CUDA.is_capturing(stream)
        CUDA.launch(plant.graph.execution.captured.executable,stream)
        return nothing
    end
    status=Ref{DRIVER.CUstreamCaptureStatus}()
    id=Ref{UInt64}()
    graph=Ref{DRIVER.CUgraph}()
    dependencies=Ref{Ptr{DRIVER.CUgraphNode}}()
    count=Ref{Csize_t}()
    DRIVER.cuStreamGetCaptureInfo_v3(stream,status,id,graph,dependencies,C_NULL,count)
    status[]==DRIVER.CU_STREAM_CAPTURE_STATUS_ACTIVE ||
        error("plant child insertion requires active stream capture")
    child=Ref{DRIVER.CUgraphNode}()
    DRIVER.cuGraphAddChildGraphNode(child,graph[],dependencies[],count[],
        plant.graph.execution.captured.graph)
    DRIVER.cuStreamUpdateCaptureDependencies_v2(stream,child,C_NULL,1,
        UInt32(DRIVER.CU_STREAM_SET_CAPTURE_DEPENDENCIES))
    return nothing
end

function stage_input_kernel!(destination,bank,index)
    i=(CUDA.blockIdx().x-1)*CUDA.blockDim().x+CUDA.threadIdx().x
    if i<=length(destination)
        destination[i]=bank[i+(index[1]-1)*length(destination)]
    end
    return nothing
end
function advance_input_kernel!(index,count)
    index[1]=index[1]==count ? Int32(1) : index[1]+Int32(1)
    return nothing
end
struct CompleteLoopNode end
struct CompleteLoopOwner{S,R,B,I}
    plant::S
    rtc::R
    bank::B
    index::I
    gain::Float32
    diagnostics::LoopCaptureDiagnostics
end
AG.graph_node_ports(::Type{CompleteLoopNode},config)=()
function AG.prepare_graph_node(::Type{CompleteLoopNode},config,::NamedTuple{()},
    ::NamedTuple{()},::NamedTuple{()},::NamedTuple{()},target)
    B.compute_device(config.bank)==target || error("loop bank and graph must use the exact same CUDA device")
    B.compute_device(config.plant.uncompensated_opd)==target || error("plant and loop target mismatch")
    size(config.bank)[1:2]==size(config.plant.uncompensated_opd) || error("loop bank pupil shape mismatch")
    0<size(config.bank,3)<=typemax(Int32) || error("loop bank frame count must fit Int32")
    index=CUDA.fill(Int32(1),1)
    return CompleteLoopOwner(config.plant,config.rtc,config.bank,index,
        config.gain,config.diagnostics)
end
AG.graph_node_capture_capability(::CompleteLoopOwner)=AG.GraphNodeCaptureSafe()
function enqueue_loop!(owner::CompleteLoopOwner)
    try
        owner.diagnostics.phase=:input_staging
        destination=owner.plant.uncompensated_opd
        CUDA.@cuda threads=256 blocks=cld(length(destination),256) stage_input_kernel!(
            destination,owner.bank,owner.index)
        owner.diagnostics.phase=:plant_child
        enqueue_plant!(owner.plant)
        owner.diagnostics.phase=:rtc
        control!(owner.rtc,owner.gain,owner.diagnostics)
        owner.diagnostics.phase=:input_advance
        CUDA.@cuda threads=1 blocks=1 advance_input_kernel!(owner.index,Int32(size(owner.bank,3)))
        owner.diagnostics.phase=:complete
    catch error
        owner.diagnostics.cause=sprint(showerror,error)*"; originating calls: "*join((string(f.func)*"@"*basename(string(f.file))*":"*string(f.line) for f in stacktrace(catch_backtrace())[1:min(end,35)])," <- ")
        rethrow()
    end
    return nothing
end
AG.enqueue_captured_graph_node!(owner::CompleteLoopOwner)=enqueue_loop!(owner)
# This owner is prepared only with CapturedGraphExecution; explicit diagnostic
# stream mode below uses the original complete-frame API and its own callbacks.
AG.step_graph_node!(::CompleteLoopOwner)=throw(AG.AlgorithmGraphError(
    "complete-loop owner requires captured execution; use explicit stream diagnostic mode for the baseline"))
AG._preflight_captured_graph_node!(owner::CompleteLoopOwner)=
    AG._preflight_captured_nodes!(values(owner.plant.graph.nodes))
AG._complete_captured_graph_node!(owner::CompleteLoopOwner)=
    AG._complete_captured_nodes!(values(owner.plant.graph.nodes))
function AG.reset_graph_node!(owner::CompleteLoopOwner)
    reset_loop!(owner.plant,owner.rtc)
    fill!(owner.index,Int32(1))
    # Child reset runs on its retained stream. Transfer managed-buffer ownership
    # back to this outer stream while cold; doing this from a broadcast's alias
    # check during capture would query/synchronize the child's stream illegally.
    for array in (owner.rtc.reconstructor,owner.rtc.command_basis,owner.rtc.reference,
        owner.rtc.measurement,owner.rtc.estimate,owner.rtc.coefficients,
        owner.rtc.command,owner.rtc.frame,owner.rtc.multiplication.alpha.x)
        pointer(array)
    end
    return nothing
end
function prepare_complete_loop(plant,rtc,bank;gain=LOOP_GAIN)
    graph_execution_policy(plant.graph)==CapturedGraphExecution() || error("complete loop requires a captured plant; explicitly prepare the CUDA plant with capture")
    diagnostics=LoopCaptureDiagnostics(:preparation,"")
    config=(;plant,rtc,bank,gain=Float32(gain),diagnostics)
    definition=algorithm_graph((algorithm_node(:complete_loop,CompleteLoopNode,config),);
        name=:gpi_complete_closed_loop)
    try
        return prepare_algorithm_graph(definition;target=B.compute_device(bank),
            execution=CapturedGraphExecution())
    catch error
        throw(LoopCaptureError(diagnostics.phase,
            isempty(diagnostics.cause) ? sprint(showerror,error) : diagnostics.cause,error))
    end
end
cycle!(loop::PreparedAlgorithmGraph)=step_graph!(loop)
reset_loop!(loop::PreparedAlgorithmGraph)=reset_graph!(loop)
loop_allocations(loop)=@allocated cycle!(loop)

mutable struct StreamLoop{S,R,B}
    plant::S
    rtc::R
    bank::B
    index::Int
    gain::Float32
end
function cycle!(loop::StreamLoop)
    cycle!(loop.plant,loop.rtc,loop.bank,loop.index;gain=loop.gain)
    loop.index=mod1(loop.index+1,size(loop.bank,3))
    return nothing
end
function reset_loop!(loop::StreamLoop)
    reset_loop!(loop.plant,loop.rtc);loop.index=1
    return nothing
end
prepare_loop(plant,rtc,bank,::Val{:captured};gain=LOOP_GAIN)=prepare_complete_loop(plant,rtc,bank;gain)
prepare_loop(plant,rtc,bank,::Val{:stream};gain=LOOP_GAIN)=StreamLoop(plant,rtc,bank,1,Float32(gain))

function native_graph_structure(graph)
    count=Ref{Csize_t}(0);DRIVER.cuGraphGetNodes(graph,C_NULL,count)
    nodes=Vector{DRIVER.CUgraphNode}(undef,count[]);DRIVER.cuGraphGetNodes(graph,nodes,count)
    kinds=Dict{String,Int}();children=[]
    for node in nodes
        kind=Ref{DRIVER.CUgraphNodeType}();DRIVER.cuGraphNodeGetType(node,kind)
        key=string(kind[]);kinds[key]=get(kinds,key,0)+1
        if kind[]==DRIVER.CU_GRAPH_NODE_TYPE_GRAPH
            child=Ref{DRIVER.CUgraph}();DRIVER.cuGraphChildGraphNodeGetGraph(node,child)
            push!(children,native_graph_structure(child[]))
        end
    end
    return Dict("node_count"=>Int(count[]),"node_types"=>kinds,"children"=>children)
end
function loop_execution_record(loop::PreparedAlgorithmGraph)
    return Dict("policy"=>"complete captured CUDA Graph", "host_graph_node_count"=>captured_graph_node_count(loop),
        "native"=>native_graph_structure(loop.execution.captured.graph),
        "includes"=>["device input-bank staging","plant child graph","camera normalization",
            "reconstruction","integrator/clamp","command synthesis","device input-index advance"],
        "allocation_nodes_rejected_recursively"=>true)
end
loop_execution_record(::StreamLoop)=Dict("policy"=>"explicit diagnostic stream baseline")
