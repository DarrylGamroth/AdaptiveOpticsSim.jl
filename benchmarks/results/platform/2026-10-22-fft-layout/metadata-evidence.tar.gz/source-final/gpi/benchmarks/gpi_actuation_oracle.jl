module GPIActuationOracle

using SHA: sha256
using LinearAlgebra: mul!

export ActuationOracle, column!, opd!, dense_opd!, influence_at, pupil_contains,
    source_index_map, source_grid_indices, verify_source_maps

# An analytical check of the declared simulator model, not measured GPI fidelity.
# This module deliberately imports neither GPI2Sim nor AdaptiveOpticsSim. Numeric
# source labels and SHA256 identities have provenance in docs/model-provenance.md.
const SOURCE_HASHES = (
    woofer="828199fac0ae91e8d614ee353a1930ef6ab3aece51d6d66c1169321e25d4bed4",
    tweeter="8d72cf020deb5525f97826fe2e9c4d8314f8cb44d6ef4db36eec3b67266167f3")

function source_index_map(mirror::Symbol)
    if mirror === :tweeter
        return Int32[(row - 1) * 48 + column for row in 1:48, column in 1:48]
    elseif mirror === :woofer
        widths = (5, 7, 9, 11, 11, 11, 11, 11, 9, 7, 5)
        labels = zeros(Int32, 11, 11)
        for row in 1:11
            first_label = 1 + sum(widths[(row + 1):end]; init=0)
            first_column = 1 + (11 - widths[row]) ÷ 2
            for offset in 0:(widths[row] - 1)
                labels[row, first_column + offset] = first_label + offset
            end
        end
        return labels
    end
    throw(ArgumentError("mirror must be :woofer or :tweeter"))
end

"""Independent command-to-grid labels: source column is +x, source row is −y."""
function source_grid_indices(mirror::Symbol)
    labels = source_index_map(mirror)
    k = size(labels, 1)
    cells = zeros(Int32, maximum(labels))
    for row in 1:k, column in 1:k
        label = labels[row, column]
        iszero(label) && continue
        cells[label] = column + k * (k - row)
    end
    return cells
end

struct GaussianMirror
    axis_count::Int
    pitch::Float64
    sigma::Float64
    grid_indices::Vector{Int32}
    basis::Matrix{Float64}
end

function GaussianMirror(mirror::Symbol, coordinates::Vector{Float64}, coupling::Float64)
    k, pitch = mirror === :woofer ? (11, 2 / 10) : (48, 2 / 43)
    sigma = pitch / sqrt(-2 * log(coupling))
    basis = [exp(-(x - (cell - (k + 1) / 2) * pitch)^2 / (2 * sigma^2))
             for x in coordinates, cell in 1:k]
    return GaussianMirror(k, pitch, sigma, source_grid_indices(mirror), basis)
end

"""
    ActuationOracle(; resolution, central_obstruction_ratio,
        woofer_coupling, tweeter_coupling)
    ActuationOracle(parameters)

Independent Float64 command→OPD model. Pass the actual immutable GPI parameters:
Float32 couplings and obstruction are converted to Float64 without recovering
their unrounded decimal defaults. Pitches are declared normalized values 2/10
and 2/43; coordinates on each pupil axis are (2i−N−1)/N. Axis 1 is x, axis 2 y.
The annulus includes both boundaries (ρ² ≤ x²+y² ≤ 1), matching the inclusive
boundary convention in AOS optics/aperture_masks.jl, without calling its code.

All 2,403 commands have units metres of OPD: 97 woofer, 2,304 tweeter, then
two coefficients multiplying normalized x and y. Contributions add directly;
there is no reflection factor or inferred corrective sign. Configured channels
need not have an observable Float32 response after sampling and pupil masking.
"""
struct ActuationOracle
    resolution::Int
    central_obstruction_ratio::Float64
    woofer_coupling::Float64
    tweeter_coupling::Float64
    coordinates::Vector{Float64}
    pupil::BitMatrix
    woofer::GaussianMirror
    tweeter::GaussianMirror
end

pupil_contains(x::Real, y::Real, obstruction::Real) =
    Float64(obstruction)^2 <= Float64(x)^2 + Float64(y)^2 <= 1.0

function ActuationOracle(; resolution::Integer, central_obstruction_ratio::Real,
    woofer_coupling::Real, tweeter_coupling::Real)
    n = Int(resolution)
    n > 0 || throw(ArgumentError("resolution must be positive"))
    rho, wc, tc = Float64.((central_obstruction_ratio, woofer_coupling, tweeter_coupling))
    isfinite(rho) && 0 <= rho < 1 || throw(ArgumentError("obstruction must lie in [0, 1)"))
    all(c -> isfinite(c) && 0 < c < 1, (wc, tc)) ||
        throw(ArgumentError("couplings must lie in (0, 1)"))
    coordinates = [(2 * i - n - 1) / n for i in 1:n]
    pupil = BitMatrix([pupil_contains(x, y, rho) for x in coordinates, y in coordinates])
    return ActuationOracle(n, rho, wc, tc, coordinates, pupil,
        GaussianMirror(:woofer, coordinates, wc), GaussianMirror(:tweeter, coordinates, tc))
end

ActuationOracle(parameters) = ActuationOracle(;
    resolution=parameters.pupil_resolution,
    central_obstruction_ratio=parameters.central_obstruction_ratio,
    woofer_coupling=parameters.woofer_coupling,
    tweeter_coupling=parameters.tweeter_coupling)

function _mirror(oracle::ActuationOracle, mirror::Symbol)
    mirror === :woofer && return oracle.woofer
    mirror === :tweeter && return oracle.tweeter
    throw(ArgumentError("mirror must be :woofer or :tweeter"))
end

function _grid_cell(mirror::GaussianMirror, index::Integer)
    cell = mirror.grid_indices[index]
    return (mod1(cell, mirror.axis_count), (cell - 1) ÷ mirror.axis_count + 1)
end

"""Unmasked unit Gaussian at arbitrary normalized coordinates, evaluated directly."""
function influence_at(oracle::ActuationOracle, mirror::Symbol, index::Integer, x::Real, y::Real)
    model = _mirror(oracle, mirror)
    gx, gy = _grid_cell(model, index)
    cx = (gx - (model.axis_count + 1) / 2) * model.pitch
    cy = (gy - (model.axis_count + 1) / 2) * model.pitch
    return exp(-((Float64(x) - cx)^2 + (Float64(y) - cy)^2) / (2 * model.sigma^2))
end

function _check_output(out::AbstractMatrix{Float64}, oracle::ActuationOracle)
    axes(out) == (Base.OneTo(oracle.resolution), Base.OneTo(oracle.resolution)) ||
        throw(DimensionMismatch("output must have one-based N×N axes"))
    return nothing
end

function _add_column!(out::AbstractMatrix{Float64}, oracle::ActuationOracle,
    mirror::GaussianMirror, index::Integer, amplitude::Float64)
    gx, gy = _grid_cell(mirror, index)
    for j in 1:oracle.resolution, i in 1:oracle.resolution
        oracle.pupil[i, j] || continue
        out[i, j] += amplitude * mirror.basis[i, gx] * mirror.basis[j, gy]
    end
    return out
end

function _add_tiptilt!(out::AbstractMatrix{Float64}, oracle::ActuationOracle,
    index::Integer, amplitude::Float64)
    index in 1:2 || throw(BoundsError(1:2, index))
    for j in 1:oracle.resolution, i in 1:oracle.resolution
        oracle.pupil[i, j] || continue
        out[i, j] += amplitude * oracle.coordinates[index == 1 ? i : j]
    end
    return out
end

"""
    column!(out, oracle, mirror, index, amplitude=1)

Overwrite a Float64 N×N output with one channel's masked OPD. `mirror` is
`:woofer`, `:tweeter`, or `:tiptilt`; `index` is local command order. Precomputed
Float64 one-dimensional exponentials avoid an exponential per output sample.
"""
function column!(out::AbstractMatrix{Float64}, oracle::ActuationOracle,
    mirror::Symbol, index::Integer, amplitude::Real=1)
    _check_output(out, oracle)
    fill!(out, 0.0)
    if mirror === :tiptilt
        return _add_tiptilt!(out, oracle, index, Float64(amplitude))
    end
    return _add_column!(out, oracle, _mirror(oracle, mirror), index, Float64(amplitude))
end

"""
    opd!(out, oracle, command)

Direct sum of the complete 2,403-entry command, skipping exact zero entries.
Suitable for arbitrary commands and sparse superposition probes. This path
uses independent reconstructed labels and Float64 Gaussian samples throughout.
"""
function opd!(out::AbstractMatrix{Float64}, oracle::ActuationOracle, command::AbstractVector)
    _check_output(out, oracle)
    axes(command) == (Base.OneTo(2403),) || throw(DimensionMismatch("command must have 2,403 entries"))
    fill!(out, 0.0)
    for index in 1:97
        iszero(command[index]) || _add_column!(out, oracle, oracle.woofer, index, Float64(command[index]))
    end
    for index in 1:2304
        value = command[97 + index]
        iszero(value) || _add_column!(out, oracle, oracle.tweeter, index, Float64(value))
    end
    _add_tiptilt!(out, oracle, 1, Float64(command[2402]))
    _add_tiptilt!(out, oracle, 2, Float64(command[2403]))
    return out
end

function _dense_mirror!(out::AbstractMatrix{Float64}, mirror::GaussianMirror,
    command::AbstractVector, offset::Int)
    coefficients = zeros(Float64, mirror.axis_count, mirror.axis_count)
    for index in eachindex(mirror.grid_indices)
        gx, gy = _grid_cell(mirror, index)
        coefficients[gx, gy] = Float64(command[offset + index])
    end
    temporary = Matrix{Float64}(undef, size(out, 1), mirror.axis_count)
    mul!(temporary, mirror.basis, coefficients)
    mul!(out, temporary, transpose(mirror.basis), 1.0, 1.0)
    return out
end

"""
    dense_opd!(out, oracle, command)

Float64 separable evaluation for dense command probes: B C Bᵀ for each mirror,
where C uses this module's independently reconstructed source labels. Uses the
same declared Gaussian equations as `opd!`, with a different summation order.
Allocates small CPU scratch matrices; this is a validation oracle, not a plant
hot path. Compare its result with the direct sum when establishing evidence.
"""
function dense_opd!(out::AbstractMatrix{Float64}, oracle::ActuationOracle, command::AbstractVector)
    _check_output(out, oracle)
    axes(command) == (Base.OneTo(2403),) || throw(DimensionMismatch("command must have 2,403 entries"))
    fill!(out, 0.0)
    _dense_mirror!(out, oracle.woofer, command, 0)
    _dense_mirror!(out, oracle.tweeter, command, 97)
    for index in eachindex(out, oracle.pupil)
        oracle.pupil[index] || (out[index] = 0.0)
    end
    _add_tiptilt!(out, oracle, 1, Float64(command[2402]))
    _add_tiptilt!(out, oracle, 2, Float64(command[2403]))
    return out
end

"""
    verify_source_maps(directory)

Compare optional locally available HEART CSVs against both recorded SHA256
identities and reconstructed numeric labels. No external source is copied.
Returns evidence per mirror; the caller decides how to handle a mismatch.
"""
function verify_source_maps(directory::AbstractString)
    return map((:woofer, :tweeter)) do mirror
        expected = source_index_map(mirror)
        path = joinpath(directory, "dmActuatorMap_$(maximum(expected)).csv")
        digest = bytes2hex(sha256(read(path)))
        lines = readlines(path)
        header = split(first(lines))
        dimensions_match = parse.(Int, header[1:2]) == collect(size(expected))
        actual = [parse.(Int32, split(strip(line), ',')) for line in lines[2:end] if !isempty(strip(line))]
        labels_match = dimensions_match && length(actual) == size(expected, 1) &&
            all(row -> actual[row] == expected[row, :], axes(expected, 1))
        (; mirror, path, sha256=digest, hash_matches=digest == getproperty(SOURCE_HASHES, mirror), labels_match)
    end
end

end # module
