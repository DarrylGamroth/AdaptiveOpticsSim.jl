# Explicit CUDA benchmark target: julia --project=ISOLATED_ENV benchmarks/test_gpi_closed_loop_cuda.jl
include("gpi_closed_loop_cuda.jl")
using Test

function fixture(parameters,commands,calibration,bank;gain=LOOP_GAIN)
    system=prepare_calibration_system(parameters=parameters,target=B.compute_device(bank))
    rtc=ModalRTC(system,commands,calibration.R,calibration.flat,calibration.flux)
    loop=prepare_complete_loop(system,rtc,bank;gain)
    return (;system,rtc,loop)
end
function snapshot(f)
    return (frame=Array(graph_output(f.system.graph,:frame)),
        opd=Array(graph_output(f.system.graph,:pupil_opd)),
        q=Array(f.rtc.coefficients),command=Array(f.rtc.command))
end
function storage_signature(f)
    return (pointer(f.system.uncompensated_opd),pointer(f.rtc.reconstructor),
        pointer(f.rtc.frame),pointer(f.rtc.coefficients),pointer(f.rtc.command),
        pointer(AG.prepared_graph_node(f.loop,Val(:complete_loop)).index))
end
function require_fixed_nodes(record)
    for (kind,count) in record["node_types"]
        @test !(occursin("MEM_ALLOC",kind)||occursin("MEM_FREE",kind)) || count==0
    end
    foreach(require_fixed_nodes,record["children"])
end

CUDA.functional() || error("CUDA hardware required")
CUDA.allowscalar(false);BLAS.set_num_threads(1);B.set_fft_provider_threads!(1)
target=B.compute_device(CUDA.zeros(Float32,1))
p=GPI2Parameters(pupil_resolution=60,modulation_points=4,noise=false)
basis=build_basis(p;reference_resolution=60)
calibration_system=prepare_calibration_system(parameters=p,target=target)
calibration=calibrate!(mktempdir(),calibration_system,basis.commands)
coordinates=Float32.((2 .* collect(1:60) .- 61)./60)
hostbank=Float32[(12e-9*x+8e-9*y)*k+4e-9*cospi(3*x+k*y)
    for x in coordinates,y in coordinates,k in 1:3]
bank=CUDA.CuArray(hostbank)

@testset "Complete CUDA closed-loop capture" begin
    for noisy in (false,true),gain in (LOOP_GAIN,0f0)
        parameters=GPI2Parameters(pupil_resolution=60,modulation_points=4,noise=noisy)
        captured=fixture(parameters,basis.commands,calibration,bank;gain)
        stream_system=prepare_calibration_system(parameters=parameters,target=target)
        stream_rtc=ModalRTC(stream_system,basis.commands,calibration.R,calibration.flat,calibration.flux)
        stream=prepare_loop(stream_system,stream_rtc,bank,Val(:stream);gain)
        reset_loop!(stream);reset_loop!(captured.loop)
        before=storage_signature(captured)
        reference=[]
        for k in 1:8
            cycle!(stream);cycle!(captured.loop)
            actual=snapshot(captured)
            expected=(frame=Array(graph_output(stream_system.graph,:frame)),
                opd=Array(graph_output(stream_system.graph,:pupil_opd)),
                q=Array(stream_rtc.coefficients),command=Array(stream_rtc.command))
            @test actual.frame ≈ expected.frame rtol=2e-5 atol=1e-4
            @test actual.opd ≈ expected.opd rtol=2e-5 atol=1e-12
            @test actual.q ≈ expected.q rtol=2e-5 atol=1e-12
            @test actual.command ≈ expected.command rtol=2e-5 atol=1e-12
            @test Array(AG.prepared_graph_node(captured.loop,Val(:complete_loop)).index)==[mod1(k+1,3)]
            @test graph_step_sequence(captured.loop)==k
            @test all(iszero,actual.frame[241:242,:])
            gain==0 && @test all(iszero,actual.q)
            push!(reference,actual)
        end
        GC.gc(true);CUDA.reclaim()
        reset_loop!(captured.loop)
        @test before==storage_signature(captured)
        for k in 1:8
            cycle!(captured.loop)
            @test snapshot(captured)==reference[k]
        end
        cycle!(captured.loop);loop_allocations(captured.loop)
        @test all(iszero,[loop_allocations(captured.loop) for _ in 1:32])
        @test_throws AG.AlgorithmGraphError AG.step_graph_node!(AG.prepared_graph_node(captured.loop,Val(:complete_loop)))
        @test captured_graph_node_count(captured.loop)==1
        info=loop_execution_record(captured.loop)
        @test info["native"]["node_types"]["CU_GRAPH_NODE_TYPE_GRAPH"]==1
        require_fixed_nodes(info["native"])
        ticket=step_graph_async!(captured.loop)
        @test_throws AG.AlgorithmGraphError step_graph!(captured.loop)
        wait_graph_step!(ticket)
        @test_throws AG.AlgorithmGraphError wait_graph_step!(ticket)
        reset_loop!(captured.loop)
        # Simulate an unfinished child exposure: delegated preflight must stop
        # the outer graph without committing a sequence or losing reset replay.
        detector=AG.prepared_graph_node(captured.system.graph,Val(:detector)).prepared.detector
        detector.state.readout_ready=false
        sequence=graph_step_sequence(captured.loop)
        @test_throws AdaptiveOpticsSim.InvalidConfiguration cycle!(captured.loop)
        @test graph_failed(captured.loop)
        @test !graph_step_pending(captured.loop)
        @test graph_step_sequence(captured.loop)==sequence
        @test_throws AG.AlgorithmGraphError cycle!(captured.loop)
        reset_loop!(captured.loop);cycle!(captured.loop)
        @test snapshot(captured)==reference[1]
    end
    # A preparation error must retain its cause and fail, never select stream.
    system=prepare_calibration_system(parameters=p,target=target)
    rtc=ModalRTC(system,basis.commands,calibration.R,calibration.flat,calibration.flux)
    error=try prepare_complete_loop(system,rtc,CUDA.zeros(Float32,30,30,1));nothing catch e;e end
    @test error isa LoopCaptureError
    @test occursin("pupil shape mismatch",sprint(showerror,error))
    invalid=ModalRTC(system,basis.commands[:,1:34],calibration.R,calibration.flat,calibration.flux)
    error=try prepare_complete_loop(system,invalid,bank);nothing catch e;e end
    @test error isa LoopCaptureError
    @test error.phase==:reconstruction
    @test !isempty(error.initiating_cause)
    @test occursin("mandatory",sprint(showerror,error))
end
