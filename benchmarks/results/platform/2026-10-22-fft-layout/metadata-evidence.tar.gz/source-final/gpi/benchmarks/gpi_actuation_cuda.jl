# Independent declared-model checks, not measured instrument qualification.
# julia --project=ISOLATED_ENV --startup-file=no HARNESS OUTPUT_DIRECTORY HEART_MAP_DIRECTORY
using GPI2Sim, AdaptiveOpticsSim, AdaptiveOpticsSim.AlgorithmGraphs
using LinearAlgebra, Random, SHA, Statistics, TOML
import CUDA
include("gpi_actuation_oracle.jl")
const ORACLE = GPIActuationOracle
const AG = AdaptiveOpticsSim.AlgorithmGraphs
const B = AdaptiveOpticsSim.Backends
const COMPONENTS = (:woofer_opd, :tweeter_opd, :tiptilt_opd)
const COMPONENT_NODES = (:command_routing, :woofer, :tweeter, :tiptilt,
    :woofer_composition, :tweeter_composition, :tiptilt_composition)

function save_record(directory, record)
    path=joinpath(directory, "validation.toml")
    open(path*".tmp", "w") do io
        TOML.print(io, record; sorted=true)
    end
    mv(path*".tmp",path;force=true)
end
function save_array(directory, name, values::AbstractArray{T}) where {T<:Union{Float32,Float64}}
    ENDIAN_BOM == 0x04030201 || error("little-endian host required")
    filename = name * (T === Float32 ? ".f32" : ".f64")
    path = joinpath(directory, filename)
    open(io -> write(io, vec(values)), path, "w")
    return Dict("file"=>filename, "shape"=>collect(size(values)), "eltype"=>string(T),
        "order"=>"column-major little-endian", "sha256"=>bytes2hex(sha256(read(path))))
end
function errors(actual, expected)
    delta = Float64.(actual) .- expected
    reference_norm = norm(expected)
    return Dict("max_abs"=>maximum(abs, delta), "relative_l2"=>
        iszero(reference_norm) ? norm(delta) : norm(delta) / reference_norm)
end
function component_step!(graph)
    # Disposable diagnostic owner: enqueue the actual captured node protocol in
    # its prepared context. This excludes optics and does not advance graph/HIL
    # sequence bookkeeping; no complete frames are requested from this owner.
    B._with_prepared_device_execution_context(graph.context) do
        for name in COMPONENT_NODES
            AG.enqueue_captured_graph_node!(AG.prepared_graph_node(graph, name))
        end
        B._synchronize_prepared_device_execution_context_blocking!(graph.context)
    end
    return nothing
end
function family(index)
    index <= 97 && return (:woofer, index, 1)
    index <= 2401 && return (:tweeter, index - 97, 2)
    return (:tiptilt, index - 2401, 3)
end

function all_columns!(directory, p, target, oracle)
    system = prepare_calibration_system(; parameters=p, target,
        execution=CapturedGraphExecution())
    graph = system.graph
    amplitude = Array(AG.prepared_graph_node(graph, :pyramid).prepared.input.amplitude)
    @assert (!iszero).(amplitude) == oracle.pupil
    routing = AG.prepared_graph_node(graph, :command_routing)
    host_command = zeros(Float32, 2403)
    reference = zeros(Float64, p.pupil_resolution, p.pupil_resolution)
    coefficient = 20f-9
    summaries = Dict(string(name)=>Dict("columns"=>0, "zero_device_columns"=>0,
        "reference_peak_gain_below_1e_6"=>0, "maximum_error_per_command"=>0.0,
        "maximum_relative_l2_peak_gain_at_least_1e_6"=>0.0) for name in (:woofer,:tweeter,:tiptilt))
    csv = joinpath(directory, "columns.csv")
    open(csv, "w") do io
        println(io, "command,family,local_index,reference_peak_gain,device_peak_gain,reference_norm_m,max_abs_error_m,error_per_command,relative_l2,device_nonzero_samples,device_sha256")
        for index in 1:2403
            index > 1 && (host_command[index - 1] = 0f0)
            host_command[index] = coefficient
            copyto!(graph_input(graph, :command), host_command)
            CUDA.synchronize()
            component_step!(graph)
            # Every route is checked on every column, including zero neighbors.
            @assert Array(routing.outputs.woofer) == host_command[1:97]
            @assert Array(routing.outputs.tweeter) == host_command[98:2401]
            @assert Array(routing.outputs.tiptilt) == host_command[2402:2403]
            mirror, local_index, selected = family(index)
            ORACLE.column!(reference, oracle, mirror, local_index, coefficient)
            actual = Array(graph_output(graph, COMPONENTS[selected]))
            for other in 1:3
                other == selected && continue
                @assert all(iszero, Array(graph_output(graph, COMPONENTS[other])))
            end
            @assert Array(graph_output(graph, :pupil_opd)) == actual
            @assert all(iszero, actual[.!oracle.pupil])
            e = errors(actual, reference)
            gain_error = e["max_abs"] / abs(Float64(coefficient))
            # Float32 grid sampling/exponentials vs independent Float64 physical
            # equations. Absolute command-normalized bound remains meaningful
            # for channels whose masked Gaussian tails underflow in Float32.
            @assert gain_error <= 1e-5 (index, mirror, local_index, e)
            peak = maximum(abs, reference) / abs(Float64(coefficient))
            device_peak = maximum(abs, actual) / abs(Float64(coefficient))
            summary = summaries[string(mirror)]
            summary["columns"] += 1
            summary["zero_device_columns"] += all(iszero, actual)
            summary["reference_peak_gain_below_1e_6"] += peak < 1e-6
            summary["maximum_error_per_command"] = max(summary["maximum_error_per_command"],gain_error)
            if peak >= 1e-6
                summary["maximum_relative_l2_peak_gain_at_least_1e_6"] = max(
                    summary["maximum_relative_l2_peak_gain_at_least_1e_6"], e["relative_l2"])
            end
            digest = bytes2hex(sha256(reinterpret(UInt8, vec(actual))))
            println(io, join((index,mirror,local_index,peak,device_peak,norm(reference),
                e["max_abs"],gain_error,e["relative_l2"],count(!iszero,actual),digest), ','))
            index % 256 == 0 && (println("Validated command ", index, "/2403"); flush(stdout))
        end
    end
    return Dict("families"=>summaries,"columns_file"=>basename(csv),
        "columns_sha256"=>bytes2hex(sha256(read(csv))),"coefficient_m"=>Float64(coefficient),
        "command_normalized_absolute_tolerance"=>1e-5,
        "scope"=>"all2403 columns of actual prepared component pipeline; no optics/frame latency measurement")
end

function probes()
    cases = Pair{String,Vector{Float32}}[]
    push!(cases, "flat"=>zeros(Float32,2403))
    for (name,index) in (("woofer",49),("tweeter_illuminated",1138+97),
            ("tweeter_obscured",1128+97),("tip",2402),("tilt",2403))
        for sign in (1f0,-1f0)
            values=zeros(Float32,2403);values[index]=sign*20f-9
            push!(cases, name*(sign>0 ? "_positive" : "_negative")=>values)
        end
    end
    values=zeros(Float32,2403);values[[1,49,97,98,97+1138,2401,2402,2403]] .=
        Float32[5,-20,8,4,15,-6,3,-7].*1f-9
    push!(cases,"sparse_combined"=>values)
    generator=Xoshiro(731)
    push!(cases,"dense_combined"=>20f-9.*randn(generator,Float32,2403))
    return cases
end

function complete_plant!(directory,p,target,oracle)
    cpu=prepare_calibration_system(;parameters=p)
    gpu=prepare_calibration_system(;parameters=p,target,execution=CapturedGraphExecution())
    systems=(cpu,gpu)
    sequences=[step_hil_frame!(s.boundary) for s in systems]
    baseline_rates=map(s->Array(graph_output(s.graph,:photon_rate)),systems)
    result=Dict{String,Any}()
    reference=zeros(Float64,p.pupil_resolution,p.pupil_resolution)
    for (name,command) in probes()
        for (i,system) in enumerate(systems)
            old_frame=copy(hil_frame_buffer(system.boundary))
            copyto!(hil_command_buffer(system.boundary),command)
            adopt_hil_command!(system.boundary,sequences[i])
            @assert hil_frame_buffer(system.boundary)==old_frame
            sequences[i]=step_hil_frame!(system.boundary)
        end
        ORACLE.dense_opd!(reference,oracle,command)
        record=Dict{String,Any}("command"=>save_array(directory,name*"-command",command))
        for (label,system) in zip(("cpu","cuda_captured"),systems)
            opd=Array(graph_output(system.graph,:pupil_opd))
            rates=Array(graph_output(system.graph,:photon_rate))
            frame=copy(hil_frame_buffer(system.boundary))
            @assert all(isfinite,rates) && all(>=(0),rates)
            @assert all(iszero,frame[241:242,:])
            @assert isapprox(sum(rates),sum(baseline_rates[label=="cpu" ? 1 : 2]);rtol=3e-5)
            @assert isapprox(frame[1:240,:],rates.*(p.quantum_efficiency*p.exposure_duration_s);rtol=3e-5,atol=1e-12)
            e=errors(opd,reference)
            @assert e["relative_l2"] <= 2e-5
            record[label]=Dict("opd_error"=>e,"opd"=>save_array(directory,name*"-"*label*"-opd",opd),
                "rate"=>save_array(directory,name*"-"*label*"-rate",rates),
                "frame"=>save_array(directory,name*"-"*label*"-frame",frame))
        end
        cpu_rate=Array(graph_output(cpu.graph,:photon_rate))
        gpu_rate=Array(graph_output(gpu.graph,:photon_rate))
        record["rate_cpu_cuda_error"]=errors(gpu_rate,Float64.(cpu_rate))
        @assert record["rate_cpu_cuda_error"]["relative_l2"] <= 3e-4
        result[name]=record
        println("Validated full-plant probe ",name);flush(stdout)
    end
    # Calibrated angle convention: OPD coefficient c gives line-of-sight 2c/D.
    result["tiptilt_units"]=Dict("coefficient_m"=>20e-9,
        "line_of_sight_radians"=>2*20e-9/Float64(p.telescope_diameter_m),
        "relation"=>"OPD=c*x_normalized, physical pupil x=D*x_normalized/2; angle=2c/D; no mirror-surface factor")
    return result
end

function source_record(mod)
    root=dirname(dirname(pathof(mod)))
    return Dict("path"=>root,"revision"=>readchomp(`git -C $root rev-parse HEAD`),
        "status"=>readchomp(`git -C $root status --short`))
end
function main(args)
    length(args)==2 || error("usage: HARNESS EMPTY_OUTPUT_DIRECTORY HEART_MAP_DIRECTORY")
    directory=abspath(args[1]);mkpath(directory)
    isempty(readdir(directory)) || error("output directory must be empty")
    CUDA.functional() || error("functional CUDA required")
    CUDA.allowscalar(false);BLAS.set_num_threads(1);B.set_fft_provider_threads!(1)
    p=GPI2Parameters(noise=false);oracle=ORACLE.ActuationOracle(p)
    record=Dict{String,Any}("complete"=>false,"aos"=>source_record(AdaptiveOpticsSim),
        "gpi"=>source_record(GPI2Sim),"julia"=>string(VERSION),"cuda"=>string(pkgversion(CUDA)),
        "device"=>CUDA.name(CUDA.device()),"pupil_resolution"=>p.pupil_resolution,
        "modulation_points"=>p.modulation_points,"units"=>"metre OPD coefficients, additive",
        "harness_sha256"=>bytes2hex(sha256(read(@__FILE__))),
        "oracle_sha256"=>bytes2hex(sha256(read(joinpath(@__DIR__,"gpi_actuation_oracle.jl")))))
    @assert GPI2Sim.command_layout()==(woofer=1:97,tweeter=98:2401,tiptilt=2402:2403)
    for mirror in (:woofer,:tweeter)
        @assert ORACLE.source_index_map(mirror)==GPI2Sim.actuator_index_map(mirror)
        @assert ORACLE.source_grid_indices(mirror)==GPI2Sim.actuator_grid_indices(mirror)
    end
    maps=ORACLE.verify_source_maps(args[2])
    @assert all(x->x.hash_matches && x.labels_match,maps)
    record["source_maps"]=Dict(string(x.mirror)=>Dict("path"=>x.path,
        "sha256"=>x.sha256,"hash_matches"=>x.hash_matches,"labels_match"=>x.labels_match) for x in maps)
    save_record(directory,record)
    target=B.compute_device(CUDA.zeros(Float32,1))
    record["columns"]=all_columns!(directory,p,target,oracle)
    save_record(directory,record);GC.gc(true);CUDA.reclaim()
    record["plant_probes"]=complete_plant!(directory,p,target,oracle)
    record["complete"]=true;save_record(directory,record)
    println("All actuation checks complete")
end
if abspath(PROGRAM_FILE)==@__FILE__
    main(ARGS)
end
