# Usage: julia --project=<CUDA validation environment> benchmarks/gpi_runtime_cuda.jl OUTPUT_TOML
# Optional GPI_RUNTIME_SAVE_F32=1 writes only the first/last replay frame and rate.
# No RTC process, reconstruction, command allocation, or wall-clock pacing is run.
using CUDA, GPI2Sim, AdaptiveOpticsSim
using AdaptiveOpticsSim.AlgorithmGraphs
using AdaptiveOpticsSim.Backends: compute_device
import AdaptiveOpticsSim.AlgorithmGraphs as AG
using Dates, LinearAlgebra, SHA, Statistics, TOML

const OUTPUTS = (:woofer_opd, :tweeter_opd, :tiptilt_opd, :pupil_opd,
    :photon_rate, :detector_frame, :frame)
const PHYSICAL_OUTPUTS = OUTPUTS[1:5]
const WARMUP = 32
const SAMPLES = 128
const ALLOCATION_SAMPLES = 16
const REPLAY_FRAMES = 32
const RTOL = 2e-5
const ATOL = 1e-12

# HIL stages a completed frame to host, then validates and stages the same-sequence
# host command for the next frame. The command buffer stays zero throughout timing.
function exchange!(boundary)
    sequence = step_hil_frame!(boundary)
    adopt_hil_command!(boundary, sequence)
    return sequence
end
exchange_allocations(boundary) = @allocated exchange!(boundary)

function persist(path, report)
    mkpath(dirname(path))
    temporary = path * ".tmp"
    open(temporary, "w") do io
        TOML.print(io, report; sorted=true)
    end
    mv(temporary, path; force=true)
end

function command_output(command)
    try
        return strip(read(command, String))
    catch exception
        return "unavailable: " * sprint(showerror, exception)
    end
end

file_record(path) = isfile(path) ? Dict("path" => abspath(path),
    "sha256" => bytes2hex(sha256(read(path)))) : Dict("path" => abspath(path), "present" => false)

function source_record(module_)
    root = dirname(dirname(pathof(module_)))
    files = sort(filter(path -> endswith(path, ".jl"), [joinpath(directory, file)
        for folder in ("src", "ext") if isdir(joinpath(root, folder))
        for (directory, _, files) in walkdir(joinpath(root, folder)) for file in files]))
    # Include relative paths and individual hashes to make the aggregate unambiguous.
    digest_input = join((relpath(file, root) * "\0" * bytes2hex(sha256(read(file))) for file in files), "\n")
    return Dict("path" => root, "version" => string(pkgversion(module_)),
        "git_head" => command_output(`git -C $root rev-parse HEAD`),
        "git_branch" => command_output(`git -C $root branch --show-current`),
        "git_status" => command_output(`git -C $root status --short`),
        "src_ext_sha256" => bytes2hex(sha256(digest_input)),
        "project" => file_record(joinpath(root, "Project.toml")))
end

function pool_record()
    result = Dict{String,Any}()
    for name in (:used_memory, :cached_memory)
        if isdefined(CUDA, name)
            try
                result[string(name) * "_bytes"] = Int(getproperty(CUDA, name)())
            catch exception
                result[string(name) * "_unavailable"] = sprint(showerror, exception)
            end
        end
    end
    return result
end

function runtime_record()
    project = Base.active_project()
    environment = Dict(key => ENV[key] for key in ("JULIA_NUM_THREADS", "JULIA_NUM_GC_THREADS",
        "CUDA_VISIBLE_DEVICES", "OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS",
        "JULIA_CUDA_MEMORY_POOL", "JULIA_CUDA_SOFT_MEMORY_LIMIT", "JULIA_CUDA_HARD_MEMORY_LIMIT")
        if haskey(ENV, key))
    manifests = filter(path -> occursin(r"^(Julia)?Manifest.*\.toml$", basename(path)),
        readdir(dirname(project); join=true))
    return Dict("julia_version" => string(VERSION), "kernel" => string(Sys.KERNEL),
        "architecture" => string(Sys.ARCH), "machine" => Sys.MACHINE,
        "cpu" => Sys.CPU_NAME, "cpu_threads" => Sys.CPU_THREADS,
        "threads_default" => Threads.nthreads(:default),
        "threads_interactive" => Threads.nthreads(:interactive),
        "blas_threads" => BLAS.get_num_threads(), "word_size" => Sys.WORD_SIZE,
        "command" => join(vcat(Base.julia_cmd().exec, PROGRAM_FILE, ARGS), " "),
        "environment" => environment, "julia_options" => repr(Base.JLOptions()),
        "project" => file_record(project),
        "manifests" => file_record.(manifests),
        "cuda_package_version" => string(pkgversion(CUDA)),
        "cuda_versioninfo" => sprint(io -> CUDA.versioninfo(io)),
        "gpu" => command_output(`nvidia-smi --query-gpu=name,uuid,driver_version,memory.total,pstate,clocks.current.sm,clocks.current.memory,power.limit --format=csv`),
        "affinity" => command_output(`taskset -pc $(getpid())`),
        "uname" => command_output(`uname -a`),
        "script" => file_record(@__FILE__))
end

function modulation_record(system)
    modulation = AG.prepared_graph_node(system.graph, Val(:pyramid)).prepared.front_end.modulation
    @assert size(modulation.coordinates) == (240,)
    @assert size(modulation.offsets) == (2, 24)
    @assert modulation.coordinates isa CuArray{Float32}
    @assert modulation.offsets isa CuArray{Float32}
    @assert modulation.amplitude_weights isa AdaptiveOpticsSim.FixedSizeVectorDefault{Float32}
    @assert length(modulation.amplitude_weights) == 24
    bytes = sizeof(eltype(modulation.coordinates)) * length(modulation.coordinates) +
        sizeof(eltype(modulation.offsets)) * length(modulation.offsets)
    @assert bytes == 1152
    return Dict("owner_type" => string(typeof(modulation)),
        "coordinate_type" => string(typeof(modulation.coordinates)),
        "coordinate_shape" => collect(size(modulation.coordinates)),
        "offset_type" => string(typeof(modulation.offsets)),
        "offset_shape" => collect(size(modulation.offsets)),
        "amplitude_weights_type" => string(typeof(modulation.amplitude_weights)),
        "amplitude_weights_location" => "host FixedSizeArray", "amplitude_weights_count" => 24,
        "retained_modulation_device_bytes" => bytes,
        "former_complex_f32_phase_cube_bytes" => 240 * 240 * 24 * sizeof(ComplexF32),
        "storage_scope" => "modulation coordinates/offsets only; excludes propagation workspace and graph capture reservations")
end

function bindings(system)
    routing = AG.prepared_graph_node(system.graph, Val(:command_routing))
    layout = AG.prepared_graph_node(system.graph, Val(:frame_layout))
    modulation = AG.prepared_graph_node(system.graph, Val(:pyramid)).prepared.front_end.modulation
    return (hil_command_buffer(system.boundary), hil_frame_buffer(system.boundary),
        graph_input(system.graph, :command), graph_output(system.graph, Val(:frame)),
        routing.woofer, routing.tweeter, routing.tiptilt, values(routing.outputs)...,
        layout.detector_frame, layout.science, layout.padding,
        modulation.coordinates, modulation.offsets, modulation.amplitude_weights)
end

function check_frame(system)
    frame = hil_frame_buffer(system.boundary)
    @assert size(frame) == (242, 240) && eltype(frame) === Float32
    @assert size(hil_command_buffer(system.boundary)) == (2403,)
    @assert eltype(hil_command_buffer(system.boundary)) === Float32
    @assert all(isfinite, frame)
    @assert all(iszero, @view frame[241:242, :])
    @assert frame == Array(graph_output(system.graph, Val(:frame)))
    return nothing
end

snapshot(system) = NamedTuple{OUTPUTS}(map(name -> Array(graph_output(system.graph, Val(name))), OUTPUTS))

function replay(system)
    reset_hil_boundary!(system.boundary)
    @assert exchange!(system.boundary) == UInt64(1)
    check_frame(system)
    first = snapshot(system)
    snapshots = Vector{typeof(first)}(undef, REPLAY_FRAMES)
    snapshots[1] = first
    for index in 2:REPLAY_FRAMES
        @assert exchange!(system.boundary) == UInt64(index)
        check_frame(system)
        snapshots[index] = snapshot(system)
    end
    return snapshots
end

function difference(actual, expected)
    @assert size(actual) == size(expected)
    delta2 = actual2 = expected2 = maxabs = 0.0
    for index in eachindex(actual, expected)
        a, b = Float64(actual[index]), Float64(expected[index])
        delta2 += abs2(a - b)
        actual2 += abs2(a)
        expected2 += abs2(b)
        maxabs = max(maxabs, abs(a - b))
    end
    scale = max(sqrt(actual2), sqrt(expected2))
    return (relative_l2=scale == 0 ? 0.0 : sqrt(delta2) / scale,
        absolute_l2=sqrt(delta2), max_abs=maxabs,
        exact=actual == expected, passed=sqrt(delta2) <= max(ATOL, RTOL * scale))
end

function comparison(actual, expected; noisy=false)
    result = Dict{String,Any}()
    for name in OUTPUTS
        metrics = [difference(getproperty(actual[index], name), getproperty(expected[index], name))
            for index in 1:REPLAY_FRAMES]
        gate = name in PHYSICAL_OUTPUTS || !noisy
        result[string(name)] = Dict("relative_l2" => getproperty.(metrics, :relative_l2),
            "absolute_l2" => getproperty.(metrics, :absolute_l2),
            "max_abs" => getproperty.(metrics, :max_abs),
            "exact_frames" => getproperty.(metrics, :exact),
            "within_tolerance" => getproperty.(metrics, :passed), "required_gate" => gate)
    end
    return result
end

function command_probe(system)
    old = bindings(system)
    addresses = map(pointer, old)
    reset_hil_boundary!(system.boundary)
    first = nothing
    command = zeros(Float32, command_count())
    command[49], command[97 + 1128] = 20f-9, -10f-9
    command[2402:2403] .= (5f-9, -2f-9)
    differences = Float64[]
    components = Vector{typeof(snapshot(system))}(undef, 4)
    for (index, values_) in enumerate((zero(command), command, -command, zero(command)))
        if index > 1
            copyto!(hil_command_buffer(system.boundary), values_)
            adopt_hil_command!(system.boundary, UInt64(index - 1))
        end
        # A nonzero sentinel makes stale padding visible on the next replay.
        fill!(graph_output(system.graph, Val(:frame)), -99f0)
        CUDA.synchronize()
        @assert step_hil_frame!(system.boundary) == UInt64(index)
        check_frame(system)
        routing = AG.prepared_graph_node(system.graph, Val(:command_routing))
        for name in (:woofer, :tweeter, :tiptilt)
            @assert Array(getproperty(routing.outputs, name)) == values_[getproperty(command_layout(), name)]
        end
        current = snapshot(system)
        components[index] = current
        if index == 1
            first = current
        else
            push!(differences, difference(current.photon_rate, first.photon_rate).relative_l2)
        end
    end
    @assert differences[1] > 0 && differences[2] > 0
    for name in OUTPUTS[1:3]
        @assert all(iszero, getproperty(components[1], name))
        @assert any(!iszero, getproperty(components[2], name))
        @assert difference(getproperty(components[2], name), -getproperty(components[3], name)).passed
        @assert all(iszero, getproperty(components[4], name))
    end
    reset_hil_boundary!(system.boundary)
    @assert all(map((a, b) -> a === b, old, bindings(system)))
    @assert map(pointer, bindings(system)) == addresses
    @assert all(iszero, hil_command_buffer(system.boundary))
    @assert all(iszero, hil_frame_buffer(system.boundary))
    @assert all(iszero, Array(graph_input(system.graph, :command)))
    @assert step_hil_frame!(system.boundary) == UInt64(1)
    check_frame(system)
    restored = snapshot(system)
    @assert all(name -> getproperty(restored, name) == getproperty(first, name), OUTPUTS)
    return Dict("command_count" => 2403, "frame_shape" => [242, 240],
        "combined_command_m" => Dict("woofer_49" => command[49],
            "tweeter_1128" => command[97 + 1128], "tiptilt" => command[2402:2403]),
        "relative_rate_difference_from_initial" => differences,
        "routing_exact" => true, "component_sign_reversal_and_zero_return" => true,
        "reset_replay_exact" => true,
        "reset_identity_and_addresses_preserved" => true, "padding_zero" => true)
end

function save_selected(path, label, snapshots)
    records = Dict{String,Any}()
    get(ENV, "GPI_RUNTIME_SAVE_F32", "0") == "1" || return records
    directory = splitext(path)[1] * "-frames"
    mkpath(directory)
    for index in (1, REPLAY_FRAMES), name in (:frame, :photon_rate)
        array = getproperty(snapshots[index], name)
        destination = joinpath(directory, "$(label)-$(name)-$(index).f32")
        open(io -> write(io, array), destination, "w")
        records["$(name)_$(index)"] = merge(file_record(destination),
            Dict("shape" => collect(size(array)), "layout" => "Julia column major",
                "element_type" => "Float32", "endianness" => ENDIAN_BOM == 0x04030201 ? "little" : "big"))
    end
    return records
end

function run_case!(path, report, target, kind, captured, expected)
    label = kind * (captured ? "_captured" : "_stream")
    result = Dict{String,Any}("status" => "preparing", "noise" => kind == "production",
        "execution" => captured ? "CapturedGraphExecution" : "StreamGraphExecution",
        "pool_before_preparation" => pool_record())
    report["cases"][label] = result
    persist(path, report)
    parameters = kind == "production" ? GPI2Parameters() : GPI2Parameters(noise=false)
    @assert parameters.pupil_resolution == 240 && parameters.modulation_points == 24
    @assert parameters.frame_rate_hz == 2000 && parameters.atmosphere_seed == 1 && parameters.detector_seed == 2
    execution = captured ? CapturedGraphExecution() : StreamGraphExecution()
    preparation_start = time_ns()
    system = kind == "production" ? prepare_hil_system(; parameters, target, execution) :
        prepare_calibration_system(; parameters, target, execution)
    CUDA.synchronize()
    result["preparation_ns"] = Int(time_ns() - preparation_start)
    result["pool_after_preparation"] = pool_record()
    result["parameters"] = Dict(string(name) => (isnothing(getfield(parameters, name)) ? "nothing" :
        getfield(parameters, name) isa Tuple ? collect(getfield(parameters, name)) : getfield(parameters, name))
        for name in fieldnames(typeof(parameters)))
    result["frame_schema"] = frame_schema(parameters)
    result["command_schema"] = command_schema()
    result["modulation"] = modulation_record(system)
    result["captured_node_count"] = captured_graph_node_count(system.graph)
    @assert result["captured_node_count"] == (captured ? (kind == "production" ? 11 : 10) : 0)
    result["status"] = "correctness"
    persist(path, report)
    snapshots = replay(system)
    result["replay_frames"] = REPLAY_FRAMES
    result["replay_frame_evolution"] = [snapshots[index].frame != snapshots[1].frame for index in 1:REPLAY_FRAMES]
    result["selected_raw_arrays"] = save_selected(path, label, snapshots)
    if captured
        reset_hil_boundary!(system.boundary)
        exact = Bool[]
        for index in 1:REPLAY_FRAMES
            @assert exchange!(system.boundary) == UInt64(index)
            check_frame(system)
            current = snapshot(system)
            push!(exact, all(name -> getproperty(current, name) == getproperty(snapshots[index], name), OUTPUTS))
        end
        result["seeded_reset_exact_all_outputs"] = exact
        result["stream_comparison"] = comparison(snapshots, expected; noisy=parameters.noise)
        result["comparison_rtol"] = RTOL
        result["comparison_atol_l2"] = ATOL
        persist(path, report)
        @assert all(exact)
        for values_ in values(result["stream_comparison"])
            values_["required_gate"] && @assert all(values_["within_tolerance"])
        end
    end
    result["command_probe"] = command_probe(system)
    result["pool_after_replay"] = pool_record()
    result["status"] = "measuring"
    persist(path, report)
    reset_hil_boundary!(system.boundary)
    # Compile the allocation observation wrapper separately from the 32 warmups.
    exchange_allocations(system.boundary)
    for _ in 1:WARMUP
        exchange!(system.boundary)
    end
    samples = Vector{Int}(undef, SAMPLES)
    for index in eachindex(samples)
        start = time_ns()
        exchange!(system.boundary)
        samples[index] = Int(time_ns() - start)
    end
    allocations = [exchange_allocations(system.boundary) for _ in 1:ALLOCATION_SAMPLES]
    result["latency_ns"] = Dict("samples" => samples, "median" => median(samples),
        "p95" => quantile(samples, 0.95), "maximum" => maximum(samples))
    result["host_allocated_bytes"] = allocations
    result["warmup_frames"] = WARMUP
    result["allocation_observer_compile_frames"] = 1
    result["completed_measured_frames"] = SAMPLES
    result["allocation_observations"] = ALLOCATION_SAMPLES
    result["pool_after_measurement"] = pool_record()
    result["captured_allocation_gate_passed"] = !captured || all(iszero, allocations)
    persist(path, report)
    captured && @assert all(iszero, allocations)
    result["status"] = "complete"
    persist(path, report)
    return captured ? nothing : snapshots
end

function main()
    length(ARGS) == 1 || error("Usage: gpi_runtime_cuda.jl OUTPUT_TOML")
    path = abspath(only(ARGS))
    CUDA.functional() || error("CUDA hardware is required")
    CUDA.allowscalar(false)
    target = compute_device(CUDA.zeros(Float32, 1))
    report = Dict{String,Any}("started_utc" => string(now(UTC)), "status" => "running",
        "runtime" => runtime_record(), "sources" => Dict("GPI2Sim" => source_record(GPI2Sim),
            "AdaptiveOpticsSim" => source_record(AdaptiveOpticsSim)), "cases" => Dict{String,Any}(),
        "measurement" => Dict("load_model" => "single outstanding lockstep service time",
            "timed_boundary" => "step_hil_frame! completion and host frame staging, followed by same-sequence adopt_hil_command! validation and command staging",
            "commands" => "zero Float32 metre-OPD commands; no RTC control algorithm",
            "excluded" => "external RTC, transport, wall pacing, correctness comparisons and artifact I/O",
            "virtual_model_rate_hz" => 2000, "wall_clock_rate_claim" => false,
            "pool_interpretation" => "observations only; capture reserve does not establish pool stability",
            "qualification" => "private local software measurement; no deployed latency or instrument fidelity qualification"))
    persist(path, report)
    try
        for kind in ("calibration", "production")
            expected = nothing
            for captured in (false, true)
                try
                    expected = run_case!(path, report, target, kind, captured, expected)
                finally
                    GC.gc(true)
                    CUDA.reclaim()
                end
                label = kind * (captured ? "_captured" : "_stream")
                report["cases"][label]["pool_after_owner_release"] = pool_record()
                persist(path, report)
            end
        end
        report["status"] = "complete"
    catch exception
        report["status"] = "failed"
        report["error"] = sprint(showerror, exception, catch_backtrace())
        rethrow()
    finally
        report["finished_utc"] = string(now(UTC))
        persist(path, report)
    end
    println(path)
end

abspath(PROGRAM_FILE) == (@__FILE__) && main()
