module GPIClosedLoopInputs

using FFTW
using LinearAlgebra
using Random

include(joinpath(@__DIR__, "gpi_actuation_oracle.jl"))
import .GPIActuationOracle

export build_basis, frozen_flow_inputs, sample_grid, pupil_rms

"""Piston-removed pupil RMS, accumulated in Float64 (same units as `opd`)."""
function pupil_rms(opd::AbstractMatrix, mask::AbstractMatrix{Bool})
    axes(opd) == axes(mask) || throw(DimensionMismatch("OPD and mask axes must match"))
    count = 0
    mean = 0.0
    sum_squares = 0.0
    for index in eachindex(opd, mask)
        mask[index] || continue
        count += 1
        delta = Float64(opd[index]) - mean
        mean += delta / count
        sum_squares += delta * (Float64(opd[index]) - mean)
    end
    count > 0 || throw(ArgumentError("pupil must contain at least one sample"))
    return sqrt(max(0.0, sum_squares / count))
end

# Real Zernike-shaped command patterns. Their propagated optical products are
# neither exact Zernikes nor an orthogonal modal basis.
function _shape(n::Int, m::Int, x::Float64, y::Float64)
    radius = hypot(x, y)
    radius <= 1 || return 0.0
    order = abs(m)
    radial = 0.0
    for s in 0:((n - order) ÷ 2)
        radial += (-1)^s * factorial(n - s) /
            (factorial(s) * factorial((n + order) ÷ 2 - s) *
             factorial((n - order) ÷ 2 - s)) * radius^(n - 2s)
    end
    angle = atan(y, x)
    return radial * (m < 0 ? sin(order * angle) : cos(order * angle))
end

function _fill_shape!(command, mirror::Symbol, n::Int, m::Int)
    labels = GPIActuationOracle.source_index_map(mirror)
    k = size(labels, 1)
    pitch = mirror === :woofer ? 2 / 10 : 2 / 43
    offset = mirror === :woofer ? 0 : 97
    for row in 1:k, column in 1:k
        label = labels[row, column]
        iszero(label) && continue
        x = (column - (k + 1) / 2) * pitch
        y = ((k + 1) / 2 - row) * pitch
        command[offset + label] = _shape(n, m, x, y)
    end
    return command
end

"""
    build_basis(parameters; reference_resolution=720)

Prepare 35 command patterns: normalized x/y tip/tilt, seven woofer patterns
(n=2:3), then 26 tweeter patterns (n=4:7), in ascending n and m=-n:2:n.
Each pattern occupies only its command family. The independent analytical
actuation oracle normalizes each propagated annular OPD to unit piston-removed
RMS. Multiplying a column by a coefficient in metres gives commands and OPD in
metres. The real Zernike shapes describe actuator commands, not exact optical
Zernikes; no orthogonalization or measured calibration is implied.
"""
function build_basis(p; reference_resolution::Integer=720)
    oracle = GPIActuationOracle.ActuationOracle(;
        resolution=reference_resolution,
        central_obstruction_ratio=p.central_obstruction_ratio,
        woofer_coupling=p.woofer_coupling, tweeter_coupling=p.tweeter_coupling)
    commands = zeros(Float32, 2403, 35)
    opd = Matrix{Float32}(undef, reference_resolution^2, 35)
    labels = String["tiptilt_x", "tiptilt_y"]
    families = Symbol[:tiptilt, :tiptilt]
    commands[2402, 1] = 1
    commands[2403, 2] = 1
    column = 2
    for (family, orders) in ((:woofer, 2:3), (:tweeter, 4:7))
        for n in orders, m in -n:2:n
            column += 1
            _fill_shape!(view(commands, :, column), family, n, m)
            push!(labels, "$(family)_n$(n)_m$(m)")
            push!(families, family)
        end
    end
    temporary = zeros(Float64, reference_resolution, reference_resolution)
    for mode in axes(commands, 2)
        command = view(commands, :, mode)
        GPIActuationOracle.dense_opd!(temporary, oracle, command)
        rms = pupil_rms(temporary, oracle.pupil)
        rms > 0 || throw(ArgumentError("mode $(labels[mode]) has zero pupil RMS"))
        command ./= rms
        # Re-evaluate rounded Float32 commands so products match delivered inputs.
        GPIActuationOracle.dense_opd!(temporary, oracle, command)
        opd[:, mode] .= vec(temporary)
    end
    return (; commands, opd, mask=copy(oracle.pupil), labels, families)
end

function _pupil(resolution::Int, obstruction::Float64)
    coordinates = [(2i - resolution - 1) / resolution for i in 1:resolution]
    return BitMatrix([obstruction^2 <= x^2 + y^2 <= 1 for x in coordinates, y in coordinates])
end

"""
    frozen_flow_inputs(; resolution=720, frames=320, dt=0.0005,
        diameter=7.77, L0=25, wind=(10., 0.), seed=823, rms_m=400e-9,
        cutoff=20, obstruction=1.024/7.77)

Independent periodic, band-limited von Kármán-shaped OPD screens in metres.
Axis 1 is x, axis 2 is y; cell centers are (2i−N−1)D/(2N). Fourier amplitudes
scale as (f²+1/L0²)^(-11/12), with conjugate Gaussian coefficients and zero DC.
Advection is screen(x−vₓt,y−vᵧt). One scale sets the first annular,
piston-removed RMS; later frames retain the same Fourier amplitudes.

Returned compact coefficients (metres) have axes indexed in the order
`metadata.wavenumbers` and reconstruct the field by Σ c[k] exp(2πi k⋅x/D).
This is a finite periodic disturbance model, not a full r₀/seeing prescription.
"""
function frozen_flow_inputs(; resolution::Integer=720, frames::Integer=320,
    dt::Real=0.0005, diameter::Real=7.77, L0::Real=25,
    wind=(10.0, 0.0), seed::Integer=823, rms_m::Real=400e-9,
    cutoff::Integer=20, obstruction::Real=1.024 / 7.77)
    n, count, limit = Int(resolution), Int(frames), Int(cutoff)
    n > 0 && count > 0 || throw(ArgumentError("resolution and frames must be positive"))
    1 <= limit < n / 2 || throw(ArgumentError("cutoff must lie between 1 and the Nyquist frequency"))
    step, period, outer_scale, rms, rho = Float64.((dt, diameter, L0, rms_m, obstruction))
    all(isfinite, (step, period, outer_scale, rms, rho)) || throw(ArgumentError("parameters must be finite"))
    step > 0 && period > 0 && outer_scale > 0 && rms > 0 || throw(ArgumentError("time, lengths and RMS must be positive"))
    0 <= rho < 1 || throw(ArgumentError("obstruction must lie in [0, 1)"))
    length(wind) == 2 || throw(ArgumentError("wind must contain x and y velocities"))
    velocity = (Float64(wind[1]), Float64(wind[2]))
    all(isfinite, velocity) || throw(ArgumentError("wind must be finite"))
    wavenumbers = collect(-limit:limit)
    coefficients = zeros(ComplexF64, 2limit + 1, 2limit + 1)
    rng = Xoshiro(seed)
    for ky in wavenumbers, kx in wavenumbers
        (kx > 0 || (kx == 0 && ky > 0)) || continue
        f_squared = (kx^2 + ky^2) / period^2
        amplitude = (f_squared + 1 / outer_scale^2)^(-11 / 12)
        value = amplitude * complex(randn(rng), randn(rng)) / sqrt(2)
        coefficients[kx + limit + 1, ky + limit + 1] = value
        coefficients[-kx + limit + 1, -ky + limit + 1] = conj(value)
    end
    screens = Array{Float32}(undef, n, n, count)
    spectrum = zeros(ComplexF64, n, n)
    transform = plan_ifft!(spectrum)
    mask = _pupil(n, rho)
    normalization_scale = 1.0
    for frame in 1:count
        fill!(spectrum, 0)
        t = (frame - 1) * step
        for (j, ky) in enumerate(wavenumbers), (i, kx) in enumerate(wavenumbers)
            center_phase = (kx + ky) * (1 - n) / (2n)
            wind_phase = -(kx * velocity[1] + ky * velocity[2]) * t / period
            spectrum[mod(kx, n) + 1, mod(ky, n) + 1] =
                coefficients[i, j] * cispi(2 * (center_phase + wind_phase))
        end
        transform * spectrum
        if frame == 1
            first_screen = real.(spectrum) .* n^2
            normalization_scale = rms / pupil_rms(first_screen, mask)
            coefficients .*= normalization_scale
            screens[:, :, frame] .= first_screen .* normalization_scale
        else
            screens[:, :, frame] .= real.(spectrum) .* n^2
        end
    end
    metadata = (; seed, normalization_scale, period_m=period,
        cutoff_cycles_per_aperture=limit, dt_s=step, wind_m_s=velocity,
        outer_scale_m=outer_scale, requested_first_frame_rms_m=rms,
        obstruction_ratio=rho, wavenumbers,
        boundary=:periodic, spectrum=:band_limited_von_karman,
        amplitude_exponent=-11 / 12, power_exponent=-11 / 6,
        coordinate_convention=:cell_centered_x_first_y_second,
        normalization=:first_frame_annular_piston_removed_rms)
    return (; screens, metadata, spectral_coefficients=coefficients)
end

"""Copy exactly coincident cell centers; the reference/target ratio must be odd."""
function sample_grid(screens::AbstractArray{T, 3}, resolution::Integer) where {T}
    size(screens, 1) == size(screens, 2) || throw(DimensionMismatch("screens must be square"))
    target = Int(resolution)
    target > 0 || throw(ArgumentError("resolution must be positive"))
    ratio, remainder = divrem(size(screens, 1), target)
    remainder == 0 && isodd(ratio) || throw(ArgumentError("reference/target resolution ratio must be an odd integer"))
    indices = ((ratio + 1) ÷ 2):ratio:size(screens, 1)
    return copy(screens[indices, indices, :])
end

end # module
