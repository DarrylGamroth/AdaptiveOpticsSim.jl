using TOML, SHA, LinearAlgebra
BLAS.set_num_threads(1)
include(joinpath(get(ENV,"GPI_VERIFY_REPO","/home/dgamroth/workspaces/codex/GPI2Sim-closed-loop"),"benchmarks","gpi_actuation_oracle.jl"))
root=get(ENV,"GPI_VERIFY_DIR","/home/dgamroth/workspaces/codex/gpi-closed-loop-evidence/final")
d=TOML.parsefile(joinpath(root,"validation.toml"))
C=reshape(reinterpret(Float32,read(joinpath(root,d["basis_commands"]["file"]))),2403,35)
o=GPIActuationOracle.ActuationOracle(resolution=720,central_obstruction_ratio=Float32(1.024/7.77),woofer_coupling=Float32(.3),tweeter_coupling=Float32(.15))
H=zeros(Float32,720*720,35);tmp=zeros(720,720)
for i in 1:35
 GPIActuationOracle.dense_opd!(tmp,o,view(C,:,i));H[:,i].=vec(tmp)
end
h=bytes2hex(sha256(reinterpret(UInt8,vec(H))))
@assert h==d["basis_opd_fine"]["sha256"]
open(io->write(io,H),get(ENV,"GPI_VERIFY_BASIS","/tmp/gpi-basis-oracle.f32"),"w")
println("Reconstructed Float32 basis SHA256 matches: ",h)
