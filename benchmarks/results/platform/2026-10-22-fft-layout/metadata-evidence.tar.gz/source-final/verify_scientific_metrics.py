import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import numpy as np, pathlib, tomllib, hashlib, json
root=pathlib.Path(os.environ.get('GPI_VERIFY_DIR','/home/dgamroth/workspaces/codex/gpi-closed-loop-evidence/final'))
repo=pathlib.Path(os.environ.get('GPI_VERIFY_REPO','/home/dgamroth/workspaces/codex/GPI2Sim-closed-loop'))
d=tomllib.loads((root/'validation.toml').read_text())
report={'complete':d['complete'],'source_checks':{},'cases':{},'raw_digest_count':0}
def arr(base,m):
 p=base/m['file'];b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==m['sha256'],str(p)
 report['raw_digest_count']+=1
 return np.frombuffer(b,dtype='<f4' if m['eltype']=='Float32' else '<f8').reshape(m['shape'],order='F')
for key,name in [('harness_sha256','gpi_closed_loop_cuda.jl'),('inputs_sha256','gpi_closed_loop_inputs.jl')]:
 report['source_checks'][name]=hashlib.sha256((repo/'benchmarks'/name).read_bytes()).hexdigest()==d[key]
 assert report['source_checks'][name]
C=arr(root,d['basis_commands']).astype(float);Gsaved=arr(root,d['basis_gram']);N=720
x=(2*np.arange(1,N+1)-N-1)/N
rho=float(np.float32(1.024/7.77)); mask=(x[:,None]**2+x[None,:]**2>=rho**2)&(x[:,None]**2+x[None,:]**2<=1)
H=np.zeros((N*N,35),dtype=np.float32,order='F')
for k,pitch,coupling,offset in [(11,2/10,float(np.float32(.3)),0),(48,2/43,float(np.float32(.15)),97)]:
 sigma=pitch/np.sqrt(-2*np.log(coupling)); B=np.exp(-(x[:,None]-(np.arange(1,k+1)-(k+1)/2)*pitch)**2/(2*sigma*sigma))
 labels=np.zeros((k,k),int)
 if k==48: labels=np.arange(1,2305).reshape(48,48)
 else:
  widths=[5,7,9,11,11,11,11,11,9,7,5]
  for row,w in enumerate(widths):labels[row,(11-w)//2:(11+w)//2]=np.arange(1+sum(widths[row+1:]),1+sum(widths[row+1:])+w)
 for j in range(35):
  mat=np.zeros((k,k))
  for row,col in zip(*np.nonzero(labels)):mat[col,k-1-row]=C[offset+labels[row,col]-1,j]
  v=(B@mat@B.T)*mask
  H[:,j]+=(v.astype(np.float32)).ravel(order='F')
for j in range(35):
 v=(C[2401,j]*x[:,None]+C[2402,j]*x[None,:])*mask
 H[:,j]+=v.astype(np.float32).ravel(order='F')
report['basis_reconstruction_sha_exact']=hashlib.sha256(H.tobytes(order='F')).hexdigest()==d['basis_opd_fine']['sha256']
Hj=np.fromfile(os.environ.get('GPI_VERIFY_BASIS','/tmp/gpi-basis-oracle.f32'),dtype='<f4').reshape((N*N,35),order='F')
assert hashlib.sha256(Hj.tobytes(order='F')).hexdigest()==d['basis_opd_fine']['sha256']
report['julia_oracle_basis_sha_exact']=True
report['independent_python_basis_max_abs_difference']=float(np.max(np.abs(Hj-H)))
H=Hj
Hm=H[mask.ravel(order='F'),:].astype(float);means=Hm.mean(axis=0); Hc=Hm-means;G=Hc.T@Hc/len(Hc)
report['gram_max_abs_error']=float(np.max(np.abs(G-Gsaved)));assert report['gram_max_abs_error']<1e-12
report['basis_rms_max_deviation']=float(np.max(np.abs(np.sqrt(np.diag(G))-1)))
assert np.all(C[:2401,:2]==0) and np.all(C[97:,2:9]==0) and np.all(C[:97,9:]==0) and np.all(C[2401:,9:]==0)
coeff=arr(root,d['spectral_real'])+1j*arr(root,d['spectral_imag']);assert np.all(coeff==np.conj(coeff[::-1,::-1]))
ks=np.array(d['disturbance']['wavenumbers']);kx=ks[:,None];ky=ks[None,:]
qstat=np.array(d['static_coefficients_m']);stat=(H.astype(float)@qstat).astype(np.float32).reshape((N,N),order='F')
def stats(a):
 a=a.ravel(order='F')[mask.ravel(order='F')].astype(float); a-=a.mean();p=Hc.T@a/len(a);power=a@a/len(a);ideal=-np.linalg.solve(G,p);floor=max(0,power+p@ideal)
 return power,p,ideal,floor
st=stats(stat);dyn=[]
for frame in range(d['frames']):
 t=max(frame-64,0)*.0005
 spec=np.zeros((N,N),complex); phase=(kx+ky)*(1-N)/(2*N)-kx*10*t/7.77
 spec[np.mod(ks,N)[:,None],np.mod(ks,N)[None,:]]=coeff*np.exp(2j*np.pi*phase)
 a=(np.fft.ifft2(spec).real*N*N).astype(np.float32)
 a=(a+(H[:,0].reshape((N,N),order='F')*(20e-9*np.sin(2*np.pi*60*t))).astype(np.float64)).astype(np.float32)
 a=(a+(H[:,1].reshape((N,N),order='F')*(15e-9*np.sin(2*np.pi*90*t))).astype(np.float64)).astype(np.float32)
 dyn.append(stats(a))
cal={}
for name in ['default','fine','transfer']:
 base=root/name; f=base/'validation.toml'
 if not f.exists():continue
 case=tomllib.loads(f.read_text());c=case['calibration']
 D=arr(base,c['interaction_per_m']);half=arr(base,c['half_amplitude_interaction_per_m']);R=arr(base,c['reconstructor_m']);flat=arr(base,c['flat']);flux=float(np.sum(flat,dtype=float));s=np.linalg.svd(D,compute_uv=False)
 rd=np.linalg.norm(R@D-np.eye(35))/np.sqrt(35);rank=int(np.sum(s>=s[0]*c['relative_cutoff']));assert rank==35 and rd<1e-12
 assert np.max(np.abs(s-np.array(c['singular_values_per_m']))/s)<1e-12
 cal[name]=(D,R,flat,flux)
 actualR=cal['default'][1] if name=='transfer' else R
 spectral=float(np.max(np.abs(np.linalg.eigvals(np.eye(35)-float(np.float32(.35))*actualR@D))))
 out={'retained_rank':rank,'condition_number':float(s[0]/s[-1]),'RD_error':float(rd),'spectral_radius':spectral,'half_amplitude_relative_l2':float(np.linalg.norm(half-D)/np.linalg.norm(half)),'runs':{}}
 assert abs(spectral-case['linear_spectral_radius'])<1e-12
 for label,r in case['runs'].items():
  path=base/label; used=arr(path,r['controller_coefficients_used']);following=arr(path,r['controller_coefficients_next']);last=arr(path,r['last_frame'])
  assert np.array_equal(used[:,1:],following[:,:-1]);assert np.all(used[:,0]==0); assert np.all(last[240:,:]==0)
  ds=[st]*128 if label=='static' else dyn
  residual=[];control=[];floor=[];power=[]
  for i,(pw,p,ideal,fl) in enumerate(ds):
   q=used[:,i].astype(float);residual.append(np.sqrt(max(0,pw+2*q@p+q@G@q)));err=q-ideal;control.append(np.sqrt(err@G@err));floor.append(np.sqrt(fl));power.append(np.sqrt(pw))
  errors={}
  for key,a in [('common_fine_residual_rms_m',residual),('controlled_error_rms_m',control),('all_mode_fitting_floor_rms_m',floor),('common_fine_open_rms_m',power)]:
   errors[key]=float(np.max(np.abs(np.array(r[key])-a))); assert errors[key]<2e-13,(name,label,key,errors[key])
  # Julia flat ./ flux preserves Float32 broadcast output since Float32 / Float64 gives Float64?
  # Constructor explicitly casts the resulting reference to Float32.
  invflux=float(np.float32(1/flux));reference=(flat.astype(float)/flux).astype(np.float32).astype(float)
  measurement=last.ravel(order='F').astype(float)*invflux-reference.ravel(order='F')
  camera_error=float(np.linalg.norm(measurement));assert abs(camera_error-r['normalized_camera_error_l2'][-1])<1e-14
  cpu_next=np.clip(used[:,-1].astype(float)-r['gain']*(actualR.astype(np.float32).astype(float)@measurement),-r['modal_limit_m'],r['modal_limit_m'])
  parity=float(np.max(np.abs(cpu_next-following[:,-1]))); assert parity<5e-12
  # Exact Float32 coefficient synthesis can differ by reduction order.
  cmdmax=float(np.max(np.abs(C.astype(np.float32)@used)));assert abs(cmdmax-r['physical_command_max_abs_m'])<2e-12
  sat=int(np.sum(np.abs(following)>=r['modal_limit_m']));assert sat==r['saturation_samples']
  tail=float(np.sqrt(np.mean(np.array(residual[-64:])**2)));assert abs(tail-r['tail_residual_rms_m'])<2e-13
  service=r['service'];samples=service['samples_ns'];assert np.median(samples)==service['median_ns'] and max(samples)==service['maximum_ns'];assert abs(np.quantile(samples,.9)-service['p90_ns'])<1e-5;assert sum(t>500000 for t in samples)==service['model_period_exceedances']
  for trial in r.get('uninterrupted_service_trials',[]):
   ss=trial['samples_ns'];assert len(ss)==64 and np.median(ss)==trial['median_ns'] and max(ss)==trial['maximum_ns'];assert abs(np.quantile(ss,.9)-trial['p90_ns'])<1e-5;assert sum(t>500000 for t in ss)==trial['model_period_exceedances']
  out['runs'][label]={'metric_max_abs_errors_m':errors,'tail_residual_nm':tail*1e9,'tail_floor_nm':r['tail_floor_rms_m']*1e9,'tail_open_nm':r['tail_open_rms_m']*1e9,'last_camera_error':camera_error,'last_update_parity_m':parity,'reported_all_frame_update_max_m':r['cpu_gpu_update_max_abs_m'],'saturation_samples':sat,'physical_command_max_m':cmdmax,'own_vs_common_max_nm':float(np.max(np.abs(np.array(r['own_grid_residual_rms_m'])-residual)))*1e9,'host_allocations':r.get('host_allocation_bytes'), 'uninterrupted_medians_ms':[t['median_ns']/1e6 for t in r.get('uninterrupted_service_trials',[])]}
 report['cases'][name]=out
pathlib.Path('/tmp/gpi-independent-review-'+root.name+'.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
