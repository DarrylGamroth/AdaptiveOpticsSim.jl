from pathlib import Path
import subprocess,os,time,json,threading
r=Path(__file__).parent;repo=r.parent/'AdaptiveOpticsSim-fft-layout'
env=os.environ|{'JULIA_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1'}
stop=threading.Event()
def telemetry():
 with (r/'probe-telemetry.csv').open('w') as f:
  while not stop.is_set():
   subprocess.run(['nvidia-smi','--query-gpu=timestamp,pstate,temperature.gpu,power.draw,clocks.sm,clocks.mem,utilization.gpu,utilization.memory,memory.used','--format=csv,noheader,nounits'],stdout=f,stderr=subprocess.STDOUT)
   f.flush();stop.wait(2)
thread=threading.Thread(target=telemetry);thread.start()
try:
 for layout,case,batches in [('native','gpi_fine','4,8,16'),('native','copper_fine','2,4,8,16'),('axis','gpi_fine','4,16'),('axis','copper_fine','2,16'),('transpose','gpi_fine','4,16'),('transpose','copper_fine','2,16')]:
  label=layout+'-'+case
  extra={'AOS_FFT_LAYOUT':layout,'AOS_FFT_BATCHES':batches}
  cmd=['taskset','-c','2','julia','--startup-file=no','--threads=1','--project='+str(r/'env'),str(repo/'benchmarks/sweep_fft_layout_cuda.jl'),str(r/(label+'.toml')),case]
  with (r/'commands.jsonl').open('a') as f:f.write(json.dumps({'label':label,'command':cmd,'extra':extra})+'\n')
  print('START',label,flush=True)
  with (r/(label+'.log')).open('w') as f:subprocess.run(cmd,env=env|extra,stdout=f,stderr=subprocess.STDOUT,check=True)
  print('DONE',label,flush=True)
finally:
 stop.set();thread.join()
