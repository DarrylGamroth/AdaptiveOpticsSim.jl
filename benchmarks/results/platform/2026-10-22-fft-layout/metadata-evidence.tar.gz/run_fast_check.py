from pathlib import Path
import subprocess,os,time,json,tomllib,hashlib
r=Path(__file__).resolve().parent;repo=r.parent/'AdaptiveOpticsSim-fft-layout'
while not (r/'scientific-replay.json').exists():
 if (r/'finish.log').exists() and 'Traceback' in (r/'finish.log').read_text():raise RuntimeError('Finish pipeline failed')
 time.sleep(2)
env=os.environ|{'JULIA_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','AOS_PROFILE_WARMUPS':'24','AOS_PROFILE_SAMPLES':'32'}
summary={}
for case in ('copper_fast','copper_default'):
 label='production-after-'+case;out=r/(label+'.toml')
 cmd=['taskset','-c','2','julia','--startup-file=no','--threads=1','--project='+str(r/'env'),str(repo/'benchmarks/profile_physical_pyramid_cuda.jl'),str(out),case]
 with (r/'commands.jsonl').open('a') as f:f.write(json.dumps({'label':label,'command':cmd,'extra':{k:env[k] for k in ('JULIA_NUM_THREADS','OPENBLAS_NUM_THREADS','AOS_PROFILE_WARMUPS','AOS_PROFILE_SAMPLES')}})+'\n')
 with (r/(label+'.log')).open('w') as f:subprocess.run(cmd,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 d=tomllib.loads(out.read_text());old=tomllib.loads((r.parent/'aos-pupil-reuse-evidence'/('after-'+case+'.toml')).read_text())
 assert all(x==0 for x in d['host_allocated_bytes'])
 rate=out.with_name(d['rate_file']);assert hashlib.sha256(rate.read_bytes()).hexdigest()==d['output_sha256']
 assert d['output_sha256']==old['output_sha256'],case
 summary[case]={'current_median_ms':d['median_ms'],'old_campaign_median_ms':old['median_ms'],'rate_identical_to_previous':True,'host_allocation_bytes':d['host_allocated_bytes'],'case':d['case'],'padded_side':d['padded_side'],'batch':d['batch'],'scope':d['boundary'],'timing_comparison_scope':'Current sanity check versus earlier campaign, not an interleaved causal performance comparison'}
(r/'normal-sampling-check.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
