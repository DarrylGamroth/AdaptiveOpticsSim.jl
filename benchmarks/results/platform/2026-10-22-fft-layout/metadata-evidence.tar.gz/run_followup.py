from pathlib import Path
import subprocess,os,time,json,tomllib
r=Path(__file__).parent;repo=r.parent/'AdaptiveOpticsSim-fft-layout'
env=os.environ|{'JULIA_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1'}
while Path('/proc/1512929').exists():time.sleep(1)
for name in ('native-gpi_fine','native-copper_fine','axis-gpi_fine','axis-copper_fine','transpose-gpi_fine','transpose-copper_fine'):
 assert tomllib.loads((r/(name+'.toml')).read_text())['complete']
def run(label,project,script,args,extra={}):
 cmd=['taskset','-c','2','julia','--startup-file=no','--threads=1','--project='+str(project),str(script)]+list(map(str,args))
 print('START',label,flush=True)
 with (r/'commands.jsonl').open('a') as f:f.write(json.dumps({'label':label,'command':cmd,'extra':extra})+'\n')
 with (r/(label+'.log')).open('w') as f:subprocess.run(cmd,env=env|extra,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',label,flush=True)
run('test-tiled-transpose',r/'env',repo/'benchmarks/test_fft_transpose_cuda.jl',[],{'AOS_FFT_TRANSPOSE':'tiled'})
run('cuda-policy',r/'env',repo/'test/cuda/modulation_batch_policy.jl',[])
for mode in ('transpose','pair'):
 for case in ('gpi_fine','copper_fine'):
  label='tiled-'+mode+'-'+case
  run(label,r/'env',repo/'benchmarks/sweep_fft_layout_cuda.jl',[r/(label+'.toml'),case],
      {'AOS_FFT_LAYOUT':'native' if mode=='pair' else 'transpose','AOS_FFT_PAIR':'1' if mode=='pair' else '0','AOS_FFT_TRANSPOSE':'tiled','AOS_FFT_BATCHES':'16'})
run('copper-before',r/'baseline-copper-env',repo/'benchmarks/validate_fine_fft_copper_cuda.jl',[r.parent/'REVOLTCopperSim-pupil-tilt',r/'copper-before'])
