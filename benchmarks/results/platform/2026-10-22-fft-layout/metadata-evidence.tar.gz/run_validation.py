from pathlib import Path
import subprocess,os,time,json,tomllib,threading
r=Path(__file__).parent;repo=r.parent/'AdaptiveOpticsSim-fft-layout'
env=os.environ|{'JULIA_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1'}
while Path('/proc/1535797').exists():time.sleep(1)
assert (r/'copper-before/closed-loop.toml').exists()
assert tomllib.loads((r/'copper-before/validation.toml').read_text())['complete']
stop=threading.Event()
def telemetry():
 with (r/'validation-telemetry.csv').open('w') as f:
  while not stop.is_set():
   subprocess.run(['nvidia-smi','--query-gpu=timestamp,pstate,temperature.gpu,power.draw,clocks.sm,clocks.mem,utilization.gpu,utilization.memory,memory.used','--format=csv,noheader,nounits'],stdout=f,stderr=subprocess.STDOUT)
   f.flush();stop.wait(2)
thread=threading.Thread(target=telemetry);thread.start()
def run(label,project,script,args=[],extra={},prefix=[]):
 cmd=prefix+['taskset','-c','2','julia','--startup-file=no','--threads=1','--project='+str(project),str(script)]+list(map(str,args))
 print('START',label,flush=True)
 with (r/'commands.jsonl').open('a') as f:f.write(json.dumps({'label':label,'command':cmd,'extra':extra})+'\n')
 with (r/(label+'.log')).open('w') as f:subprocess.run(cmd,env=env|extra,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',label,flush=True)
try:
 run('paired-storage',r/'env',repo/'test/cuda/fft_layout.jl')
 run('native-storage',r/'env',repo/'test/cuda/modulation_storage.jl')
 run('modulation-batches',r/'env',repo/'test/cuda/modulation_batches.jl')
 run('captured-storage',r/'env',repo/'test/cuda/captured_storage.jl')
 run('gpi-complete',r/'env',r.parent/'GPI2Sim-pupil-tilt/benchmarks/test_gpi_closed_loop_cuda.jl')
 for round in (1,2):
  for case in ('gpi_fine','copper_fine'):
   for version in (('before','after') if round==1 else ('after','before')):
    project=r/'baseline-copper-env' if version=='before' else r/'env'
    label=f'production-{version}-{case}-r{round}'
    run(label,project,repo/'benchmarks/profile_physical_pyramid_cuda.jl',[r/(label+'.toml'),case],{'AOS_PROFILE_WARMUPS':'24','AOS_PROFILE_SAMPLES':'32'})
 for case in ('gpi_fine','copper_fine'):
  for version in ('before','after'):
   label=f'trace-{version}-{case}'
   prefix=['nsys','profile','--trace=cuda','--sample=none','--cpuctxsw=none','--cuda-graph-trace=node','--capture-range=cudaProfilerApi','--capture-range-end=stop','--force-overwrite=true','--output='+str(r/label)]
   run(label,r/'baseline-copper-env' if version=='before' else r/'env',repo/'benchmarks/profile_physical_pyramid_cuda.jl',[r/(label+'.toml'),case],{'AOS_PROFILE_EXTERNAL':'1','AOS_PROFILE_WARMUPS':'4','AOS_PROFILE_SAMPLES':'1'},prefix)
   with (r/(label+'-stats.log')).open('w') as f:subprocess.run(['nsys','stats','--report=cuda_gpu_kern_sum,cuda_gpu_mem_time_sum','--format=csv',str(r/(label+'.nsys-rep'))],stdout=f,stderr=subprocess.STDOUT,check=True)
 run('copper-after',r/'copper-env',repo/'benchmarks/validate_fine_fft_copper_cuda.jl',[r.parent/'REVOLTCopperSim-pupil-tilt',r/'copper-after',r/'copper-before'])
 run('gpi-after',r/'env',repo/'benchmarks/validate_fine_fft_gpi_cuda.jl',[r.parent/'GPI2Sim-pupil-tilt',r/'gpi-after'],{'GPI_LOOP_CASES':'default,fine,transfer'})
finally:
 stop.set();thread.join()
