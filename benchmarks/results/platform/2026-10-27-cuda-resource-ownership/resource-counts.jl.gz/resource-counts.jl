using CUDA, Test
const CC = CUDA.CUDACore

@testset "CUDA release counter semantics" begin
    seen = zeros(Int, 3)
    recursive_result = Ref(-1)
    lock(CC.drain_lock) do
        CC.drain_retired()
        release = i -> begin
            seen[i] += 1
            if i == 3
                recursive_result[] = CC.drain_retired()
            end
            nothing
        end
        for i in 1:3
            CC.retire!(CC.ReleaseAction(release, i, nothing, false))
        end
        @test CC.drain_retired(2) == 2
        @test sum(seen) == 2
        @test all(x -> x in (0,1), seen)
        CC.begin_capture()
        try
            @test CC.drain_retired() == 0
            @test sum(seen) == 2
        finally
            CC.end_capture()
        end
        @test CC.drain_retired() == 1
        @test seen == ones(Int,3)
        @test recursive_result[] == 0
        @test CC.drain_retired() == 0
        @test CC.active_releases[] == 0
        @test !CC.drain_running[]
    end
end
