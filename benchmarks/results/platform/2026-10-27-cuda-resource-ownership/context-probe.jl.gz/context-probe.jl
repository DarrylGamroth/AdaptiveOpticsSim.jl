using CUDA, AdaptiveOpticsSim, InteractiveUtils, Profile
const B = AdaptiveOpticsSim.Backends
ctx = B._prepare_device_execution_context(B.compute_device(CUDA.zeros(Float32,1)))
noop() = nothing
call_original(ctx) = B._with_prepared_device_execution_context(noop, ctx)
call_public(ctx) = CUDA.context!(CUDA.context(ctx.device)) do
    CUDA.stream!(noop, ctx.stream)
end
function call_public_saved(ctx, target_context)
    CUDA.context!(target_context) do
        CUDA.stream!(noop, ctx.stream)
    end
end
context_only(dev) = CUDA.context(dev)
function measure(f, args...)
    for _ in 1:10; f(args...); end
    return [@allocated f(args...) for _ in 1:10]
end
println("original ",measure(call_original,ctx))
println("public ",measure(call_public,ctx))
println("public saved ",measure(call_public_saved,ctx,CUDA.context(ctx.device)))
println("context ",measure(context_only,ctx.device))
code_warntype(stdout,call_original,Tuple{typeof(ctx)})
code_llvm(stdout,call_original,Tuple{typeof(ctx)};debuginfo=:source)
