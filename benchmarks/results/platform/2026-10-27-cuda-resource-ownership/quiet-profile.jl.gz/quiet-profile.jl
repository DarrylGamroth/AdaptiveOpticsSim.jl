using CUDA, Profile
function wait!(stream)
    CUDA.synchronize(stream; blocking=true)
    return nothing
end
bytes(stream) = @allocated wait!(stream)
function main()
    stream = CUDA.CuStream(; flags=CUDA.STREAM_NON_BLOCKING)
    for _ in 1:16
        wait!(stream)
        bytes(stream)
    end
    println("warm bytes: ",bytes(stream))
    sleep(10.1)
    println("quiet bytes: ",bytes(stream))
    println("next bytes: ",bytes(stream))
    Profile.Allocs.@profile sample_rate=1.0 wait!(stream)
    Profile.Allocs.clear()
    sleep(10.1)
    Profile.Allocs.@profile sample_rate=1.0 wait!(stream)
    for a in Profile.Allocs.fetch().allocs
        println("ALLOCATION ",a.size," ",a.type)
        for f in a.stacktrace
            occursin("/packages/",string(f.file)) || occursin("/deps/cudacore",string(f.file)) || continue
            println("  ",f.func," ",f.file,":",f.line)
        end
    end
end
main()
