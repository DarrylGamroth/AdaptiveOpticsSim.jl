import CUDA
using Test
include("/home/dgamroth/workspaces/codex/worktrees/aos-cuda65-resource-patch-20261027/test/runtests_gpu_target_common.jl")
require_backend_target!(Backends.CUDABackendTag)
include("/home/dgamroth/workspaces/codex/worktrees/aos-cuda65-resource-patch-20261027/test/cuda/prepared_context.jl")
@testset "captured owner" run_captured_graph_execution_smoke(Backends.CUDABackendTag)
