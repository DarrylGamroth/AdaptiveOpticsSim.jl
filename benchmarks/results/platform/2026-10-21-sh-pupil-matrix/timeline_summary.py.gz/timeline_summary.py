import collections,csv,json,sqlite3
from pathlib import Path
root=Path('/tmp/aos-sh-matrix-20261021')
results=[]
for i,policy in [(1,'checked_stream'),(2,'captured_graph')]:
 c=sqlite3.connect(root/f'architecture-timeline.{i}.sqlite')
 api=list(c.execute('select a.start,a.end,s.value from CUPTI_ACTIVITY_KIND_RUNTIME a join StringIds s on a.nameId=s.id order by a.start'))
 kernels=list(c.execute('select a.start,a.end,a.streamId,s.value from CUPTI_ACTIVITY_KIND_KERNEL a join StringIds s on a.shortName=s.id order by a.start'))
 launch='cuGraphLaunch' if i==2 else 'cuLaunch'
 start=next(a for a,b,n in api if n.startswith(launch))
 end=max(max(b for a,b,_,_ in kernels),max(b for a,b,n in api if n in ('cuStreamSynchronize','cuCtxSynchronize')))
 union=[]
 for a,b,_,_ in kernels:
  if union and a<=union[-1][1]:union[-1][1]=max(b,union[-1][1])
  else:union.append([a,b])
 busy=sum(b-a for a,b in union)
 counts=collections.Counter(n for a,b,n in api)
 assert len(kernels)==3328
 assert counts['cuGraphLaunch']==(256 if i==2 else 0)
 assert all(start<=a<b<=end for a,b,_,_ in kernels)
 result=dict(policy=policy,steps=256,traced_interval_ns=end-start,kernel_active_union_ns=busy,kernel_active_percent=100*busy/(end-start),kernel_activities=len(kernels),kernel_stream_ids=sorted({s for a,b,s,n in kernels}),graph_launch_calls=counts['cuGraphLaunch'],kernel_launch_calls=counts['cuLaunchKernel']+counts['cuLaunchKernelEx'],device_to_device_copy_calls=counts['cuMemcpyDtoDAsync_v2'],stream_synchronize_calls=counts['cuStreamSynchronize'],warmed_host_bytes=0 if i==2 else 7120)
 results.append(result)
 for name,rows,header in [('apis',api,['start_ns','end_ns','name']),('kernels',kernels,['start_ns','end_ns','stream_id','name'])]:
  with (root/f'architecture-{policy}-{name}.csv').open('w') as f:
   w=csv.writer(f);w.writerow(header);w.writerows(rows)
(root/'timeline-summary.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
